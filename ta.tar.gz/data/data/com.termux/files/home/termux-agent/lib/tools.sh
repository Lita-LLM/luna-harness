#!/usr/bin/env bash
# lib/tools.sh — реестр инструментов.
# Инструмент = .sh в tools/ (встроенные) или ~/.config/termux-agent/tools/ (свои)
# с двумя функциями: tool_meta (печатает JSON-схему) и tool_run (аргументы в $1).

tools_files() {
  local f
  for f in "$TA_HOME/tools"/*.sh "$TA_USER_TOOLS"/*.sh; do
    [[ -f "$f" ]] && printf '%s\n' "$f"
  done
}

tools_find() {
  local name="$1" f
  while IFS= read -r f; do
    [[ "$(basename "$f" .sh)" == "$name" ]] && { printf '%s' "$f"; return 0; }
  done < <(tools_files)
  return 1
}

tools_manifest() {
  if [[ -s "$TA_TMP/tools.json" ]]; then cat "$TA_TMP/tools.json"; return; fi
  local f
  { while IFS= read -r f; do
      ( set +u; source "$TA_HOME/lib/toolkit.sh"; source "$f"
        declare -F tool_meta >/dev/null && tool_meta ) 2>/dev/null
    done < <(tools_files); } \
  | jq -s --argjson off "$(cfg_read '.settings.disabled_tools // []')" \
      'map(select(.name as $n | ($off | index($n)) | not))' > "$TA_TMP/tools.json"
  cat "$TA_TMP/tools.json"
}

# Схема для модели. В режиме плана инструменты с x_writes не отдаются вовсе —
# так модель физически не может ничего изменить, даже если очень захочет.
tools_schema() {
  if [[ "${TA_MODE:-normal}" == "plan" ]]; then
    tools_manifest | jq 'map(select((.x_writes // false) == false)) | map({name, description, parameters})'
  else
    tools_manifest | jq 'map({name, description, parameters})'
  fi
}

tools_summary() {
  local name="$1" args="$2"
  jq -r --arg n "$name" '
    if   $n=="bash"        then (.command // "")
    elif $n=="web_search"  then (.query // "") + (if (.source // "web") != "web" then " · " + .source else "" end) + (if (.read // 0) > 0 then " · читать \(.read)" else "" end)
    elif $n=="web_fetch"   then (.url // "") + (if .find then " · найти: " + .find elif (.offset // 0) > 0 then " · с \(.offset)" else "" end)
    elif $n=="ask_user"    then (.question // "")
    elif $n=="todo"        then ((.items // []) | length | tostring) + " шагов"
    elif $n=="edit_file"   then (.path // "")
    elif $n=="write_file"  then (.path // "")
    elif $n=="read_file"   then (.path // "")
    else ([to_entries[] | "\(.key)=\(.value|tostring|.[0:60])"] | join(" "))
    end' <<<"$args" 2>/dev/null | tr '\n' ' '
}

tools_run() {
  local name="$1" args="$2" f out rc
  f="$(tools_find "$name")" || { printf 'ОШИБКА: инструмент «%s» не найден' "$name"; return 0; }
  out="$( ( set +u
            export TA_TOOL_ARGS="$args"
            source "$TA_HOME/lib/toolkit.sh"
            source "$TA_HOME/lib/select.sh"
            source "$TA_HOME/lib/subagent.sh"
            source "$TA_HOME/providers/$TA_PROVIDER.sh" 2>/dev/null
            source "$f"
            tool_run "$args" ) 2>&1 )"
  rc=$?
  (( rc != 0 )) && out="${out}"$'\n'"[код возврата инструмента: $rc]"
  # Ядерный вывод (сборка, логи, дампы) убил бы контекст. Кладём целиком в файл,
  # модели отдаём начало, конец и путь — дальше пусть читает точечно.
  if (( ${#out} > TA_OUT_LIMIT )); then
    local dir="$TA_DATA_DIR/tool-output" f head_part tail_part total=${#out}
    mkdir -p "$dir" 2>/dev/null
    f="$dir/$(date +%Y%m%d-%H%M%S)-$name.log"
    printf '%s' "$out" > "$f"
    local keep=$(( TA_OUT_LIMIT / 3 ))
    (( keep < 500 )) && keep=500
    head_part="${out:0:$keep}"
    tail_part="${out: -$keep}"
    out="[ВЫВОД СЛИШКОМ БОЛЬШОЙ: $total символов — в контекст не помещается]
Целиком сохранён в файл: $f

Первые $keep символов:
$head_part

Последние $keep символов:
$tail_part

Не запрашивай файл целиком. Нужное ищи точечно:
  grep_files с pattern по пути $f
  read_file с offset/limit по этому же пути"
  fi
  [[ -z "$out" ]] && out="(пусто, ошибок нет)"
  printf '%s' "$out"
}

cmd_tools() {
  local n d w mark
  printf '\n'
  w=$(( UI_COLS - 16 )); (( w < 20 )) && w=20
  while IFS=$'\t' read -r n d mark; do
    [[ -z "$n" ]] && continue
    d="${d%%.*}."
    printf ' %s%-12s%s %s%s%s' "$C_B" "$n" "$C_RESET" "$C_GRY" "$(str_trunc "$d" "$w")" "$C_RESET"
    [[ "$mark" == "true" ]] && printf ' %s✎%s' "$C_YEL" "$C_RESET"
    printf '\n'
  done < <(tools_manifest | jq -r '.[] | "\(.name)\t\(.description)\t\(.x_writes // false)"')
  printf '\n %s✎ — меняет файлы, в режиме плана недоступен%s\n' "$C_DIM" "$C_RESET"
  printf ' %sсвои инструменты: %s/%s\n\n' "$C_DIM" "$TA_USER_TOOLS" "$C_RESET"
}

# ── проверка действий: что проверять и что делать с вердиктом ──────────────
#
# tools_gate <имя> <args> решает судьбу вызова и кладёт ответ в TA_GATE:
#   run  — выполнять;  ask — спросить человека;  deny — отклонить (TA_GATE_REASON)
#
# Кто что решает по режимам:
#   обычный / план   инструменты с x_confirm (bash, запись файлов) и те, что в
#                    confirm_tools, спрашивают человека всегда. Остальное из
#                    области проверки (чтение секретов, web_fetch на localhost…)
#                    смотрит модель: опасно — спросить.
#   авто             всё из области проверки смотрит модель: опасно — спросить
#                    (auto_ask_dangerous false — не спрашивать вообще).
#   полный авто      эскалация из авто клавишей «a» ещё раз. Опасное по мнению
#                    модели-проверяющей не спрашивает, а выполняется с пометкой
#                    в результате инструмента (модель это видит). Проверка не
#                    выключается — только сама блокировка. Необратимое по
#                    локальным правилам (tools_risk_why) — всё равно спрашивает.
#   ревизор          всё из области проверки смотрит модель: опасно — отклонить
#                    без вопроса; модель недоступна — спросить человека.
#
# Чем проверять — auto_check: model (по умолчанию) | both (сначала локальные
# правила, спорное — модели) | regex (только правила) | off.
# Модель недоступна — срабатывают локальные правила, проверка не пропадает.

tools_flag() {   # tools_flag <имя> <поле> → значение из манифеста
  tools_manifest | jq -r --arg n "$1" --arg f "$2" '.[] | select(.name==$n) | .[$f] // empty' 2>/dev/null
}

tools_gate() {
  local name="$1" args="${2:-{\}}" mode="${TA_MODE:-normal}"
  TA_GATE=run; TA_GATE_REASON=""
  local extra forced=0
  extra="$(cfg_setting confirm_tools "")"
  if [[ "$extra" == all ]] || [[ -n "$extra" && " $extra " == *" $name "* ]]; then forced=1; fi

  case "$mode" in
    auto)
      [[ "$(cfg_setting auto_ask_dangerous true)" == "true" ]] || return 0
      tools_guard_scope "$name" "$args" || return 0
      _tools_verdict "$name" "$args" loose
      case $? in
        0) TA_GATE=ask ;;
        3) TA_GATE=deny; TA_GATE_REASON="проверка прервана пользователем" ;;
      esac ;;
    full)
      # Полный авто (эскалация из авто клавишей «a» ещё раз). Разница с «авто»:
      # то, что проверка сочла опасным, здесь не спрашивает, а просто выполняется —
      # причина уходит модели пометкой в результате инструмента (guard_note_wrap),
      # чтобы она это учитывала. Саму проверку это не выключает: она по-прежнему
      # запускается на каждом вызове из области действия.
      # Единственное исключение — объективно необратимое или разрушительное
      # (tools_risk_why … hard: rm -rf, dd/mkfs, curl|sh, правка автозапуска,
      # чтение ~/.ssh/.env/конфига с ключами, ключи моделей из конфига в
      # аргументах). Это узкий локальный список правил, а не вердикт модели-
      # проверяющей, и полный авто его не снимает: тут по-прежнему спрашивает.
      # Обычные POST в API (curl -d) сюда не входят — их смотрит модель.
      tools_guard_scope "$name" "$args" || return 0
      local why; why="$(tools_risk_why "$name" "$args" hard)"
      if [[ -n "$why" ]]; then
        TA_GATE=ask; TA_GATE_REASON="необратимо: $why"
        return 0
      fi
      _tools_verdict "$name" "$args" loose
      case $? in
        0) TA_GATE=note; TA_GATE_REASON="${GUARD_REASON:-опасно}" ;;
      esac ;;
    guard)
      if ! tools_guard_scope "$name" "$args"; then
        (( forced == 1 )) && TA_GATE=ask
        return 0
      fi
      _tools_verdict "$name" "$args" strict
      case $? in
        0) TA_GATE=deny ;;
        1) TA_GATE=run ;;
        3) TA_GATE=deny; TA_GATE_REASON="проверка прервана пользователем" ;;
        *) TA_GATE=ask ;;
      esac ;;
    *)
      if (( forced == 1 )) || [[ "$(tools_flag "$name" x_confirm)" == "true" ]]; then
        TA_GATE=ask; return 0
      fi
      tools_guard_scope "$name" "$args" || return 0
      _tools_verdict "$name" "$args" loose
      case $? in
        0) TA_GATE=ask ;;
        3) TA_GATE=deny; TA_GATE_REASON="проверка прервана пользователем" ;;
      esac ;;
  esac
  return 0
}

# _tools_verdict <имя> <args> <loose|strict> → 0 опасно, 1 безопасно,
# 2 решить не удалось (только strict), 3 прервано. Причина — в TA_GATE_REASON.
_tools_verdict() {
  local name="$1" args="$2" strict="${3:-loose}" method why
  method="$(cfg_setting auto_check model)"
  case "$method" in
    off) return 1 ;;
    regex)
      why="$(tools_risk_why "$name" "$args")"
      [[ -n "$why" ]] && { TA_GATE_REASON="правила: $why"; return 0; }
      return 1 ;;
    both)
      why="$(tools_risk_why "$name" "$args")"
      [[ -n "$why" ]] && { TA_GATE_REASON="правила: $why"; return 0; } ;;
  esac
  if declare -F guard_check >/dev/null; then
    guard_check "$name" "$args"
    case $? in
      0) TA_GATE_REASON="${GUARD_REASON:-опасно}"; return 0 ;;
      1) return 1 ;;
      3) return 3 ;;
    esac
    ui_dim "  проверка недоступна: $(str_trunc "${GUARD_REASON:-нет ответа}" 90)"
  fi
  why="$(tools_risk_why "$name" "$args")"
  if [[ -n "$why" ]]; then TA_GATE_REASON="правила: $why"; return 0; fi
  [[ "$strict" == strict ]] && { TA_GATE_REASON="модель не ответила, решай сам"; return 2; }
  ui_dim "  по локальным правилам опасного не видно"
  return 1
}

# ── область проверки ────────────────────────────────────────────────────────
# guard_scope: smart (по умолчанию) | all | writes
#   writes — как раньше: только bash и изменяющие инструменты;
#   all    — каждый вызов, кроме помеченных x_guard: false (todo, ask_user);
#   smart  — bash, запись, субагенты и чужие инструменты всегда; чтение файлов —
#            когда путь вне проекта, $PREFIX и временных каталогов или похож на
#            секреты; web_fetch и web_search — когда в них localhost, частная
#            сеть или что-то похожее на ключ. Иначе модель не тревожим: на каждое
#            чтение файла в проекте тратить запрос бессмысленно.
tools_guard_scope() {   # → 0 проверять, 1 не надо
  local name="$1" args="$2" scope
  [[ "$(tools_flag "$name" x_guard)" == "false" ]] && return 1
  scope="$(cfg_setting guard_scope smart)"
  case "$scope" in
    all) return 0 ;;
    writes)
      [[ "$name" == bash || "$(tools_flag "$name" x_confirm)" == true || "$(tools_flag "$name" x_writes)" == true ]] && return 0
      return 1 ;;
  esac
  case "$name" in
    bash|write_file|edit_file|subagents) return 0 ;;
    read_file|list_dir|grep_files)
      [[ -n "$(tools_risk_why "$name" "$args")" ]] && return 0
      local p; p="$(_tools_abs "$(jq -r '.path // ""' <<<"$args" 2>/dev/null)")"
      _tools_path_safe "$p" && return 1
      return 0 ;;
    web_fetch|web_search)
      [[ -n "$(tools_risk_why "$name" "$args")" ]] && return 0
      (( $(jq -r '((.url // .query // "") | length)' <<<"$args" 2>/dev/null || echo 0) > 300 )) && return 0
      return 1 ;;
    todo|ask_user) return 1 ;;
    *) return 0 ;;   # свой инструмент — неизвестно, что он делает
  esac
}

# Абсолютный путь без обращения к модели: ~, относительный, «..».
_tools_abs() {
  local p="${1:-}"
  [[ -z "$p" || "$p" == "null" ]] && p="$PWD"
  p="${p/#\~/$HOME}"
  [[ "$p" != /* ]] && p="$PWD/$p"
  if command -v realpath >/dev/null 2>&1; then realpath -m -- "$p" 2>/dev/null || printf '%s' "$p"
  else printf '%s' "$p"; fi
}

# Каталоги, чтение из которых не требует проверки (если путь не похож на секрет).
_tools_path_safe() {
  local p="$1" r
  for r in "$PWD" "${PREFIX:-/nonexistent}" "${TMPDIR:-/tmp}" /tmp "${TA_DATA_DIR:-/nonexistent}/tool-output" \
           "${TA_DATA_DIR:-/nonexistent}/run" /proc /sys; do
    [[ -n "$r" && ( "$p" == "$r" || "$p" == "$r"/* ) ]] && return 0
  done
  return 1
}

# Похоже ли на путь к секретам или личным файлам. Регистр не важен.
_tools_path_sensitive() {
  local p="${1,,}"
  [[ "$p" =~ (^|/)\.(ssh|gnupg|aws|azure|kube|docker|password-store|netrc|git-credentials|pgpass|npmrc|pypirc)(/|$) ]] && return 0
  [[ "$p" =~ (^|/)\.env($|\.) || "$p" =~ id_(rsa|dsa|ecdsa|ed25519) ]] && return 0
  [[ "$p" =~ \.(pem|p12|pfx|jks|keystore|kdbx|key)$ ]] && return 0
  [[ "$p" =~ (credential|secret|passw|wallet|cookies) ]] && return 0
  [[ "$p" =~ termux-agent/config\.json || "$p" =~ /proc/[^/]*/environ ]] && return 0
  [[ "$p" =~ (^|/)\.(bash|zsh|python|node_repl|psql|mysql)_?history$ ]] && return 0
  [[ "$p" == "${HOME,,}/storage" || "$p" == "${HOME,,}/storage/"* || "$p" =~ ^/(sdcard|storage/emulated|storage/self)(/|$) || "$p" =~ ^/etc/(ssh|shadow) ]] && return 0
  [[ "$p" == /data/data/* && "$p" != /data/data/com.termux* ]] && return 0
  return 1
}

# Текст похож на ключ или токен. $2=url — ещё и длинные случайные куски:
# в адресах и запросах им взяться неоткуда, а в командах это обычно хэши.
_tools_text_secretish() {
  local t="$1" lt="${1,,}" m
  [[ "$lt" =~ (sk-(proj-|ant-|or-)?[a-z0-9_-]{16,}|ghp_[a-z0-9]{20,}|github_pat_|gho_[a-z0-9]{16,}|xox[abp]-[a-z0-9-]{8,}|akia[0-9a-z]{12,}|aiza[0-9a-z_-]{20,}|-----begin[a-z ]*private) ]] && return 0
  [[ "$lt" =~ [?\&](api_?key|apikey|token|access_token|secret|password|passwd|auth)=[^\&]{6,} ]] && return 0
  [[ "${2:-}" == url ]] || return 1
  while IFS= read -r m; do
    # случайная строка: есть и строчные, и заглавные, и цифры, почти нет дефисов
    [[ "$m" =~ [a-z] && "$m" =~ [A-Z] && "$m" =~ [0-9] ]] || continue
    local h="${m//[^-]/}"; (( ${#h} <= 3 )) && return 0
  done < <(grep -oE '[A-Za-z0-9+_=-]{40,}' <<<"$t" 2>/dev/null)
  return 1
}

# Ключи API из конфига и окружения: если они попали в аргументы — это утечка.
_tools_args_have_secret() {
  local args="$1" k
  if [[ -z "${TA_SECRET_VALUES_READY:-}" ]]; then
    TA_SECRET_VALUES=()
    while IFS= read -r k; do
      [[ ${#k} -ge 12 ]] && TA_SECRET_VALUES+=("$k")
    done < <(jq -r '(.profiles[]? | .api_key // empty), (.settings.search_api_key // empty)' "$TA_CFG" 2>/dev/null
             while IFS= read -r e; do [[ -n "$e" && "$e" != NONE ]] && printf '%s\n' "${!e:-}"; done \
               < <(jq -r '.profiles[]?.api_key_env // empty' "$TA_CFG" 2>/dev/null)
             printf '%s\n' "${GITHUB_TOKEN:-}" "${GH_TOKEN:-}")
    TA_SECRET_VALUES_READY=1
  fi
  for k in "${TA_SECRET_VALUES[@]}"; do
    [[ "$args" == *"$k"* ]] && return 0
  done
  return 1
}

# Локальные правила: мгновенно, без сети. Запасной вариант, когда модель
# недоступна, и быстрый предфильтр в режиме both.
# tools_risk_why <имя> <args> → короткая причина, если опасно; пусто, если нет.
# Обычный и безопасный паттерн: `mktemp` заводит временный файл/каталог,
# `trap '... rm ... "$var" ...' EXIT` убирает его за собой. Regex ниже видит
# только «rm -f» и не смотрит, ЧТО удаляется — вырезаем из проверяемой строки
# rm-вызовы, чей аргумент — переменная, которую та же команда только что
# получила из mktemp. Реальные пути, wildcard-ы и переменные не из mktemp
# по-прежнему проверяются как есть.
_tools_strip_mktemp_rm() {
  local v="$1" out="$1"
  local -a names=()
  mapfile -t names <<<"$(grep -oE '\b[A-Za-z_][A-Za-z0-9_]*=\$\(\s*mktemp\b' <<<"$v" | sed -E 's/=.*//')"
  local tv
  for tv in "${names[@]}"; do
    [[ -n "$tv" ]] || continue
    out="$(printf '%s' "$out" | sed -E "s#rm(\\s+-[a-zA-Z]+)?\\s+[\"']?\\\$\\{?${tv}\\}?[\"']?##g")"
  done
  printf '%s' "$out"
}

# Третий аргумент hard — только необратимое (барьер полного авто): без правила
# «отправляет данные наружу». POST в API — обычная работа, а не разрушение;
# в полном авто его оценивает модель-проверяющая и пишет пометку, не блокирует.
tools_risk_why() {
  local name="$1" args="$2" level="${3:-all}" v p
  if _tools_args_have_secret "$args"; then printf 'в аргументах ключ API из конфига'; return; fi
  case "$name" in
    bash)
      v="$(jq -r '.command // ""' <<<"$args" 2>/dev/null)"
      local danger='rm +-[rRf]|rm +-[a-zA-Z]*[rRf]|mkfs|(^|[^a-z])dd +if=|shred|truncate +-s|:\(\)\{|chmod +-R|chown +-R|chmod +777|>[ ]*/dev/(sd|block)|killall|pkill|reboot|halt|poweroff|pkg +(uninstall|remove)|apt(-get)? +(remove|purge|autoremove)|npm +uninstall|pip +uninstall|git +(reset +--hard|clean +-[a-z]*f|push +--force)|curl[^|]*\| *(ba)?sh|wget[^|]*\| *(ba)?sh|find +[^|]* -delete|mv +[^ ]+ +/($|[a-z]+$)|termux-setup-storage|su +-c|tsu'
      if printf '%s' "$(_tools_strip_mktemp_rm "$v")" | grep -qE "$danger"; then printf 'разрушительная или системная команда'; return; fi
      if printf '%s' "$v" | grep -qiE '(\.ssh|id_(rsa|ed25519|ecdsa)|\.env([^a-z]|$)|\.netrc|git-credentials|termux-agent/config\.json|/environ|~/storage|/sdcard|/storage/emulated)'; then
        printf 'трогает секреты или личные файлы'; return; fi
      if printf '%s' "$v" | grep -qE '(>>?|tee( -a)?) *[^|;&]*(\.bashrc|\.zshrc|\.profile|\.bash_profile|/etc/)|crontab|termux-job-scheduler'; then
        printf 'меняет окружение или автозапуск'; return; fi
      if [[ "$level" != hard ]] && printf '%s' "$v" | grep -qE '(curl|wget)[^|;&]*( -d | --data| -F | --form| -T | --upload-file|--post-file)|\| *(nc|ncat|socat)( |$)|(nc|ncat) [^|;]* -e '; then
        printf 'отправляет данные наружу'; return; fi
      _tools_text_secretish "$v" && { printf 'в команде похоже на ключ или токен'; return; } ;;
    read_file|list_dir|grep_files)
      p="$(_tools_abs "$(jq -r '.path // ""' <<<"$args" 2>/dev/null)")"
      _tools_path_sensitive "$p" && { printf 'секреты или личные файлы: %s' "$p"; return; }
      if [[ "$name" == grep_files ]]; then
        v="$(jq -r '(.pattern // "") + " " + (.name // "")' <<<"$args" 2>/dev/null)"
        if [[ "${v,,}" =~ (api[_-]?key|token|secret|passw|private.key|begin.*private|authorization|bearer|\.env|id_rsa) ]] && ! _tools_path_safe "$p"; then
          printf 'ищет секреты вне проекта'; return; fi
        [[ "$p" == "$HOME" || "$p" == / ]] && [[ "${v,,}" =~ (key|token|secret|passw) ]] && { printf 'ищет секреты по всему дому'; return; }
      fi ;;
    write_file|edit_file)
      p="$(_tools_abs "$(jq -r '.path // ""' <<<"$args" 2>/dev/null)")"
      _tools_path_sensitive "$p" && { printf 'пишет в секреты или личные файлы'; return; }
      [[ "$p" =~ /\.(bashrc|zshrc|profile|bash_profile|termux/termux\.properties)$ || "$p" == "${PREFIX:-/nonexistent}/etc/"* || "$p" == /etc/* ]] \
        && { printf 'меняет окружение shell или систему'; return; } ;;
    web_fetch)
      v="$(jq -r '.url // ""' <<<"$args" 2>/dev/null)"
      local host="${v#*://}"; host="${host%%/*}"; host="${host##*@}"; host="${host,,}"
      if [[ "$v" != http://* && "$v" != https://* && "$v" == *://* ]]; then printf 'не http-адрес'; return; fi
      if [[ "$host" =~ ^(localhost|127\.|0\.0\.0\.0|10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[01])\.|169\.254\.|\[::1\]|\[fe80) || "$host" =~ \.(local|internal|lan)(:[0-9]+)?$ ]]; then
        printf 'обращается к локальной сети: %s' "$host"; return; fi
      [[ "${v#*://}" == *@* && "${v#*://}" != */*@* ]] && { printf 'логин и пароль в адресе'; return; }
      _tools_text_secretish "$v" url && { printf 'похоже на отправку данных в URL'; return; } ;;
    web_search)
      v="$(jq -r '.query // ""' <<<"$args" 2>/dev/null)"
      _tools_text_secretish "$v" url && { printf 'в запросе похоже на ключ или токен'; return; } ;;
  esac
  return 0
}

# Совместимость со старыми вызовами.
tools_risk() { [[ -n "$(tools_risk_why "$1" "$2")" ]] && printf 'high' || printf 'low'; }
