#!/usr/bin/env bash
# lib/toolkit.sh — хелперы, доступные внутри любого инструмента.

# arg "ключ" ["значение по умолчанию"] — достать строковый аргумент из JSON в $TA_TOOL_ARGS
arg() {
  local k="$1" d="${2:-}" v
  v="$(jq -r --arg k "$k" '.[$k] // empty' <<<"${TA_TOOL_ARGS:-{\}}" 2>/dev/null)"
  [[ -n "$v" && "$v" != "null" ]] && printf '%s' "$v" || printf '%s' "$d"
}

# argj "ключ" — достать сырой JSON (массив/объект)
argj() { jq -c --arg k "$1" '.[$k] // empty' <<<"${TA_TOOL_ARGS:-{\}}" 2>/dev/null; }

die()  { printf 'ОШИБКА: %s\n' "$*"; exit 1; }

have() { command -v "$1" >/dev/null 2>&1; }

# Раскрытие ~ и $PREFIX в путях
expand_path() {
  local p="$1"
  p="${p/#\~/$HOME}"
  printf '%s' "$p"
}

urlencode() {
  local s="$1" o="" i c
  for (( i=0; i<${#s}; i++ )); do
    c="${s:i:1}"
    case "$c" in [a-zA-Z0-9.~_-]) o+="$c" ;; ' ') o+='+' ;; *) o+=$(printf '%%%02X' "'$c") ;; esac
  done
  printf '%s' "$o"
}

urldecode() { local s="${1//+/ }"; printf '%b' "${s//%/\\x}"; }

html_unescape() {
  sed -e 's/&amp;/\&/g' -e 's/&lt;/</g' -e 's/&gt;/>/g' -e 's/&quot;/"/g' \
      -e "s/&#x27;/'/g" -e "s/&#39;/'/g" -e 's/&nbsp;/ /g' -e 's/&#x2F;/\//g' \
      -e 's/&middot;/·/g' -e 's/&mdash;/—/g' -e 's/&ndash;/–/g' -e 's/&hellip;/…/g'
}

html_to_text() {
  sed -e 's/<script[^>]*>.*<\/script>//gI' -e 's/<style[^>]*>.*<\/style>//gI' \
    | sed -e 's/<[^>]*>/ /g' \
    | html_unescape \
    | tr -s ' \t' ' ' \
    | grep -v '^[[:space:]]*$'
}

# Чекпоинт: сохранить состояние файла до изменения, чтобы работал /rewind.
# Пустая вторая колонка означает «файла не было» — при откате он удаляется.
ckpt_save() {
  local p="$1" b
  [[ -n "${TA_CKPT_LOG:-}" ]] || return 0
  if [[ -f "$p" ]]; then
    b="$TA_CKPT_DIR/$(date +%s%N)-$(basename "$p")"
    cp "$p" "$b" 2>/dev/null && printf '%s\t%s\n' "$p" "$b" >> "$TA_CKPT_LOG"
  else
    printf '%s\t\n' "$p" >> "$TA_CKPT_LOG"
  fi
  return 0
}

UA='Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36'
