#!/usr/bin/env bash
# Запуск подчинённых агентов, в том числе нескольких сразу.
tool_meta() {
cat <<'JSON'
{
  "name": "subagents",
  "description": "Поручить подзадачи подчинённым агентам. Каждый работает сам, со своей историей, и возвращает только сжатый итог — твой контекст не забивается выводом их команд. До четырёх задач выполняются параллельно. Годится для разведки и рутины: выяснить версии, найти конфиг, изучить логи, поискать причину ошибки в интернете. Права задаёшь полем access, модель — полем model.",
  "parameters": {
    "type": "object",
    "properties": {
      "tasks": {
        "type": "array",
        "description": "От 1 до 4 задач. Каждая самостоятельная и подробно описанная: субагент не видит вашего диалога",
        "items": {
          "type": "object",
          "properties": {
            "name": {"type": "string", "description": "Короткое имя задачи для отчёта"},
            "task": {"type": "string", "description": "Что именно сделать. Пиши развёрнуто, со всем контекстом"},
            "access": {"type": "string", "enum": ["read", "diagnose", "write"],
              "description": "read — только чтение и поиск (по умолчанию); diagnose — плюс bash для диагностики, опасные команды отклоняются сами; write — плюс правка файлов, доступно когда задача одна или сеанс в авто-режиме (авто или полный авто)"},
            "model": {"type": "string", "description": "Имя профиля из конфига или идентификатор модели. Дешёвую и быструю модель бери на разведку, сильную — на разбор"},
            "max_steps": {"type": "integer", "description": "Лимит шагов, по умолчанию 8"}
          },
          "required": ["name", "task"]
        }
      }
    },
    "required": ["tasks"]
  }
}
JSON
}

tool_run() {
  local tasks n
  tasks="$(argj tasks)"
  n="$(jq 'length' <<<"${tasks:-[]}" 2>/dev/null || echo 0)"
  (( n == 0 )) && die "не переданы задачи"
  (( n > 4 )) && n=4

  local dir; dir="$(mktemp -d "${TMPDIR:-/tmp}/ta-subs.XXXXXX")"
  # Имя задачи и файл её ответа держим строго парой. Раньше имена копились
  # только для запущенных задач, а файл назывался по индексу цикла — стоило
  # пропустить одну задачу, и ответы разъезжались по чужим заголовкам.
  local i pids=() names=() outs=() notes=""
  for (( i=0; i<n; i++ )); do
    local name task steps access model
    name="$(jq -r ".[$i].name // \"задача-$((i+1))\"" <<<"$tasks")"
    task="$(jq -r ".[$i].task // \"\"" <<<"$tasks")"
    steps="$(jq -r ".[$i].max_steps // 8" <<<"$tasks")"
    access="$(jq -r ".[$i].access // \"read\"" <<<"$tasks")"
    model="$(jq -r ".[$i].model // \"\"" <<<"$tasks")"
    [[ -z "$task" ]] && continue

    # Право на запись при нескольких задачах разом не выдаём: уследить за
    # параллельными изменениями невозможно ни пользователю, ни тебе.
    if [[ "$access" == "write" && $n -gt 1 && "${TA_MODE:-normal}" != "auto" && "${TA_MODE:-normal}" != "full" ]]; then
      access="diagnose"
      notes+="  · «$name»: права понижены до diagnose — запись при нескольких задачах разом не выдаётся"$'\n'
    fi
    if [[ "$access" != "read" && "${TA_MODE:-normal}" == "plan" ]]; then
      access="read"
      notes+="  · «$name»: режим плана, оставлено только чтение"$'\n'
    fi

    names+=("$name")
    outs+=("$dir/$i.out")
    printf '  %s↳ %s%s %s(%s%s)%s\n' "${C_MAG:-}" "$name" "${C_RESET:-}" "${C_DIM:-}" \
      "$access" "${model:+, $model}" "${C_RESET:-}" >&2
    subagent_run "$name" "$task" "$steps" "$dir/$i.out" "$access" "$model" &
    pids+=($!)
  done

  local p
  for p in "${pids[@]}"; do wait "$p" 2>/dev/null; done

  local out=""
  [[ -n "$notes" ]] && out+="Поправки к запуску:"$'\n'"$notes"$'\n'
  for (( i=0; i<${#names[@]}; i++ )); do
    out+="=== ${names[$i]} ==="$'\n'
    out+="$(cat "${outs[$i]}" 2>/dev/null || echo '[нет ответа]')"$'\n\n'
  done
  rm -rf "$dir"
  printf '%s' "$out"
}
