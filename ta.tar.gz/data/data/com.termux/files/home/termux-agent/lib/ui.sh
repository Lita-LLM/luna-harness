#!/usr/bin/env bash
# lib/ui.sh — вывод: цвета, зоны текста, статус-строка, рендер markdown.
#
# Зоны различаются глифом, цветом и отступом, чтобы на узком экране телефона
# не путались ввод, ответ модели, мысли и вывод инструментов:
#
#   ❯   твой ввод      зелёная стрелка приглашения
#   ▶   твоя реплика   зелёный (эхо очереди и восстановленных сессий)
#       ответ модели   обычный текст без отступа
#   💭  мысли          серым, с чертой слева
#   ⚙   инструмент     сиреневый заголовок, вывод серым с чертой
#   •✓!✗ служебное     синий/зелёный/жёлтый/красный

ui_init() {
  if [[ -t 1 && -z "${NO_COLOR:-}" && "${TA_COLOR:-1}" != "0" ]]; then
    C_RESET=$'\033[0m'; C_DIM=$'\033[2m'; C_B=$'\033[1m'; C_IT=$'\033[3m'
    C_RED=$'\033[38;5;203m'; C_GRN=$'\033[38;5;114m'; C_YEL=$'\033[38;5;179m'
    C_BLU=$'\033[38;5;75m';  C_MAG=$'\033[38;5;176m'; C_CYA=$'\033[38;5;80m'
    C_GRY=$'\033[38;5;245m'; C_ORG=$'\033[38;5;215m'
    C_HL=$'\033[48;5;179m\033[38;5;16m'
  else
    C_RESET=; C_DIM=; C_B=; C_IT=; C_RED=; C_GRN=; C_YEL=; C_BLU=; C_MAG=; C_CYA=
    C_GRY=; C_ORG=; C_HL=
  fi
  ui_awk_init
  ui_cols
}

ui_cols() {
  UI_COLS=$(tput cols 2>/dev/null || echo 0)
  [[ "$UI_COLS" =~ ^[0-9]+$ ]] && (( UI_COLS > 0 )) || UI_COLS="${COLUMNS:-72}"
  (( UI_COLS > 100 )) && UI_COLS=100
  (( UI_COLS < 32 )) && UI_COLS=32
  UI_ROWS=$(tput lines 2>/dev/null || echo 0)
  [[ "$UI_ROWS" =~ ^[0-9]+$ ]] && (( UI_ROWS > 0 )) || UI_ROWS="${LINES:-24}"
  UI_NARROW=0; (( UI_COLS < 60 )) && UI_NARROW=1
}

# Ширина и обрезка считаются по символам, а не по байтам. Termux'ный gawk в
# UTF-8-локали умеет это сам, но отказывается компилировать байтовые диапазоны;
# mawk наоборот. Поэтому определяем на старте, кто перед нами, и берём свой вариант.
ui_awk_init() {
  if [[ "$(awk 'BEGIN{print length("ы")}' 2>/dev/null)" == "1" ]]; then
    # awk считает символы сам (gawk в UTF-8)
    UAWK_LIB='
function ulen(s) { return length(s) }
function utrunc(s, n) { return substr(s, 1, n) }
function upad(s, n,   k, out) { out = s; k = n - length(s); while (k-- > 0) out = out " "; return out }
'
  else
    # awk считает байты (mawk, busybox): считаем ведущие байты UTF-8 сами
    UAWK_LIB='
function ulen(s,   t) { t = s; gsub(/[\200-\277]/, "", t); return length(t) }
function utrunc(s, n,   out, i, c, cnt, L) {
  cnt = 0; out = ""; L = length(s)
  for (i = 1; i <= L; i++) {
    c = substr(s, i, 1)
    if (c ~ /[\200-\277]/) { if (cnt > 0) out = out c; continue }
    if (cnt >= n) break
    cnt++; out = out c
  }
  return out
}
function upad(s, n,   k, out) { out = s; k = n - ulen(s); while (k-- > 0) out = out " "; return out }
'
  fi
}

# Обрезка без запуска процессов — для горячих путей: перерисовка списков,
# вывод инструментов, всё, что выполняется десятками раз подряд.
# В UTF-8-локали bash режет строки по символам, и ta её выставляет сам.
str_trunc() {
  local s="$1" n="$2"
  (( ${#s} > n )) && printf '%s' "${s:0:n}" || printf '%s' "$s"
}

# Обрезка потока: printf '…' | ui_trunc 40
ui_trunc() {
  awk -v N="${1:-40}" "$UAWK_LIB"'{ printf "%s", utrunc($0, N) }'
}

# Перенос по словам с сохранением отступа, по символам.
ui_wrap() {
  awk -v W="${1:-72}" "$UAWK_LIB"'
    {
      line = $0
      match(line, /^[ \t]*/); ind = substr(line, 1, RLENGTH)
      body = substr(line, RLENGTH+1)
      if (body == "") { print ind; next }
      n = split(body, w, " ")
      cur = ""
      for (i = 1; i <= n; i++) {
        if (w[i] == "") continue
        cand = (cur == "" ? w[i] : cur " " w[i])
        if (ulen(cand) + ulen(ind) > W && cur != "") { print ind cur; cur = w[i] }
        else cur = cand
      }
      print ind cur
    }'
}

ui_rule() {
  local line=""
  printf -v line '%*s' "$UI_COLS" ''
  printf '%s%s%s\n' "$C_DIM" "${line// /─}" "$C_RESET"
}

ui_mode_label() {
  case "${TA_MODE:-normal}" in
    plan) printf '%sплан — только чтение%s' "$C_BLU" "$C_RESET" ;;
    auto)  printf '%sавто — без подтверждений%s' "$C_ORG" "$C_RESET" ;;
    full)  printf '%sполный авто — опасное не спрашивает, необратимое спросит%s' "$C_RED" "$C_RESET" ;;
    guard) printf '%sревизор — опасное отклоняет модель%s' "$C_MAG" "$C_RESET" ;;
    *)     printf '%sобычный%s' "$C_GRN" "$C_RESET" ;;
  esac
}

# Приглашение ввода. Цвет полоски = режим, чтобы он был виден всегда.
ui_prompt() {
  local bar
  case "${TA_MODE:-normal}" in
    plan) bar="$C_BLU" ;; auto) bar="$C_ORG" ;; full) bar="$C_RED" ;; guard) bar="$C_MAG" ;; *) bar="$C_GRN" ;;
  esac
  printf '\n%s%s❯%s ' "$bar" "$C_B" "$C_RESET"
}

ui_banner() {
  printf '\n'
  printf ' %s%s▞▚%s %stermux-agent%s %sv%s%s\n' "$C_CYA" "$C_B" "$C_RESET" "$C_B" "$C_RESET" "$C_DIM" "$TA_VERSION" "$C_RESET"
  printf '    %s%s · %s%s\n' "$C_DIM" "$TA_PROFILE" "$TA_MODEL" "$C_RESET"
  printf '    %sрежим:%s %b %sмышление:%s %s %sмысли:%s %s\n' \
    "$C_DIM" "$C_RESET" "$(ui_mode_label)" \
    "$C_DIM" "$C_RESET" "${TA_REASONING:-off}" \
    "$C_DIM" "$C_RESET" "$( (( ${TA_SHOW_THINKING:-0} == 1 )) && echo 'видны' || echo 'скрыты' )"
  printf '    %s/help — команды · /exit — выход%s\n\n' "$C_DIM" "$C_RESET"
}

ui_info() { printf '%s•%s %s\n' "$C_BLU" "$C_RESET" "$*"; }
ui_ok()   { printf '%s✓%s %s\n' "$C_GRN" "$C_RESET" "$*"; }
ui_warn() { printf '%s!%s %s\n' "$C_YEL" "$C_RESET" "$*"; }
ui_err()  { printf '%s✗%s %s%s%s\n' "$C_RED" "$C_RESET" "$C_RED" "$*" "$C_RESET"; }
ui_dim()  { printf '%s%s%s\n' "$C_DIM" "$*" "$C_RESET"; }

ui_user() { printf '%s%s▶%s %s%s%s\n' "$C_GRN" "$C_B" "$C_RESET" "$C_GRN" "$1" "$C_RESET"; }

ui_tool_head() {
  local name="$1" summary="$2" w=$(( UI_COLS - 6 - ${#name} ))
  (( w < 8 )) && w=8
  summary="$(str_trunc "${summary//$'\n'/ }" "$w")"
  printf '\n%s%s⚙ %s%s %s%s%s\n' "$C_MAG" "$C_B" "$name" "$C_RESET" "$C_GRY" "$summary" "$C_RESET"
}

ui_tool_body() {
  local text="$1" max="${2:-10}" n=0 l total
  total="$(printf '%s\n' "$text" | grep -c '')"
  while IFS= read -r l; do
    (( n++ ))
    if (( n > max )); then
      printf '  %s│ … ещё %s строк — модель видит целиком%s\n' "$C_DIM" "$(( total - max ))" "$C_RESET"
      break
    fi
    printf '  %s│%s %s%s%s\n' "$C_DIM" "$C_RESET" "$C_GRY" "$(str_trunc "$l" $(( UI_COLS - 4 )))" "$C_RESET"
  done <<< "$text"
}

ui_thinking() {
  local text="$1" secs="$2" toks="$3"
  local meta="думал ${secs}с"
  [[ -n "$toks" && "$toks" != "0" ]] && meta="$meta · $toks ток"
  if (( ${TA_SHOW_THINKING:-0} == 0 )); then
    printf '%s💭 %s · /thinking — показать%s\n' "$C_DIM" "$meta" "$C_RESET"
    return
  fi
  printf '%s💭 %s%s\n' "$C_DIM" "$meta" "$C_RESET"
  printf '%s\n' "$text" | ui_wrap $(( UI_COLS - 4 )) | while IFS= read -r l; do
    printf '  %s│ %s%s\n' "$C_DIM" "$l" "$C_RESET"
  done
}

# ── статус-строка ───────────────────────────────────────────────────────────
# ui_status <фаза> [деталь]. Фазы, их анимации и фразы — в lib/fun.sh.
#
# Пока крутится спиннер, в терминал не должен писать никто другой: он каждые
# 100 мс делает \r и стирает строку. Инструменты, которые сами рисуют на экране
# (todo, ask_user), запускаются без спиннера — раньше их вывод налезал на строку
# статуса, и в фазе инструмента змейка «съезжала» вместе с текстом.
STATUS_PID=""
ui_status() {
  { : < /dev/tty; } 2>/dev/null || return 0
  ui_status_stop
  local state="$1" detail="${2:-}" label color frames
  label="$(fun_label "$state" 2>/dev/null || printf '%s' "$state")"
  case "$state" in
    think)                  color="$C_MAG" ;;
    api|write|models|conn)  color="$C_CYA" ;;
    call|bash|tool)         color="$C_YEL" ;;
    net)                    color="$C_BLU" ;;
    read)                   color="$C_GRN" ;;
    edit)                   color="$C_ORG" ;;
    subs)                   color="$C_MAG" ;;
    guard)                  color="$C_GRN" ;;
    compact)                color="$C_BLU" ;;
    offline)                color="$C_RED" ;;
    *)                      color="$C_CYA" ;;
  esac
  frames="$(fun_frames "$state" 2>/dev/null)"
  [[ -n "$frames" ]] || frames='⠋|⠙|⠚|⠞|⠖|⠦|⠴|⠲|⠳|⠓'

  # Termux не даёт прокручивать экран, пока внизу постоянно меняются символы.
  # Со статичным статусом строка печатается один раз и уходит в историю.
  if [[ "$(cfg_setting animation true)" == "false" ]]; then
    local one="$label"; [[ -n "$detail" ]] && one="$label: $detail"
    printf '%s⋯ %s…%s\n' "$color" "$(str_trunc "$one" $(( UI_COLS - 3 )))" "$C_RESET" >/dev/tty
    STATUS_PID=""
    return 0
  fi

  local fun=0
  fun_on 2>/dev/null && fun=1

  ( trap - EXIT INT HUP WINCH; trap 'exit 0' TERM
    local -a F=()
    IFS='|' read -r -a F <<< "$frames"
    local nf=${#F[@]} fw=${#F[0]} i=0 t0=$SECONDS e phrase tick=0 max body suffix
    # Пауза без запуска процесса: read с таймаутом из канала, в который никто
    # не пишет. sleep 0.1 — это десять fork в секунду, телефону это заметно.
    local nap=0
    { exec 9<> <(:); } 2>/dev/null && nap=1
    phrase="$label"
    (( fun == 1 )) && phrase="$(fun_phrase "$state")"
    printf '\033[?25l' >/dev/tty      # курсор не мигает поверх анимации
    while :; do
      e=$(( SECONDS - t0 )); (( tick++ ))
      # каждые ~6 секунд новая фраза, чтобы не примелькалась
      if (( fun == 1 && tick % 60 == 0 )); then phrase="$(fun_phrase "$state")"; fi
      suffix="${e}с"
      [[ -n "$detail" ]] && suffix="$detail · ${e}с"
      (( e >= 3 )) && suffix="$suffix · Ctrl+C — прервать"
      body="$phrase… ($suffix)"
      # строка обязана поместиться в экран целиком: если она перенесётся,
      # \r затрёт только последний кусок, и остальное останется мусором
      max=$(( UI_COLS - fw - 2 ))
      (( ${#body} > max )) && body="${body:0:$max}"
      printf '\r\033[K%s%s%s %s%s%s' \
        "$color" "${F[i]}" "$C_RESET" "$C_DIM" "$body" "$C_RESET" >/dev/tty
      i=$(( (i + 1) % nf ))
      if (( nap == 1 )); then read -r -t 0.1 -u 9 _ 2>/dev/null; else sleep 0.1; fi
    done ) &
  # Не disown: отвязанный процесс bash потом не узнаёт при сборе завершившихся
  # детей и печатает «wait_for: No record of process» посреди вывода.
  STATUS_PID=$!
}

# Совместимость: произвольная надпись без состояния.
ui_status_start() { ui_status "${2:-api}" "${1:-}"; }

ui_status_stop() {
  [[ -n "$STATUS_PID" ]] || return 0
  kill "$STATUS_PID" 2>/dev/null
  { wait "$STATUS_PID"; } 2>/dev/null
  STATUS_PID=""
  { : < /dev/tty; } 2>/dev/null && printf '\r\033[K\033[?25h' >/dev/tty
  return 0
}

ui_state_line() {
  case "$1" in
    wait)    printf '%s◉ ждёт указаний%s %s%s%s\n' "$C_GRN" "$C_RESET" "$C_DIM" "${2:-}" "$C_RESET" ;;
    offline) printf '%s◉ нет связи с API%s %s%s%s\n' "$C_RED" "$C_RESET" "$C_DIM" "${2:-}" "$C_RESET" ;;
    *)       printf '%s◉ %s%s %s\n' "$C_CYA" "$1" "$C_RESET" "${2:-}" ;;
  esac
}

ui_metrics() {
  local secs="$1" out="$2" total="$3" tps="" line
  [[ "${TA_SHOW_STATS:-1}" == "1" ]] || return 0
  if [[ -n "$out" && "$out" != "0" ]]; then
    tps="$(awk -v t="$out" -v s="$secs" 'BEGIN{ if (s+0>0) printf "%.0f", t/s }')"
  fi
  line="⏱ ${secs}с"
  [[ -n "$out" && "$out" != "0" ]] && line="$line · ${out} ток"
  [[ -n "$tps" && "$tps" != "0" ]] && line="$line · ${tps} т/с"
  [[ -n "$total" && "$total" != "0" ]] && line="$line · контекст ${total}"
  printf '%s%s%s\n' "$C_DIM" "$line" "$C_RESET"
}

# ── markdown ────────────────────────────────────────────────────────────────
# Заголовки, списки, цитаты, **жирный**, `код`, ```блоки```, !!важное!! (инверсия),
# автоцвет строк, начинающихся с ✓ ✗ ! ⚠ →
ui_md() {
  awk -v W="$UI_COLS" -v NARROW="${UI_NARROW:-0}" \
    -v R="$C_RESET" -v B="$C_B" -v D="$C_DIM" -v G="$C_GRN" -v Y="$C_YEL" \
    -v C="$C_CYA" -v RD="$C_RED" -v HL="$C_HL" -v GY="$C_GRY" "$UAWK_LIB"'
    function trim(s) { gsub(/^[ \t]+|[ \t]+$/, "", s); return s }
    function plain(s) {   # убрать разметку, чтобы считать ширину колонок
      gsub(/\*\*/, "", s); gsub(/`/, "", s); gsub(/!!/, "", s); return s
    }
    function fmt(s) {     # подсветка внутри строки
      gsub(/!![^!]+!!/, HL "&" R, s); gsub(/!!/, "", s)
      gsub(/\*\*[^*]+\*\*/, B "&" R, s); gsub(/\*\*/, "", s)
      gsub(/`[^`]+`/, Y "&" R, s); gsub(/`/, "", s)
      return s
    }
    function pad(s, n,   k, out) {   # добить пробелами по символам
      out = s; k = n - ulen(plain(s))
      while (k-- > 0) out = out " "
      return out
    }
    function wrap(s,   ind, body, n, w, i, cur, cand) {
      match(s, /^[ \t]*/); ind = substr(s, 1, RLENGTH); body = substr(s, RLENGTH+1)
      if (body == "") { print ind; return }
      n = split(body, w, " "); cur = ""
      for (i = 1; i <= n; i++) {
        if (w[i] == "") continue
        cand = (cur == "" ? w[i] : cur " " w[i])
        if (ulen(plain(cand)) + ulen(ind) > W && cur != "") { print ind fmt(cur); cur = w[i] }
        else cur = cand
      }
      print ind fmt(cur)
    }
    # ── таблицы ──────────────────────────────────────────────────────────────
    function tflush(   i, j, nc, cells, wsum, line, sep, out, r, c, maxw) {
      if (tn == 0) return
      nc = 0
      for (i = 1; i <= tn; i++) {
        split(trow[i], cells, "|")
        if (tcols[i] > nc) nc = tcols[i]
      }
      for (c = 1; c <= nc; c++) { maxw = 0
        for (r = 1; r <= tn; r++) { if (ulen(plain(tcell[r, c])) > maxw) maxw = ulen(plain(tcell[r, c])) }
        cw[c] = maxw
      }
      wsum = 0; for (c = 1; c <= nc; c++) wsum += cw[c] + 3
      if (NARROW == 1 || wsum > W) {          # узкий экран: строки списком
        for (r = 2; r <= tn; r++) {
          out = ""
          for (c = 1; c <= nc; c++) {
            if (tcell[r, c] == "") continue
            if (c == 1) print "  " B fmt(tcell[r, c]) R
            else        print "    " D plain(tcell[1, c]) ": " R fmt(tcell[r, c])
          }
          if (r < tn) print ""
        }
      } else {
        for (r = 1; r <= tn; r++) {
          line = "  "
          for (c = 1; c <= nc; c++) line = line (r == 1 ? B pad(tcell[r, c], cw[c]) R : pad(fmt(tcell[r, c]), cw[c])) "  "
          print line
          if (r == 1) { sep = "  "
            for (c = 1; c <= nc; c++) { j = cw[c]; while (j-- > 0) sep = sep "─"; sep = sep "  " }
            print D sep R
          }
        }
      }
      tn = 0
    }
    function tpush(line,   parts, i, n, cnt) {
      sub(/^[ \t]*\|/, "", line); sub(/\|[ \t]*$/, "", line)
      if (line ~ /^[ \t:|-]+$/) return          # строка-разделитель ---|---
      n = split(line, parts, "|")
      tn++; cnt = 0
      for (i = 1; i <= n; i++) { cnt++; tcell[tn, cnt] = trim(parts[i]) }
      tcols[tn] = cnt; trow[tn] = line
    }
    BEGIN { incode = 0; tn = 0 }
    {
      line = $0
      if (line ~ /^[ \t]*\|/ && incode == 0) { tpush(line); next }
      if (tn > 0) tflush()

      if (line ~ /^[ \t]*```/) {
        incode = !incode
        if (incode) { lang = line; sub(/^[ \t]*```/, "", lang); printf "%s┌─ %s%s\n", D, (lang == "" ? "код" : lang), R }
        else printf "%s└─%s\n", D, R
        next
      }
      if (incode) { printf "%s│%s %s%s%s\n", D, R, G, utrunc(line, W - 2), R; next }

      if (line ~ /^#{1,6} /)   { sub(/^#+ /, "", line); printf "\n%s%s%s%s\n", B, C, line, R; next }
      if (line ~ /^[ \t]*> /)  { sub(/^[ \t]*> /, "", line); printf "%s│ %s%s\n", GY, fmt(line), R; next }
      if (line ~ /^[ \t]*---+[ \t]*$/) { printf "%s────────%s\n", D, R; next }

      sub(/^[ \t]*[-*] /, "  • ", line)
      if (line ~ /^[ \t]*✓/) { printf "%s%s%s\n", G, fmt(line), R; next }
      if (line ~ /^[ \t]*✗/) { printf "%s%s%s\n", RD, fmt(line), R; next }
      if (line ~ /^[ \t]*(!|⚠)/) { printf "%s%s%s\n", Y, fmt(line), R; next }
      if (line ~ /^[ \t]*→/) { printf "%s%s%s\n", C, fmt(line), R; next }
      wrap(line)
    }
    END { if (tn > 0) tflush() }'
}
