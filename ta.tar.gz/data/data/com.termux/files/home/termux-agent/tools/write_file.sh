#!/usr/bin/env bash
tool_meta() {
cat <<'JSON'
{
  "name": "write_file",
  "description": "Создать файл или полностью перезаписать его содержимым. Каталоги создаются автоматически, существующий файл сохраняется в .bak.",
  "parameters": {
    "type": "object",
    "properties": {
      "path": {"type": "string", "description": "Путь к файлу"},
      "content": {"type": "string", "description": "Полное содержимое файла"},
      "intent": {"type": "string", "description": "ОБЯЗАТЕЛЬНО. Что за файл и зачем его создаём/перезаписываем"},
      "append": {"type": "boolean", "description": "Дописать в конец вместо перезаписи"},
      "executable": {"type": "boolean", "description": "Сделать файл исполняемым"}
    },
    "required": ["path", "content", "intent"]
  },
  "x_confirm": true,
  "x_writes": true
}
JSON
}

tool_run() {
  local p c
  p="$(expand_path "$(arg path)")"; [[ -n "$p" ]] || die "не указан path"
  # хвостовые переводы строк не должны теряться при подстановке
  c="$(jq -r '.content // ""' <<<"$TA_TOOL_ARGS"; printf X)"; c="${c%X}"
  mkdir -p "$(dirname "$p")" || die "не создать каталог"
  ckpt_save "$p"
  if [[ "$(arg append false)" == "true" ]]; then
    printf '%s' "$c" >> "$p" || die "не записать"
    printf 'дописано в %s (+%d байт)' "$p" "${#c}"
  else
    [[ -f "$p" ]] && cp "$p" "$p.bak"
    printf '%s\n' "$p" >> "${TA_UNDO_LOG:-/dev/null}" 2>/dev/null
    printf '%s' "$c" > "$p" || die "не записать"
    printf 'записано %s (%d байт, строк: %d)' "$p" "${#c}" "$(wc -l < "$p")"
  fi
  [[ "$(arg executable false)" == "true" ]] && chmod +x "$p" && printf ' [+x]'
  return 0
}
