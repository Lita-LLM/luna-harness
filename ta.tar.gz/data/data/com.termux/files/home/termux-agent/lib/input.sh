#!/usr/bin/env bash
# lib/input.sh — клавиатура во время работы агента.
#
# Пока агент думает или выполняет команду, можно:
#   • печатать — строка уйдёт агенту следующим шагом (Enter отправляет в очередь);
#   • нажать Esc дважды подряд — прервать текущий запрос или команду.
# Если в очереди что-то есть, после прерывания агент сразу получит это и продолжит.

TA_WATCH_PID=""

input_files() {
  TA_ABORT_FILE="$TA_TMP/abort"
  TA_QUEUE_FILE="$TA_TMP/queue"
  TA_TYPING_FILE="$TA_TMP/typing"
}

input_aborted() { [[ -f "${TA_ABORT_FILE:-/nonexistent}" ]]; }
input_abort_clear() { rm -f "${TA_ABORT_FILE:-}" "${TA_TYPING_FILE:-}"; }
input_abort_set() { touch "${TA_ABORT_FILE:-/dev/null}" 2>/dev/null; }

# Запустить слежение за клавиатурой (только когда есть терминал).
input_watch_start() {
  # По умолчанию выключено. Механика перехватывает клавиатуру в сыром режиме,
  # и любая её ошибка означает «печатаю вслепую, и непонятно, куда уходит ввод».
  # Включается осознанно: ta set type_while_working true
  [[ "$(cfg_setting type_while_working false)" == "true" ]] || return 0
  [[ -n "$TA_WATCH_PID" ]] && return 0
  { : < /dev/tty; } 2>/dev/null || return 0
  input_files
  : >> "$TA_QUEUE_FILE"
  ( # read -rsn1 переводит терминал в сырой режим. Если процесс убить прямо
    # посреди чтения, режим таким и останется — экран перестанет показывать ввод
    # даже после выхода из программы. Поэтому восстанавливаем всегда.
    local _st=""
    _st="$(stty -g < /dev/tty 2>/dev/null)"
    _restore() { [[ -n "$_st" ]] && stty "$_st" < /dev/tty 2>/dev/null; }
    trap '_restore; exit 0' TERM INT HUP EXIT
    local ch buf="" last_esc=0 now
    while :; do
      IFS= read -rsn1 -t 0.3 ch </dev/tty || continue
      case "$ch" in
        $'\e')
          now="$(date +%s%3N 2>/dev/null || printf '%s000' "$(date +%s)")"
          if (( now - last_esc < 1500 )); then
            printf '\r\033[K  %sпрерываю…%s\n' "${C_RED:-}" "${C_RESET:-}" >/dev/tty
            touch "$TA_ABORT_FILE"; buf=""; last_esc=0
            rm -f "$TA_TYPING_FILE"
          else
            last_esc="$now"
            printf '\r\033[K  %sEsc ещё раз — прервать%s' "${C_DIM:-}" "${C_RESET:-}" >/dev/tty
          fi ;;
        "")
          if [[ -n "$buf" ]]; then
            printf '%s\n' "$buf" >> "$TA_QUEUE_FILE"
            printf '\r\033[K  %s→ уйдёт агенту следующим шагом%s\n' "${C_GRN:-}" "${C_RESET:-}" >/dev/tty
            buf=""; rm -f "$TA_TYPING_FILE"
          fi ;;
        $'\x7f'|$'\b')
          buf="${buf%?}"
          printf '\r\033[K  %s%s%s' "${C_DIM:-}" "$buf" "${C_RESET:-}" >/dev/tty ;;
        *)
          buf+="$ch"; touch "$TA_TYPING_FILE"
          printf '\r\033[K  %s%s%s' "${C_DIM:-}" "$buf" "${C_RESET:-}" >/dev/tty ;;
      esac
    done ) &
  TA_WATCH_PID=$!
  disown 2>/dev/null
}

input_watch_stop() {
  [[ -n "$TA_WATCH_PID" ]] || return 0
  kill "$TA_WATCH_PID" 2>/dev/null; wait "$TA_WATCH_PID" 2>/dev/null
  TA_WATCH_PID=""
  # подстраховка на случай, если дочерний процесс не успел прибраться
  tty_restore
  [[ -t 1 ]] && printf '\r\033[K'
  return 0
}

# Забрать накопленное в массив TA_QUEUE.
input_collect() {
  input_files
  [[ -s "${TA_QUEUE_FILE:-}" ]] || return 0
  local l
  while IFS= read -r l; do
    [[ -n "${l// }" ]] && TA_QUEUE+=("$l")
  done < "$TA_QUEUE_FILE"
  : > "$TA_QUEUE_FILE"
}

input_queue_pending() { [[ -s "${TA_QUEUE_FILE:-/nonexistent}" ]] || (( ${#TA_QUEUE[@]} > 0 )); }

# Убить процесс вместе со всем его потомством.
kill_tree() {
  local pid="$1" child
  for child in $(pgrep -P "$pid" 2>/dev/null); do kill_tree "$child"; done
  kill -TERM "$pid" 2>/dev/null
}

# Запустить команду в фоне и ждать, поглядывая на флаг прерывания.
# Возврат: код команды, либо 130 если прервали.
run_interruptible() {
  local pid rc
  "$@" &
  pid=$!
  while kill -0 "$pid" 2>/dev/null; do
    if input_aborted; then
      kill_tree "$pid"
      wait "$pid" 2>/dev/null
      return 130
    fi
    sleep 0.12
  done
  wait "$pid"; rc=$?
  return $rc
}

# ── режим терминала ─────────────────────────────────────────────────────────
# Снимок делается один раз при старте, восстановление — при любом выходе.
tty_snapshot() {
  { : < /dev/tty; } 2>/dev/null || return 0
  TA_STTY="$(stty -g < /dev/tty 2>/dev/null)"; export TA_STTY
}
tty_restore() {
  { : < /dev/tty; } 2>/dev/null || return 0
  if [[ -n "${TA_STTY:-}" ]]; then stty "$TA_STTY" < /dev/tty 2>/dev/null
  else stty sane < /dev/tty 2>/dev/null; fi
  printf '\033[?25h' > /dev/tty 2>/dev/null || true
  return 0
}
