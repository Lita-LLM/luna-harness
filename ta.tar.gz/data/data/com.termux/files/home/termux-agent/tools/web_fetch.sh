#!/usr/bin/env bash
# Чтение страницы: HTML → чистый текст, для GitHub/StackOverflow/npm/PyPI — через их API.
# Вся механика в lib/web.sh; здесь только аргументы и подача результата.

tool_meta() {
cat <<'JSON'
{
  "name": "web_fetch",
  "description": "Прочитать страницу по URL как текст. GitHub (файлы, README, issues, релизы), StackOverflow, npm и PyPI читаются через API — чисто и коротко. Длинная страница: find — только куски вокруг нужных слов; offset — читать дальше. Повторное чтение той же страницы берётся из кэша.",
  "parameters": {
    "type": "object",
    "properties": {
      "url": {"type": "string"},
      "find": {"type": "string", "description": "Слова или текст ошибки: вернуть только фрагменты, где они встречаются"},
      "offset": {"type": "integer", "description": "С какого символа читать (для продолжения)"},
      "max_chars": {"type": "integer", "description": "Сколько символов вернуть, по умолчанию 6000"},
      "links": {"type": "boolean", "description": "Пометить ссылки [N] и перечислить их адреса в конце"}
    },
    "required": ["url"]
  }
}
JSON
}

tool_run() {
  source "$TA_HOME/lib/web.sh"
  local url max off find links raw status text total
  url="$(arg url)"; [[ -n "$url" ]] || die "не указан url"
  case "$url" in http://*|https://*) ;; *) url="https://$url" ;; esac
  max="$(arg max_chars 6000)"; [[ "$max" =~ ^[0-9]+$ ]] || max=6000; 
  # больше лимита вывода инструмента всё равно уйдёт в файл — лучше листать offset
  local cap=$(( ${TA_OUT_LIMIT:-8000} - 500 )); (( cap < 2000 )) && cap=2000; (( max > cap )) && max=$cap
  off="$(arg offset 0)";      [[ "$off" =~ ^[0-9]+$ ]] || off=0
  find="$(arg find)"
  links="$(arg links false)"
  have curl || die "нет curl: pkg install curl"

  if [[ "$links" == "true" ]]; then
    # ссылки меняют текст, поэтому у такого чтения свой ключ кэша
    raw="$(WEB_LINKS=1 WEB_CACHE="$WEB_CACHE/links" web_read "$url")"
  else
    raw="$(web_read "$url")"
  fi
  status="$(head -1 <<<"$raw")"; status="${status#@@ }"
  text="$(tail -n +2 <<<"$raw")"
  total=${#text}

  printf 'URL: %s\n%s · %d символов\n---\n' "$url" "$status" "$total"
  case "$status" in HTTP\ 4*|HTTP\ 5*|HTTP\ 000*) printf '(сайт вернул ошибку — ниже то, что он показал)\n' ;; esac
  if (( total < 40 )) && [[ "$status" == *html* ]]; then
    printf '(текста почти нет: страница, видимо, собирается JavaScript-ом или закрыта от ботов.\n Попробуй другой источник: API сайта, raw-файл, GitHub, или web_search с read)\n'
  fi

  if [[ -n "$find" ]]; then
    local frag
    if frag="$(printf '%s\n' "$text" | web_fragments "$find" "$max")" && [[ -n "$frag" ]]; then
      printf 'Фрагменты со словами «%s»:\n\n%s\n' "$find" "$frag"
    else
      printf 'Слов «%s» на странице нет. Начало страницы:\n\n%s\n' "$find" "${text:0:1500}"
    fi
    return 0
  fi

  printf '%s' "${text:$off:$max}"
  if (( off + max < total )); then
    printf '\n...[показано %d–%d из %d; дальше: offset=%d, или find — искать нужное]' \
      "$off" "$(( off + max ))" "$total" "$(( off + max ))"
  fi
  return 0
}
