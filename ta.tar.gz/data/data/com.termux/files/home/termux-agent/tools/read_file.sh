#!/usr/bin/env bash
tool_meta() {
cat <<'JSON'
{
  "name": "read_file",
  "description": "Прочитать текстовый файл с нумерацией строк. Поддерживает чтение фрагмента через offset/limit — используй для больших файлов (логи, конфиги).",
  "parameters": {
    "type": "object",
    "properties": {
      "path": {"type": "string", "description": "Путь к файлу"},
      "offset": {"type": "integer", "description": "С какой строки начать (с 1)"},
      "limit": {"type": "integer", "description": "Сколько строк вернуть (по умолчанию 400)"}
    },
    "required": ["path"]
  }
}
JSON
}

tool_run() {
  local p off lim total
  p="$(expand_path "$(arg path)")"; [[ -n "$p" ]] || die "не указан path"
  [[ -e "$p" ]] || die "нет такого файла: $p"
  [[ -d "$p" ]] && die "$p — каталог, используй list_dir"
  if have file && file -b --mime-encoding "$p" 2>/dev/null | grep -q binary; then
    die "$p — бинарный файл ($(du -h "$p" | cut -f1))"
  fi
  off="$(arg offset 1)"; [[ "$off" =~ ^[0-9]+$ ]] || off=1; (( off < 1 )) && off=1
  lim="$(arg limit 400)"; [[ "$lim" =~ ^[0-9]+$ ]] || lim=400
  total="$(wc -l < "$p")"
  printf '%s (строк: %s)\n' "$p" "$total"
  sed -n "${off},$((off+lim-1))p" "$p" | nl -ba -v "$off" -w6 -s' | '
  (( off + lim - 1 < total )) && printf '...ещё %d строк ниже (offset=%d)\n' "$(( total - off - lim + 1 ))" "$(( off + lim ))"
  return 0
}
