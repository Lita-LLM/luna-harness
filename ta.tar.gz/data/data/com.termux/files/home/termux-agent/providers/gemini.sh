#!/usr/bin/env bash
# Провайдер Google Gemini (generateContent, с thinkingConfig).

source "${TA_HOME:?}/lib/histfix.sh"

_gem_budget() {
  case "${TA_REASONING:-off}" in
    low) echo 1024 ;; medium) echo 8192 ;; high) echo 24576 ;; *) echo 0 ;;
  esac
}

provider_request() {
  local budget; budget="$(_gem_budget)"
  jq -n --slurpfile h "$1" --slurpfile t "$2" \
        --argjson temp "$TA_TEMPERATURE" \
        --argjson maxtok "$TA_MAX_TOKENS" \
        --argjson budget "$budget" \
        --argjson extra "$TA_EXTRA_BODY" "$HISTFIX_JQ"'
    def clean: walk(if type == "object" then del(.additionalProperties, .["$schema"]) else . end);
    def parts:
      if .role == "assistant" then
        ((if (.content // "") == "" then [] else [{text: .content}] end)
         + ((.tool_calls // []) | map({functionCall: {name: .name, args: .arguments}})))
      elif .role == "tool" then
        [{functionResponse: {name: .name, response: {result: (.content | tostring)}}}]
      else
        [{text: .content}]
      end;
    def grole: if .role == "assistant" then "model" else "user" end;
    {
      systemInstruction: {parts: [{text: ($h[0] | map(select(.role == "system") | .content) | join("\n\n"))}]},
      contents: ($h[0] | fixhist | map(select(.role != "system")) | map({role: grole, parts: parts})),
      tools: [{functionDeclarations: ($t[0] | clean | map({name: .name, description: .description, parameters: .parameters}))}],
      generationConfig: ({temperature: $temp, maxOutputTokens: $maxtok}
        + (if $budget > 0 then {thinkingConfig: {includeThoughts: true, thinkingBudget: $budget}} else {} end))
    }
    | (if ($t[0] | length) == 0 then del(.tools) else . end)
    | . * $extra'
}

provider_send() {
  local key; key="$(cfg_api_key)"
  local -a H=(-H 'Content-Type: application/json')
  [[ -n "$key" ]] && H+=(-H "x-goog-api-key: $key")
  local h; for h in "${TA_EXTRA_HEADERS[@]}"; do [[ -n "$h" ]] && H+=(-H "$h"); done
  curl -sS --max-time "$TA_HTTP_TIMEOUT" -X POST \
       "${TA_BASE_URL%/}/models/${TA_MODEL}:generateContent" \
       "${H[@]}" --data-binary @"$1" -o "$2" -w '%{http_code}'
}

provider_parse() {
  jq -c '
    ((.candidates[0].content.parts) // []) as $p |
    {
      role: "assistant",
      content: ([$p[] | select(has("text") and (.thought // false) == false) | .text] | join("\n")),
      reasoning: ([$p[] | select(has("text") and (.thought // false) == true) | .text] | join("\n")),
      tool_calls: [$p[] | select(has("functionCall"))
                   | {id: ("call_" + .functionCall.name), name: .functionCall.name, arguments: (.functionCall.args // {})}]
    }' "$1"
}

provider_usage() {
  jq -r '"\(.usageMetadata.candidatesTokenCount // 0) \(.usageMetadata.totalTokenCount // 0)"' "$1" 2>/dev/null || echo "0 0"
}

provider_error() { jq -r '(.error.message // .message // "неизвестная ошибка") | tostring' "$1" 2>/dev/null; }

# Потоковый режим для этого API пока не реализован: ответ приходит целиком.
provider_stream_supported() { return 1; }
