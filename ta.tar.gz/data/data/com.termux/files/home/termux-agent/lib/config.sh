#!/usr/bin/env bash
# lib/config.sh — профили моделей: хранение, переключение, мастер настройки.
# Списком моделей занимается lib/models.sh, выбором из списка — lib/select.sh.

TA_CFG_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/termux-agent"
TA_CFG="$TA_CFG_DIR/config.json"
TA_DATA_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/termux-agent"
TA_SESS_DIR="$TA_DATA_DIR/sessions"
TA_CKPT_DIR="$TA_DATA_DIR/checkpoints"
TA_USER_TOOLS="$TA_CFG_DIR/tools"

# имя|провайдер|base_url|модель по умолчанию|переменная с ключом|описание
TA_PRESET_LIST=(
  "openrouter|openai|https://openrouter.ai/api/v1|anthropic/claude-sonnet-4.5|OPENROUTER_API_KEY|сотни моделей одним ключом, есть бесплатные"
  "anthropic|anthropic|https://api.anthropic.com/v1|claude-sonnet-4-5|ANTHROPIC_API_KEY|Claude напрямую"
  "openai|openai|https://api.openai.com/v1|gpt-4.1-mini|OPENAI_API_KEY|GPT напрямую"
  "gemini|gemini|https://generativelanguage.googleapis.com/v1beta|gemini-2.0-flash|GEMINI_API_KEY|Google, щедрый бесплатный лимит"
  "groq|openai|https://api.groq.com/openai/v1|llama-3.3-70b-versatile|GROQ_API_KEY|очень быстрый, есть бесплатный лимит"
  "deepseek|openai|https://api.deepseek.com/v1|deepseek-chat|DEEPSEEK_API_KEY|дёшево и сильно в коде"
  "cerebras|openai|https://api.cerebras.ai/v1|llama-3.3-70b|CEREBRAS_API_KEY|самый быстрый инференс"
  "mistral|openai|https://api.mistral.ai/v1|mistral-large-latest|MISTRAL_API_KEY|европейский провайдер"
  "together|openai|https://api.together.xyz/v1|Qwen/Qwen2.5-72B-Instruct-Turbo|TOGETHER_API_KEY|много открытых моделей"
  "glm|openai|https://open.bigmodel.cn/api/paas/v4|glm-4-plus|GLM_API_KEY|Zhipu GLM"
  "ollama|openai|http://127.0.0.1:11434/v1|qwen2.5-coder:7b|NONE|локально на телефоне, без ключа"
  "lmstudio|openai|http://127.0.0.1:1234/v1|local-model|NONE|локальный сервер LM Studio"
  "llamacpp|openai|http://127.0.0.1:8080/v1|local-model|NONE|локальный llama.cpp server"
)

preset_field() {
  local p
  for p in "${TA_PRESET_LIST[@]}"; do
    [[ "${p%%|*}" == "$1" ]] && { cut -d'|' -f"$2" <<<"$p"; return 0; }
  done
  return 1
}

cfg_default_json() {
  cat <<'JSON'
{
  "current": null,
  "recent_models": [],
  "settings": {
    "auto_approve": false,
    "default_mode": "normal",
    "max_steps": 30,
    "temperature": 0.2,
    "max_tokens": 4096,
    "http_timeout": 180,
    "tool_output_limit": 8000,
    "disabled_tools": [],
    "search_engine": "duckduckgo",
    "search_api_key": "",
    "show_thinking": false,
    "show_stats": true,
    "fun": true
  },
  "profiles": {}
}
JSON
}

cfg_init() {
  mkdir -p "$TA_CFG_DIR" "$TA_SESS_DIR" "$TA_CKPT_DIR" "$TA_USER_TOOLS"
  [[ -f "$TA_CFG" ]] || { cfg_default_json > "$TA_CFG"; chmod 600 "$TA_CFG"; }
  cfg_migrate_stray_key
}

# До 2.8.3 «ta set api_key …» клал ключ в settings.api_key, который никто не
# читал. Переносим его в активный профиль — но только если у того нет своего
# ключа и переменной, чтобы не отправить ключ чужому хосту.
cfg_migrate_stray_key() {
  jq -e '(.settings.api_key // "") != "" and .current != null
         and (.profiles[.current] != null)
         and ((.profiles[.current].api_key // "") == "")
         and ((.profiles[.current].api_key_env // "NONE") | IN("NONE", ""))' \
     "$TA_CFG" >/dev/null 2>&1 || return 0
  local cur; cur="$(cfg_read '.current')"
  cfg_write '.profiles[.current].api_key = .settings.api_key | del(.settings.api_key)' \
    && ui_warn "ключ из settings.api_key перенесён в профиль «$cur»"
}

cfg_read()  { jq -r "$1" "$TA_CFG" 2>/dev/null; }
cfg_write() {
  local expr="$1"; shift
  local tmp; tmp="$(mktemp)"
  if jq "$@" "$expr" "$TA_CFG" > "$tmp" 2>/dev/null; then
    mv "$tmp" "$TA_CFG"; chmod 600 "$TA_CFG"
  else
    rm -f "$tmp"; ui_err "не удалось записать конфиг"; return 1
  fi
}

cfg_setting() {
  local v; v="$(cfg_read ".settings.$1 // empty")"
  [[ -n "$v" && "$v" != "null" ]] && printf '%s' "$v" || printf '%s' "$2"
}

cfg_load_profile() {
  local name="${1:-}"
  [[ -z "$name" ]] && name="$(cfg_read '.current // empty')"
  if [[ -z "$name" || "$name" == "null" ]]; then
    ui_err "профиль не выбран — запусти: ta setup"; return 1
  fi
  local p; p="$(jq -c --arg n "$name" '.profiles[$n] // empty' "$TA_CFG")"
  [[ -n "$p" ]] || { ui_err "профиль «$name» не найден (ta profile list)"; return 1; }

  TA_PROFILE="$name"
  TA_PROVIDER="$(jq -r '.provider // "openai"' <<<"$p")"
  TA_BASE_URL="$(jq -r '.base_url // empty' <<<"$p")"
  TA_MODEL="${TA_MODEL_OVERRIDE:-$(jq -r '.model // empty' <<<"$p")}"
  TA_KEY_ENV="$(jq -r '.api_key_env // empty' <<<"$p")"
  TA_KEY_RAW="$(jq -r '.api_key // empty' <<<"$p")"
  TA_EXTRA_BODY="$(jq -c '.extra_body // {}' <<<"$p")"
  TA_REASONING="${TA_REASONING_OVERRIDE:-$(jq -r '.reasoning // "off"' <<<"$p")}"
  mapfile -t TA_EXTRA_HEADERS < <(jq -r '(.extra_headers // [])[]' <<<"$p")

  TA_TEMPERATURE="$(cfg_setting temperature 0.2)"
  TA_MAX_TOKENS="$(cfg_setting max_tokens 4096)"
  TA_MAX_STEPS="${TA_MAX_STEPS_OVERRIDE:-$(cfg_setting max_steps 30)}"
  TA_HTTP_TIMEOUT="$(cfg_setting http_timeout 180)"
  TA_OUT_LIMIT="$(cfg_setting tool_output_limit 8000)"
  TA_MODE="${TA_MODE_OVERRIDE:-$(cfg_setting default_mode normal)}"
  [[ "$(cfg_setting auto_approve false)" == "true" ]] && TA_MODE="auto"
  [[ "${TA_AUTO_APPROVE_FLAG:-}" == "1" ]] && TA_MODE="auto"
  [[ "$(cfg_setting show_thinking false)" == "true" ]] && TA_SHOW_THINKING=1 || TA_SHOW_THINKING=0
  [[ "$(cfg_setting show_stats true)" == "true" ]] && TA_SHOW_STATS=1 || TA_SHOW_STATS=0
  TA_SEARCH_ENGINE="$(cfg_setting search_engine duckduckgo)"
  TA_SEARCH_KEY="$(cfg_setting search_api_key '')"
  export TA_SEARCH_ENGINE TA_SEARCH_KEY
  return 0
}

cfg_api_key() {
  if [[ -n "${TA_KEY_RAW:-}" && "$TA_KEY_RAW" != "null" ]]; then printf '%s' "$TA_KEY_RAW"; return; fi
  if [[ -n "${TA_KEY_ENV:-}" && "$TA_KEY_ENV" != "NONE" && "$TA_KEY_ENV" != "null" ]]; then
    printf '%s' "${!TA_KEY_ENV:-}"
  fi
}

cfg_profiles() { cfg_read '.profiles | keys[]'; }

# Пробный запрос: жив ли ключ и существует ли модель.
cfg_test_connection() {
  cfg_load_profile "${1:-}" >/dev/null || return 1
  provider_source || return 1
  local tmp; tmp="$(mktemp -d)"
  jq -n '[{role:"system",content:"Отвечай одним словом."},{role:"user",content:"скажи: готово"}]' > "$tmp/h.json"
  echo '[]' > "$tmp/t.json"
  ui_status conn
  provider_request "$tmp/h.json" "$tmp/t.json" > "$tmp/req.json" 2>/dev/null
  local code; code="$(provider_send "$tmp/req.json" "$tmp/resp.json")"
  ui_status_stop
  if [[ "$code" == "200" ]]; then
    ui_ok "связь есть: $TA_PROFILE · $TA_MODEL"
    rm -rf "$tmp"; return 0
  fi
  ui_err "API $code: $(str_trunc "$(provider_error "$tmp/resp.json" 2>/dev/null)" 200)"
  case "$code" in
    401|403) ui_dim "  ключ не принят — ta profile key $TA_PROFILE" ;;
    404)     ui_dim "  модель или base_url неверны — ta model" ;;
    000)     ui_dim "  нет сети или хост недоступен" ;;
  esac
  rm -rf "$tmp"; return 1
}

_setup_pick_reasoning() {
  printf 'off\tвыключить\tбыстрее и дешевле\nlow\tнизкий\tнемного подумать перед ответом\nmedium\tсредний\tбаланс скорости и качества\nhigh\tвысокий\tсложные задачи, заметно медленнее\n' \
    | ui_pick --title "Уровень рассуждений" --hint "работает только у моделей, которые это умеют"
}

_setup_pick_provider() {
  local p k pv url md env desc out=""
  for p in "${TA_PRESET_LIST[@]}"; do
    IFS='|' read -r k pv url md env desc <<< "$p"
    out+="$(printf '%s\t%s\t%s' "$k" "$k" "$desc")"$'\n'
  done
  out+="$(printf '%s\t%s\t%s' "__custom__" "свой" "любой другой OpenAI-совместимый URL")"$'\n'
  printf '%s' "$out" | ui_pick --title "Провайдер" --hint "↑↓ · печатай для поиска · Enter"
}

# ── мастер настройки ────────────────────────────────────────────────────────
cmd_setup() {
  cfg_init
  (( $# )) && { cmd_setup_flags "$@"; return $?; }
  if ! { : < /dev/tty; } 2>/dev/null; then
    ui_err "нет терминала для интерактивной настройки"
    ui_dim "используй флаги: ta setup --preset openrouter --key sk-…"
    return 1
  fi

  local preset provider base_url model keyenv name key="" reasoning
  preset="$(_setup_pick_provider)" || { ui_dim "отменено"; return 1; }

  if [[ "$preset" == "__custom__" ]]; then
    provider="$(printf 'openai\tOpenAI-совместимый\tбольшинство сервисов и локальных серверов\nanthropic\tAnthropic\tMessages API\ngemini\tGoogle Gemini\tgenerateContent\n' \
      | ui_pick --title "Тип API" --hint "чем говорит сервер")" || return 1
    base_url="$(ui_input 'Base URL:' 'https://')"
    keyenv="NONE"; model=""; preset="custom"
    # у своего сервиса нет известной переменной, но ключ ему обычно нужен
    printf '\n  %sAPI-ключ%s %s— ввод скрыт, Enter = без ключа (локальный сервер)%s\n' "$C_B" "$C_RESET" "$C_DIM" "$C_RESET"
    key="$(ui_input 'ключ:' '' secret)"
  else
    provider="$(preset_field "$preset" 2)"
    base_url="$(preset_field "$preset" 3)"
    model="$(preset_field "$preset" 4)"
    keyenv="$(preset_field "$preset" 5)"
    base_url="$(ui_input 'Base URL:' "$base_url")"
  fi

  if [[ "$keyenv" != "NONE" ]]; then
    printf '\n  %sAPI-ключ%s %s— ввод скрыт, Enter = брать из $%s%s\n' "$C_B" "$C_RESET" "$C_DIM" "$keyenv" "$C_RESET"
    key="$(ui_input 'ключ:' '' secret)"
    [[ -z "$key" && -z "${!keyenv:-}" ]] && ui_warn "ключа нет ни здесь, ни в \$$keyenv — запросы вернут 401"
  fi

  # модель тянем прямо из API выбранного провайдера
  local picked
  picked="$(models_pick "$provider" "$base_url" "${key:-${!keyenv:-}}")" && [[ -n "$picked" ]] && model="$picked"
  [[ -z "$model" ]] && model="$(ui_input 'Модель:' '')"

  reasoning="$(_setup_pick_reasoning)" || reasoning="off"
  name="$(ui_input 'Имя профиля:' "$preset")"

  cfg_write '
    .profiles[$n] = {provider:$p, base_url:$u, model:$m, api_key:$k, api_key_env:$e,
                     reasoning:$r, extra_headers:[], extra_body:{}}
    | .current = $n' \
    --arg n "$name" --arg p "$provider" --arg u "$base_url" --arg m "$model" \
    --arg k "$key" --arg e "$keyenv" --arg r "$reasoning" || return 1
  models_recent_add "$model"

  printf '\n'
  cfg_test_connection "$name" || ui_warn "профиль сохранён, но связь не проверена — поправь: ta setup"
  printf '\n%sГотово. Запускай:%s ta\n\n' "$C_DIM" "$C_RESET"
}

cmd_setup_flags() {
  local name="" preset="" provider="" base_url="" model="" key="" keyenv="NONE" reasoning="off"
  while (( $# )); do
    case "$1" in
      --name)      name="$2"; shift 2 ;;
      --preset)    preset="$2"; shift 2 ;;
      --provider)  provider="$2"; shift 2 ;;
      --base-url)  base_url="$2"; shift 2 ;;
      --model)     model="$2"; shift 2 ;;
      --key)       key="$2"; shift 2 ;;
      --key-env)   keyenv="$2"; shift 2 ;;
      --reasoning|--think) reasoning="$2"; shift 2 ;;
      *) ui_err "неизвестный флаг: $1"; return 1 ;;
    esac
  done
  if [[ -n "$preset" ]]; then
    preset_field "$preset" 1 >/dev/null || { ui_err "нет пресета «$preset» (ta profile presets)"; return 1; }
    provider="${provider:-$(preset_field "$preset" 2)}"
    base_url="${base_url:-$(preset_field "$preset" 3)}"
    model="${model:-$(preset_field "$preset" 4)}"
    [[ "$keyenv" == "NONE" ]] && keyenv="$(preset_field "$preset" 5)"
    name="${name:-$preset}"
  fi
  [[ -n "$name" && -n "$base_url" ]] || { ui_err "нужны --name и --base-url (или --preset)"; return 1; }
  cfg_write '
    .profiles[$n] = {provider:$p, base_url:$u, model:$m, api_key:$k, api_key_env:$e,
                     reasoning:$r, extra_headers:[], extra_body:{}}
    | .current = $n' \
    --arg n "$name" --arg p "${provider:-openai}" --arg u "$base_url" --arg m "$model" \
    --arg k "$key" --arg e "$keyenv" --arg r "$reasoning" \
    && ui_ok "профиль ${C_B}$name${C_RESET} сохранён и выбран активным"
}

# ── профили ─────────────────────────────────────────────────────────────────
cmd_profile() {
  local sub="${1:-list}"; shift || true
  case "$sub" in
    list|ls)
      local cur n pr md rs mark
      cur="$(cfg_read '.current // empty')"
      printf '\n'
      while IFS= read -r n; do
        [[ -z "$n" ]] && continue
        pr="$(jq -r --arg n "$n" '.profiles[$n].provider' "$TA_CFG")"
        md="$(jq -r --arg n "$n" '.profiles[$n].model' "$TA_CFG")"
        rs="$(jq -r --arg n "$n" '.profiles[$n].reasoning // "off"' "$TA_CFG")"
        [[ "$n" == "$cur" ]] && mark="${C_GRN}●${C_RESET}" || mark="${C_DIM}○${C_RESET}"
        printf ' %s %s%-12s%s %s%-9s%s %s' "$mark" "$C_B" "$n" "$C_RESET" "$C_DIM" "$pr" "$C_RESET" "$md"
        [[ "$rs" != "off" ]] && printf ' %s(think: %s)%s' "$C_DIM" "$rs" "$C_RESET"
        printf '\n'
      done < <(cfg_profiles)
      printf '\n' ;;
    use)
      local n="${1:-}"
      if [[ -z "$n" ]]; then
        local items="" p
        while IFS= read -r p; do
          [[ -z "$p" ]] && continue
          items+="$(printf '%s\t%s\t%s' "$p" "$p" "$(jq -r --arg n "$p" '.profiles[$n].model' "$TA_CFG")")"$'\n'
        done < <(cfg_profiles)
        [[ -n "$items" ]] || { ui_err "профилей нет"; return 1; }
        n="$(printf '%s' "$items" | ui_pick --title "Профиль" --hint "↑↓ · Enter")" || return 1
      fi
      jq -e --arg n "$n" '.profiles[$n]' "$TA_CFG" >/dev/null || { ui_err "нет профиля «$n»"; return 1; }
      cfg_write '.current = $n' --arg n "$n" && ui_ok "профиль: ${C_B}$n${C_RESET}" ;;
    show)
      local n="${1:-$(cfg_read '.current')}"
      jq --arg n "$n" '.profiles[$n] | .api_key = (if (.api_key//"")=="" then "" else "***" end)' "$TA_CFG" ;;
    del|rm)
      local n="${1:?укажи имя}"
      cfg_write 'del(.profiles[$n]) | (if .current == $n then .current = null else . end)' --arg n "$n" \
        && ui_ok "профиль «$n» удалён" ;;
    add|new) cmd_setup "$@" ;;
    key)
      local n="${1:-$(cfg_read '.current // empty')}" k="${2:-}"
      [[ -n "$n" ]] || { ui_err "профиль не выбран"; return 1; }
      jq -e --arg n "$n" '.profiles[$n]' "$TA_CFG" >/dev/null || { ui_err "нет профиля «$n»"; return 1; }
      if [[ -z "$k" ]]; then
        { : < /dev/tty; } 2>/dev/null || { ui_err "нет терминала: ta profile key $n <ключ>"; return 1; }
        printf '\n  %sAPI-ключ для «%s»%s %s— ввод скрыт, пусто = убрать ключ%s\n' "$C_B" "$n" "$C_RESET" "$C_DIM" "$C_RESET"
        k="$(ui_input 'ключ:' '' secret)"
      fi
      cfg_write '.profiles[$n].api_key = $k' --arg n "$n" --arg k "$k" || return 1
      if [[ -n "$k" ]]; then ui_ok "ключ для «$n» сохранён"; else ui_ok "ключ для «$n» убран"; fi ;;
    test)    cfg_test_connection "${1:-}" ;;
    presets)
      local p k pv url md env desc
      printf '\n'
      for p in "${TA_PRESET_LIST[@]}"; do
        IFS='|' read -r k pv url md env desc <<< "$p"
        printf ' %s%-11s%s %s%s%s\n   %s%s%s\n' "$C_B" "$k" "$C_RESET" "$C_GRY" "$desc" "$C_RESET" "$C_DIM" "$url" "$C_RESET"
      done
      printf '\n' ;;
    *) ui_err "неизвестно: $sub (list|use|add|show|key|del|test|presets)"; return 1 ;;
  esac
}

cmd_set() {
  if (( $# == 0 )); then
    printf '\n'
    jq -r '.settings | to_entries[] | "  \(.key)\t\(.value|tostring)"' "$TA_CFG" \
      | while IFS=$'\t' read -r k v; do printf ' %s%-20s%s %s\n' "$C_B" "$k" "$C_RESET" "$v"; done
    printf '\n%sменять: ta set ключ значение%s\n\n' "$C_DIM" "$C_RESET"
    return 0
  fi
  # ${2:?} ругался бы на пустую строку, а «стереть настройку» — законное действие
  local k="${1:?ключ}" v="${2?значение}" jv
  # ключ API живёт в профиле, а не в общих настройках
  [[ "$k" == "api_key" ]] && { cmd_profile key "$(cfg_read '.current // empty')" "$v"; return $?; }
  if [[ "$v" =~ ^(true|false)$ || "$v" =~ ^-?[0-9]+([.][0-9]+)?$ ]]; then jv="$v"; else jv="\"$v\""; fi
  cfg_write ".settings.$k = $jv" && ui_ok "settings.$k = $v"
}
