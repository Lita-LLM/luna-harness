#!/usr/bin/env bash
# Вопрос пользователю: свободный ответ или выбор из вариантов.
tool_meta() {
cat <<'JSON'
{
  "name": "ask_user",
  "description": "Спросить пользователя и дождаться ответа. Если у решения есть несколько понятных вариантов — передай их в options, пользователю покажется меню выбора, это быстрее для него, чем печатать. Спрашивай, когда выбор за пользователем (что ставить, что удалять, какой путь) или когда не хватает данных, которые нельзя добыть командой.",
  "parameters": {
    "type": "object",
    "properties": {
      "question": {"type": "string", "description": "Вопрос одной фразой"},
      "options": {"type": "array", "items": {"type": "string"},
                  "description": "Варианты ответа (2-4). Без них будет свободный ввод"}
    },
    "required": ["question"]
  },
  "x_interactive": true,
  "x_guard": false
}
JSON
}

tool_run() {
  local q ans opts n
  q="$(arg question)"
  opts="$(argj options)"
  n="$(jq 'length' <<<"${opts:-[]}" 2>/dev/null || echo 0)"

  if (( n > 0 )) && { : < /dev/tty; } 2>/dev/null; then
    local -a items=()
    mapfile -t items < <(jq -r '.[]' <<<"$opts")
    items+=("(свой ответ)")
    # ui_pick ждёт на stdin строки «значение\tметка», значением берём индекс:
    # по нему после выбора достаём исходный текст варианта из items как есть.
    local list="" i
    for (( i=0; i<${#items[@]}; i++ )); do
      list+="$(printf '%s\t%s' "$i" "${items[$i]//$'\t'/ }")"$'\n'
    done
    local sel; sel="$(printf '%s' "$list" | ui_pick --title "$q")" \
      || { printf 'Пользователь отменил выбор.'; return 0; }
    if (( sel == ${#items[@]} - 1 )); then
      ans="$(ui_input '  ответ:' '')"
    else
      ans="${items[sel]}"
    fi
  else
    printf '\n%s? %s%s\n' "${C_YEL:-}" "$q" "${C_RESET:-}" >&2
    ans="$(ui_input '  ответ:' '')"
  fi
  printf 'Пользователь ответил: %s' "${ans:-(без ответа)}"
}
