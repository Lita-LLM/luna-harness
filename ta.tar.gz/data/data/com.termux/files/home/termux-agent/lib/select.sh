#!/usr/bin/env bash
# lib/select.sh — интерактивные списки: стрелки, фильтр по мере набора,
# страницы. Используется везде, где нужно что-то выбрать: провайдер, модель,
# профиль, вариант ответа на вопрос агента.
#
#   printf 'val\tметка\tпояснение\n' | ui_pick --title "Заголовок"
#   → выбранное value в stdout, код 1 если отменили

ui_pick() {
  local title="" hint="" height=0 multi=0 query="" allow_custom=0
  while (( $# )); do
    case "$1" in
      --title)  title="$2"; shift 2 ;;
      --hint)   hint="$2"; shift 2 ;;
      --height) height="$2"; shift 2 ;;
      --query)  query="$2"; shift 2 ;;
      --multi)  multi=1; shift ;;
      --custom) allow_custom=1; shift ;;
      *) shift ;;
    esac
  done

  local -a VAL=() LAB=() META=() SEL=() LOW=()
  local v l m
  while IFS=$'\t' read -r v l m; do
    [[ -z "$v" ]] && continue
    VAL+=("$v"); LAB+=("${l:-$v}"); META+=("${m:-}"); SEL+=(0)
    # Строку для поиска готовим один раз при загрузке и средствами самого bash.
    # Раньше на каждое нажатие клавиши запускалось по два процесса на КАЖДУЮ
    # строку списка: для трёх сотен моделей это шестьсот процессов на букву.
    LOW+=("${v,,} ${l,,} ${m,,}")
  done

  local total=${#VAL[@]}
  (( total == 0 )) && return 1
  if ! { : < /dev/tty; } 2>/dev/null; then printf '%s' "${VAL[0]}"; return 0; fi

  (( height == 0 )) && height=$(( UI_ROWS - 9 ))
  (( height > 12 )) && height=12
  (( height < 4 )) && height=4

  local filter="$query" cur=0 off=0 drawn=0
  local -a IDX=()

  _pick_filter() {
    IDX=(); local i flt="${filter,,}"
    if [[ -z "$flt" ]]; then
      for (( i=0; i<total; i++ )); do IDX+=("$i"); done
    else
      for (( i=0; i<total; i++ )); do
        [[ "${LOW[$i]}" == *"$flt"* ]] && IDX+=("$i")
      done
    fi
    (( cur >= ${#IDX[@]} )) && cur=$(( ${#IDX[@]} - 1 ))
    (( cur < 0 )) && cur=0
  }

  _pick_draw() {
    local out="" n=${#IDX[@]} i idx line mark meta w up=$drawn
    (( cur < off )) && off=$cur
    (( cur >= off + height )) && off=$(( cur - height + 1 ))
    (( off < 0 )) && off=0

    local t="$title" f="$filter"
    if [[ -n "$f" ]]; then
      t="$(str_trunc "$t" $(( UI_COLS / 3 )))"
      # длинный запрос показываем хвостом — курсор ввода должен быть виден
      local froom=$(( UI_COLS - ${#t} - 12 ))
      (( froom < 6 )) && froom=6
      (( ${#f} > froom )) && f="…${f: -$(( froom - 1 ))}"
      out+=$'\n'"  ${C_B}${C_CYA}${t}${C_RESET}  ${C_DIM}поиск:${C_RESET} ${C_YEL}${f}${C_RESET}${C_DIM}▏${C_RESET}"
    else
      t="$(str_trunc "$t" $(( UI_COLS - 24 )))"
      out+=$'\n'"  ${C_B}${C_CYA}${t}${C_RESET}  ${C_DIM}(печатай для поиска)${C_RESET}"
    fi
    out+=$'\033[K\n'
    drawn=2

    for (( i=off; i<off+height; i++ )); do
      if (( i >= n )); then out+=$'\033[K\n'; (( drawn++ )); continue; fi
      idx="${IDX[$i]}"
      mark="  "
      (( multi )) && { [[ "${SEL[$idx]}" == "1" ]] && mark=" ${C_GRN}✓${C_RESET}" || mark="  "; }
      # Бюджет ширины на всю строку: маркер (2) + галочка (2) + запас (1).
      # Если строка вылезет за экран, терминал перенесёт её на вторую физическую
      # строку, и подъём курсора на следующем кадре съедет — весь список
      # рассыпется. Поэтому ужимаем сначала хвост, потом само название.
      w=$(( UI_COLS - 5 ))
      (( w < 8 )) && w=8
      line="${LAB[$idx]}"
      meta="${META[$idx]}"
      if (( ${#line} >= w )); then
        line="$(str_trunc "$line" "$w")"; meta=""
      elif [[ -n "$meta" ]]; then
        local room=$(( w - ${#line} - 1 ))
        if (( room < 4 )); then meta=""
        else meta="$(str_trunc "$meta" "$room")"; fi
      fi
      if (( i == cur )); then
        out+="${C_CYA}${C_B} ❯${C_RESET}${mark}${C_B}${line}${C_RESET}"
        [[ -n "$meta" ]] && out+=" ${C_DIM}${meta}${C_RESET}"
      else
        out+="  ${mark}${C_GRY}${line}${C_RESET}"
        [[ -n "$meta" ]] && out+=" ${C_DIM}${meta}${C_RESET}"
      fi
      out+=$'\033[K\n'
      (( drawn++ ))
    done

    local pos="$(( n == 0 ? 0 : cur + 1 ))/$n"
    # Последняя строка без перевода строки, поэтому в счётчик не идёт:
    # drawn — это ровно столько строк, на сколько нужно подняться назад.
    local h="${hint:-↑↓ выбор · Enter принять · Esc отмена}"
    h="$(str_trunc "$h" $(( UI_COLS - ${#pos} - 5 )))"
    out+="  ${C_DIM}${pos}  ${h}${C_RESET}"$'\033[K\033[J'
    # Весь кадр уходит одной записью, начиная с возврата курсора наверх.
    # Стирать отдельной командой нельзя: между стиранием и отрисовкой
    # терминал успевает показать пустоту — это и есть мерцание.
    # Escape-последовательность обязана быть в формате printf: в аргументе
    # %s она осталась бы обычным текстом.
    if (( up > 0 )); then printf '\r\033[%dA%s' "$up" "$out" > /dev/tty
    else printf '%s' "$out" > /dev/tty; fi
  }

  _pick_clear() { printf '\r\033[%dA\033[J' "$drawn" > /dev/tty; }

  # Пока список открыт, терминал не должен сам печатать нажатия: между
  # перерисовками эхо включено, и стрелки высыпаются на экран как ^[[B.
  local _stty=""
  _stty="$(stty -g < /dev/tty 2>/dev/null)" && stty -echo < /dev/tty 2>/dev/null
  printf '\033[?25l' > /dev/tty
  _pick_filter; _pick_draw

  local k rest result=""
  while :; do
    IFS= read -rsn1 k < /dev/tty || break
    case "$k" in
      $'\e')
        rest=""; read -rsn2 -t 0.05 rest < /dev/tty
        case "$rest" in
          '[A') (( cur > 0 )) && (( cur-- )) ;;
          '[B') (( cur < ${#IDX[@]} - 1 )) && (( cur++ )) ;;
          '[5') read -rsn1 -t 0.05 < /dev/tty; cur=$(( cur - height )); (( cur < 0 )) && cur=0 ;;
          '[6') read -rsn1 -t 0.05 < /dev/tty; cur=$(( cur + height ))
                (( cur > ${#IDX[@]} - 1 )) && cur=$(( ${#IDX[@]} - 1 )) ;;
          '[H') cur=0 ;;
          '[F') cur=$(( ${#IDX[@]} - 1 )) ;;
          '')   result=""; break ;;
        esac ;;
      '')  # Enter
        if (( ${#IDX[@]} == 0 )); then
          (( allow_custom )) && { result="$filter"; break; }
        elif (( multi )); then
          local i sel=""
          for i in "${!SEL[@]}"; do [[ "${SEL[$i]}" == "1" ]] && sel+="${VAL[$i]}"$'\n'; done
          [[ -z "$sel" ]] && sel="${VAL[${IDX[$cur]}]}"$'\n'
          result="${sel%$'\n'}"
        else
          result="${VAL[${IDX[$cur]}]}"
        fi
        break ;;
      ' ')
        if (( multi )) && (( ${#IDX[@]} > 0 )); then
          local idx="${IDX[$cur]}"
          [[ "${SEL[$idx]}" == "1" ]] && SEL[$idx]=0 || SEL[$idx]=1
          (( cur < ${#IDX[@]} - 1 )) && (( cur++ ))
        else filter+=" "; cur=0; fi ;;
      $'\177'|$'\b') filter="${filter%?}"; cur=0 ;;
      $'\003') result=""; break ;;                       # Ctrl+C
      $'\025') filter=""; cur=0 ;;                       # Ctrl+U
      $'\016') (( cur < ${#IDX[@]} - 1 )) && (( cur++ )) ;;  # Ctrl+N
      $'\020') (( cur > 0 )) && (( cur-- )) ;;              # Ctrl+P
      *)
        if [[ "$k" == [[:print:]] || ${#k} -gt 0 ]]; then filter+="$k"; cur=0; fi ;;
    esac
    _pick_filter
    _pick_draw
  done

  _pick_clear
  printf '\033[?25h' > /dev/tty
  [[ -n "$_stty" ]] && stty "$_stty" < /dev/tty 2>/dev/null
  [[ -z "$result" ]] && return 1
  printf '%s' "$result"
  return 0
}

# Однострочный ввод с подсказкой и значением по умолчанию.
ui_input() {
  local prompt="$1" def="${2:-}" secret="${3:-}" val=""
  if [[ -n "$def" ]]; then
    printf '  %s%s%s %s[%s]%s ' "$C_B" "$prompt" "$C_RESET" "$C_DIM" "$def" "$C_RESET" > /dev/tty
  else
    printf '  %s%s%s ' "$C_B" "$prompt" "$C_RESET" > /dev/tty
  fi
  if [[ "$secret" == "secret" ]]; then
    read -rs val < /dev/tty; printf '\n' > /dev/tty
  else
    read -r val < /dev/tty
  fi
  printf '%s' "${val:-$def}"
}

# Да/нет с понятным дефолтом.
ui_confirm() {
  local q="$1" def="${2:-y}" a
  printf '  %s%s%s %s(%s)%s ' "$C_B" "$q" "$C_RESET" "$C_DIM" \
         "$([[ "$def" == y ]] && echo 'Enter=да, n=нет' || echo 'y=да, Enter=нет')" "$C_RESET" > /dev/tty
  read -r a < /dev/tty
  a="${a,,}"; [[ -z "$a" ]] && a="$def"
  [[ "$a" == y || "$a" == "да" || "$a" == "д" ]]
}
