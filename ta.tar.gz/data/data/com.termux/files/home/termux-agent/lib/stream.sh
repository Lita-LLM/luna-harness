#!/usr/bin/env bash
# lib/stream.sh — разбор потокового ответа (SSE) OpenAI-совместимых API.
#
# Поток приходит строками «data: {…}». Каждая несёт кусочек: текст ответа,
# кусочек рассуждений или часть вызова инструмента. Всё это надо склеить
# обратно в одно сообщение, попутно показывая мысли на экране по мере поступления.
#
# Разбором занимается один долгоживущий jq: запускать его на каждый чанк
# означало бы сотни процессов на ответ.

# jq-программа: читает строки SSE, печатает по строке JSON на каждое событие.
#   R:текст   — фрагмент рассуждений (переводы строк закодированы как \u0001)
#   C:текст   — фрагмент ответа
#   T:имя     — модель начала вызов инструмента
#   A:число   — пришёл кусок аргументов вызова (число — сколько символов всего)
#   E:причина — модель закончила генерацию (finish_reason)
#   F:{…}     — собранное сообщение целиком, одной строкой JSON
#
# E нужен потому, что после finish_reason провайдер может ещё долго держать
# соединение открытым (OpenRouter ждёт от исходного провайдера usage и шлёт
# только «: OPENROUTER PROCESSING»). Ждать [DONE] в таком случае — значит
# висеть десятки секунд с уже готовым ответом на руках.
STREAM_JQ='
def nz: if type == "string" and length > 0 then . else null end;
def argstr: if . == null then "" elif type == "string" then . else tojson end;

# Куски вызовов инструментов у разных провайдеров приходят по-разному:
#  • имя и id в первом куске, а в следующих — пустые строки "" (их нельзя
#    принимать за значение: jq-оператор // пустую строку не заменяет);
#  • index только в первом куске, дальше без него;
#  • несколько параллельных вызовов под одним и тем же index, но с разными id;
#  • пустой «пролог» без имени и аргументов.
# Слоты храним с порядковым номером ord, чтобы порядок не зависел от того,
# как сортируются строковые ключи ("10" < "2").
def slot_by_id($id): (.tc | to_entries | map(select(.value.id == $id)) | first | .key) // null;
def upd($d):
    .dr = ($d.reasoning // $d.reasoning_content // "")
  | .dc = ($d.content // "")
  | .r += (.dr | argstr)
  | .c += (.dc | argstr)
  | reduce ($d.tool_calls // [])[] as $x (.;
      ($x.id | nz) as $xid
      | ($x.function.name | nz) as $xname
      | ($x.function.arguments | argstr) as $xargs
      | (if $xid != null and slot_by_id($xid) != null then slot_by_id($xid)
         elif $x.index != null then ($x.index | tostring)
         elif $xid != null or $xname != null then "n\(.tcn)"
         else (.last // "0") end) as $k0
      | (if .tc[$k0] != null and $xid != null
            and (.tc[$k0].id // "") != "" and .tc[$k0].id != $xid
         then "n\(.tcn)" else $k0 end) as $k
      | (if .tc[$k] == null then (.tc[$k] = {ord: .tcn, id: "", name: "", args: ""} | .tcn += 1) else . end)
      | .tc[$k].id   = ($xid // .tc[$k].id)
      | (if .tc[$k].name == "" and $xname != null then .dt += [$xname] else . end)
      | .tc[$k].name = (if .tc[$k].name == "" then ($xname // "") else .tc[$k].name end)
      | .tc[$k].args += $xargs
      | (if $xargs != "" then .da = true | .alen += ($xargs | length) else . end)
      | .last = $k);

def calls:
  [ .tc | to_entries | sort_by(.value.ord)[] | .value
    | (.args | gsub("^\\s+|\\s+$"; "")) as $raw
    | select(.name != "" or ($raw != "" and $raw != "{}"))
    | (if $raw == "" then {} else ($raw | fromjson? // null) end) as $p
    | {id: .id, name: .name, arguments: (if ($p | type) == "object" then $p else {} end)}
      + (if ($p | type) == "object" or $raw == "null" then {} else {bad_args: $raw} end) ];

def reset_line: .dr = "" | .dc = "" | .dt = [] | .da = false | .de = null | .emit = false;

foreach (inputs, "__END__") as $line
  ({c:"", r:"", tc:{}, tcn:0, last:null, u:null, alen:0, efin:false,
    dr:"", dc:"", dt:[], da:false, de:null, fin:false, emit:false};
   reset_line
   | if $line == "__END__" then (.emit = (.fin | not) | .fin = true)
     else
       ($line | sub("^data: *"; "")) as $p
       | if ($p | length) == 0 then .
         elif ($p | startswith("[DONE]")) then (.emit = (.fin | not) | .fin = true)
         else (try ($p | fromjson) catch null) as $j
           | if ($j | type) != "object" then .
             else
               (.u = ($j.usage // .u))
               | upd(($j.choices[0].delta) // {})
               | (($j.choices[0].finish_reason // null) | nz) as $fr
               | (if $fr != null and (.efin | not) then (.de = $fr | .efin = true) else . end)
             end
         end
     end;
   if .emit then
     "F:" + ({
        role: "assistant",
        content: .c,
        reasoning: .r,
        usage: .u,
        tool_calls: calls
     } | tojson)
   else
     (if (.dr | argstr) != "" then "R:" + (.dr | argstr | gsub("\n"; "\u0001")) else empty end),
     (if (.dc | argstr) != "" then "C:" + (.dc | argstr | gsub("\n"; "\u0001")) else empty end),
     (.dt[] | "T:" + gsub("\n"; " ")),
     (if .da then "A:\(.alen)" else empty end),
     (if .de != null then "E:" + .de else empty end)
   end
  )'

# Нужен ли поток: только когда мысли показываются, либо когда включили явно.
stream_enabled() {
  declare -F provider_stream >/dev/null || return 1
  if declare -F provider_stream_supported >/dev/null; then provider_stream_supported || return 1; fi
  case "$(cfg_setting stream auto)" in
    on|true)   return 0 ;;
    off|false) return 1 ;;
    *)         (( ${TA_SHOW_THINKING:-0} == 1 )) && return 0 || return 1 ;;
  esac
}

# Живой показ мыслей: печатаем по мере поступления, аккуратно перенося по ширине.
STREAM_COL=0
STREAM_TTY=0
STREAM_BUF=""
STREAM_IND="   "

stream_think_open() {
  STREAM_COL=0; STREAM_BUF=""
  # без терминала (запуск из скрипта, вывод в файл) просто молча копим ответ
  { : < /dev/tty; } 2>/dev/null && STREAM_TTY=1 || { STREAM_TTY=0; return 0; }
  printf '\n%s💭 ' "$C_DIM" > /dev/tty
  STREAM_COL=3
}

# Печать одного готового слова с переносом по ширине экрана.
_stream_word() {
  # ${#w} нельзя считать в той же строке, где w только присваивается:
  # bash раскрывает все слова команды до выполнения присваиваний.
  local w="$1"
  local n=${#w} room
  (( n == 0 )) && return 0
  room=$(( UI_COLS - 2 ))
  # слово длиннее строки (ссылка, путь) режем принудительно, иначе поедет вёрстка
  while (( n > room - 3 )); do
    if (( STREAM_COL > 3 )); then printf '\n%s' "$STREAM_IND" > /dev/tty; STREAM_COL=3; fi
    printf '%s' "${w:0:$(( room - 3 ))}" > /dev/tty
    w="${w:$(( room - 3 ))}"; n=${#w}
    printf '\n%s' "$STREAM_IND" > /dev/tty; STREAM_COL=3
  done
  if (( STREAM_COL + n + 1 > room )); then
    printf '\n%s' "$STREAM_IND" > /dev/tty; STREAM_COL=3
  elif (( STREAM_COL > 3 )); then
    printf ' ' > /dev/tty; (( STREAM_COL++ ))
  fi
  printf '%s' "$w" > /dev/tty
  STREAM_COL=$(( STREAM_COL + n ))
}

# Чанки копятся в буфере: провайдер рвёт текст в произвольных местах, и слово
# запросто приходит двумя кусками. Печатаем только то, что уже дописано до конца.
stream_think_chunk() {
  (( STREAM_TTY == 1 )) || return 0
  STREAM_BUF+="${1//$'\n'/ }"
  local word
  while [[ "$STREAM_BUF" == *" "* ]]; do
    word="${STREAM_BUF%% *}"
    STREAM_BUF="${STREAM_BUF#* }"
    _stream_word "$word"
  done
}

# $1 — сколько секунд думала модель, дописывается в ту же строку
stream_think_close() {
  (( STREAM_TTY == 1 )) || return 0
  [[ -n "$STREAM_BUF" ]] && { _stream_word "$STREAM_BUF"; STREAM_BUF=""; }
  local secs="${1:-}"
  printf '%s\n' "$C_RESET" > /dev/tty
  # Время — отдельной строкой. Приклеенное к последнему слову, оно читается
  # как часть мысли.
  [[ -n "$secs" ]] && printf '%s%s💭 %sс%s\n' "$STREAM_IND" "$C_DIM" "$secs" "$C_RESET" > /dev/tty
  STREAM_COL=0
}

# ── что происходит после мыслей ─────────────────────────────────────────────
# Раньше, как только мысли кончались, экран замирал: текст ответа и аргументы
# вызова копились молча до конца потока. Теперь крутится статус — видно, что
# модель пишет ответ или готовит вызов конкретного инструмента.
STREAM_PHASE=""
STREAM_PHASE_DETAIL=""

# stream_phase <api|think|write|call|""> [деталь]; пустое состояние — убрать статус
stream_phase() {
  local ph="${1:-}" det="${2:-}"
  [[ "$ph" == "$STREAM_PHASE" && "$det" == "$STREAM_PHASE_DETAIL" ]] && return 0
  STREAM_PHASE="$ph"; STREAM_PHASE_DETAIL="$det"
  if [[ -z "$ph" ]]; then ui_status_stop; else ui_status "$ph" "$det"; fi
}

# ── защита от зацикливания ──────────────────────────────────────────────────
# Модель иногда залипает и повторяет одну фразу до исчерпания лимита токенов.
# Ловим это так: берём последние 30 символов и одной подстановкой считаем,
# сколько раз этот кусок встречается в накопленном хвосте. Десять совпадений
# подряд в живом тексте не встречаются, а стоит это одну операцию самого bash —
# ни процессов, ни расчётов, телефон не заметит.
STREAM_LOOPBUF=""
STREAM_LOOPSEEN=0

stream_loop_reset() { STREAM_LOOPBUF=""; STREAM_LOOPSEEN=0; }

# stream_loop_watch <кусок текста> → 0 если обнаружено зацикливание
stream_loop_watch() {
  local limit; limit="$(cfg_setting loop_guard 10)"
  [[ "$limit" == "0" ]] && return 1

  STREAM_LOOPBUF+="$1"
  local len=${#STREAM_LOOPBUF}
  (( len > 4000 )) && { STREAM_LOOPBUF="${STREAM_LOOPBUF: -4000}"; len=4000; }
  # проверяем не чаще, чем раз в 200 пришедших символов
  (( len - STREAM_LOOPSEEN < 200 )) && return 1
  STREAM_LOOPSEEN=$len

  local probe="${STREAM_LOOPBUF: -30}"
  (( ${#probe} < 30 )) && return 1
  local stripped="${STREAM_LOOPBUF//"$probe"/}"
  local n=$(( (len - ${#stripped}) / 30 ))
  (( n >= limit ))
}

# Та же проверка для целого текста (нестриминговый ответ).
text_is_looped() {
  local text="$1" limit
  limit="$(cfg_setting loop_guard 10)"
  [[ "$limit" == "0" ]] && return 1
  # Хвостовые пробелы и переводы строк сдвигают окно сравнения, и повтор
  # перестаёт совпадать сам с собой — обрезаем их до проверки.
  text="${text%"${text##*[![:space:]]}"}"
  local len=${#text}
  (( len < 600 )) && return 1
  (( len > 4000 )) && text="${text: -4000}" && len=4000
  local probe="${text: -30}"
  (( ${#probe} < 30 )) && return 1
  local stripped="${text//"$probe"/}"
  local n=$(( (len - ${#stripped}) / 30 ))
  (( n >= limit ))
}
