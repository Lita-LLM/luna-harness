#!/usr/bin/env bash
# Выполнение shell-команд.

tool_meta() {
cat <<'JSON'
{
  "name": "bash",
  "description": "Выполнить команду в shell Termux (bash). Складывай в ОДИН вызов всё, что логически идёт вместе — установку, сборку и проверку, — вместо десятка мелких вызовов. Возвращает stdout+stderr и код возврата. Используй для установки пакетов (pkg/apt/pip), диагностики, запуска скриптов. Работает неинтерактивно: не запускай команды, ждущие ввода — добавляй флаги вроде -y. Долгие команды ограничены таймаутом.",
  "parameters": {
    "type": "object",
    "properties": {
      "command": {"type": "string", "description": "Команда для выполнения"},
      "intent": {"type": "string", "description": "ОБЯЗАТЕЛЬНО. Одной фразой по-русски: что именно сделает эта команда и зачем. Честно, включая риск. Пользователь читает только это, решая, разрешить или нет"},
      "timeout": {"type": "integer", "description": "Таймаут в секундах (по умолчанию 120, максимум 900)"},
      "cwd": {"type": "string", "description": "Рабочий каталог (необязательно)"},
      "background": {"type": "boolean", "description": "Запустить в фоне и сразу вернуть управление. Для долгого: сборка, установка большого пакета, сервер. Вернётся PID и путь к логу — потом читай лог через read_file"}
    },
    "required": ["command", "intent"]
  },
  "x_confirm": true
}
JSON
}

tool_run() {
  local cmd t cwd
  cmd="$(arg command)"; [[ -z "$cmd" ]] && die "пустая команда"
  t="$(arg timeout 120)"; [[ "$t" =~ ^[0-9]+$ ]] || t=120; (( t > 900 )) && t=900
  cwd="$(expand_path "$(arg cwd "$PWD")")"
  [[ -d "$cwd" ]] || cwd="$PWD"

  if [[ "$(arg background false)" == "true" ]]; then
    local log="${TA_DATA_DIR:-$HOME/.local/share/termux-agent}/run"
    mkdir -p "$log" 2>/dev/null
    log="$log/bg-$(date +%Y%m%d-%H%M%S).log"
    ( cd "$cwd" && nohup bash -c "$cmd" > "$log" 2>&1 & printf '%s' $! > "$log.pid" ) 2>/dev/null
    sleep 0.5
    # запись в реестр: агент узнает о завершении сам, на следующем шаге
    local bgpid; bgpid="$(cat "$log.pid" 2>/dev/null)"
    if [[ -n "$bgpid" ]]; then
      printf '%s\t%s\t%s\n' "$bgpid" "${cmd:0:40}" "$log" \
        >> "${TA_DATA_DIR:-$HOME/.local/share/termux-agent}/run/jobs.tsv" 2>/dev/null
    fi
    printf 'Запущено в фоне.\nPID: %s\nЛог: %s\nПроверяй ход работы чтением лога (read_file с offset), не жди здесь.\nОстановить: kill %s' \
      "$(cat "$log.pid" 2>/dev/null)" "$log" "$(cat "$log.pid" 2>/dev/null)"
    return 0
  fi

  local out rc
  if have timeout; then
    out="$(cd "$cwd" && timeout --foreground "${t}s" bash -c "$cmd" 2>&1)"; rc=$?
  else
    out="$(cd "$cwd" && bash -c "$cmd" 2>&1)"; rc=$?
  fi
  (( rc == 124 )) && out="${out}"$'\n'"[прервано по таймауту ${t}s]"
  printf '%s\n[exit=%d cwd=%s]' "$out" "$rc" "$cwd"
}
