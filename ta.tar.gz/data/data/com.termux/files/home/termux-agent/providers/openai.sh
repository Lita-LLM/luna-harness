#!/usr/bin/env bash
# Провайдер для любого OpenAI-совместимого API.
# Рассуждения: OpenRouter понимает reasoning:{effort}, остальные — reasoning_effort.

source "${TA_HOME:?}/lib/histfix.sh"

_oai_reasoning() {
  [[ "${TA_REASONING:-off}" == "off" || -z "${TA_REASONING:-}" ]] && { printf '{}'; return; }
  if [[ "$TA_BASE_URL" == *openrouter* ]]; then
    jq -nc --arg e "$TA_REASONING" '{reasoning: {effort: $e}}'
  else
    jq -nc --arg e "$TA_REASONING" '{reasoning_effort: $e}'
  fi
}

provider_request() {
  jq -n --slurpfile h "$1" --slurpfile t "$2" \
        --arg model "$TA_MODEL" \
        --argjson temp "$TA_TEMPERATURE" \
        --argjson maxtok "$TA_MAX_TOKENS" \
        --argjson reason "$(_oai_reasoning)" \
        --argjson extra "$TA_EXTRA_BODY" "$HISTFIX_JQ"'
    {
      model: $model,
      temperature: $temp,
      max_tokens: $maxtok,
      messages: ($h[0] | fixhist | map(
        if .role == "assistant" then
          ({role: "assistant", content: (if (.content // "") == "" then null else .content end)}
           + (if ((.tool_calls // []) | length) > 0
              then {tool_calls: (.tool_calls | map({
                     id: .id, type: "function",
                     function: {name: .name, arguments: (.arguments | tostring)}}))}
              else {} end))
        elif .role == "tool" then
          {role: "tool", tool_call_id: .tool_call_id, content: (.content | tostring)}
        else
          {role: .role, content: .content}
        end)),
      tools: ($t[0] | map({type: "function", function: {name: .name, description: .description, parameters: .parameters}}))
    }
    | (if ($t[0] | length) == 0 then del(.tools) else . end)
    | . * $reason * $extra'
}

provider_send() {
  local key; key="$(cfg_api_key)"
  local -a H=(-H 'Content-Type: application/json')
  [[ -n "$key" ]] && H+=(-H "Authorization: Bearer $key")
  local h; for h in "${TA_EXTRA_HEADERS[@]}"; do [[ -n "$h" ]] && H+=(-H "$h"); done
  curl -sS --max-time "$TA_HTTP_TIMEOUT" -X POST "${TA_BASE_URL%/}/chat/completions" \
       "${H[@]}" --data-binary @"$1" -o "$2" -w '%{http_code}'
}

provider_parse() {
  jq -c '
    (.choices[0].message // {}) as $m |
    {
      role: "assistant",
      content: ($m.content // "" | if type == "array" then (map(.text // "") | join("")) else . end),
      reasoning: (($m.reasoning // $m.reasoning_content // "") | tostring),
      tool_calls: [ ($m.tool_calls // [])[]
        | ((.function.arguments // "{}") | if type == "string" then . else tojson end
           | gsub("^\\s+|\\s+$"; "")) as $raw
        | (if $raw == "" then {} else (try ($raw | fromjson) catch null) end) as $p
        | {
            id: (.id // ""),
            name: (.function.name // ""),
            arguments: (if ($p | type) == "object" then $p else {} end)
          }
          + (if ($p | type) == "object" or $raw == "null" then {} else {bad_args: $raw} end) ]
    }' "$1"
}

# печатает: "<токенов ответа> <всего токенов>"
provider_usage() {
  jq -r '"\(.usage.completion_tokens // 0) \(.usage.total_tokens // 0)"' "$1" 2>/dev/null || echo "0 0"
}

# Текст ошибки. Понимает и обычный JSON, и SSE-поток с ошибкой внутри.
# У OpenRouter суть часто лежит глубже: error.metadata.raw — ответ самого
# провайдера модели, без него видно лишь «Provider returned error».
provider_error() {
  [[ -s "$1" ]] || return 0
  jq -Rrs '
    def str: if . == null then "" elif type == "string" then . else tojson end;
    (try fromjson catch null) as $whole
    | (if ($whole | type) == "object" then $whole
       else ([splits("\n") | sub("^data: *"; "") | (try fromjson catch null)
              | select(type == "object" and has("error"))] | first) end) as $j
    | if $j == null then empty else
        (($j.error.message // $j.message // $j.detail // $j.error) | str) as $m
        | ($j.error.metadata.raw | str) as $raw
        | ((try ($raw | fromjson | (.error.message // .message // .detail // .error) | str) catch "") // "") as $inner
        | ($j.error.metadata.provider_name | str) as $prov
        | (if $inner != "" then $inner else $raw end | .[0:400]) as $detail
        | $m
          + (if $detail != "" and $detail != $m
             then " — " + (if $prov != "" then $prov + ": " else "" end) + $detail else "" end)
      end' "$1" 2>/dev/null
}

# ── потоковый режим ─────────────────────────────────────────────────────────
provider_stream_supported() { return 0; }

# Миллисекунды без запуска процессов: $EPOCHREALTIME есть в bash 5+.
_stream_now_ms() {
  if [[ -n "${EPOCHREALTIME:-}" ]]; then
    local t="${EPOCHREALTIME/,/.}"
    printf '%s' "$(( ${t%.*} * 1000 + 10#${t#*.} / 1000 ))"
  else
    printf '%s' "$(( SECONDS * 1000 ))"
  fi
}

# Закрыть блок мыслей в момент, когда модель перешла к ответу или вызову.
# Время — именно время раздумий, а не всего запроса: иначе ожидание хвоста
# ответа выглядело как «думал 70 секунд».
# Использует opened/closed/_t0 из provider_stream (динамическая область bash).
_stream_after_think() {
  (( opened == 1 && closed == 0 )) || return 0
  closed=1
  local _t1; _t1="$(date +%s%3N 2>/dev/null || printf '%s000' "$(date +%s)")"
  stream_think_close "$(awk -v a="$_t0" -v b="$_t1" 'BEGIN{printf "%.1f", (b-a)/1000}')"
}

# Потоковый запрос. Мысли печатаются по мере поступления, собранное сообщение
# кладётся в файл $2 во внутреннем формате. Печатает HTTP-код.
provider_stream() {
  local body="$1" outjson="$2"
  local sbody="$TA_TMP/stream.req.json" hdr="$TA_TMP/stream.hdr" err="$TA_TMP/stream.err"
  jq '. + {stream: true}' "$body" > "$sbody" 2>/dev/null || cp "$body" "$sbody"
  : > "$outjson"; : > "$hdr"

  local key; key="$(cfg_api_key)"
  local -a H=(-H 'Content-Type: application/json')
  [[ -n "$key" ]] && H+=(-H "Authorization: Bearer $key")
  local h; for h in "${TA_EXTRA_HEADERS[@]}"; do [[ -n "$h" ]] && H+=(-H "$h"); done

  local ev txt opened=0 closed=0
  local raw="$TA_TMP/stream.raw" jqerr="$TA_TMP/stream.jqerr"
  local _t0; _t0="$(date +%s%3N 2>/dev/null || printf '%s000' "$(date +%s)")"
  : > "$raw"; : > "$jqerr"

  # Сырой поток сохраняем целиком: если разбор на лету сорвётся (оборванное
  # соединение, мусорная строка), из него можно собрать ответ повторно.
  #
  # Читаем через именованный канал, а не напрямую из подстановки процесса:
  # иначе чтение блокируется до следующего куска, и нажатие Ctrl+C или Esc Esc
  # замечается только когда модель соизволит что-нибудь прислать. С каналом
  # опрос идёт каждые 0.2 секунды, и прерывание срабатывает сразу.
  local pipe="$TA_TMP/stream.pipe" aborted=0 sp=""
  rm -f "$pipe"; mkfifo "$pipe" 2>/dev/null || pipe=""

  if [[ -n "$pipe" ]]; then
    ( curl -sS -N --max-time "$TA_HTTP_TIMEOUT" -D "$hdr" -X POST \
        "${TA_BASE_URL%/}/chat/completions" "${H[@]}" --data-binary @"$sbody" 2>"$err" \
      | tee "$raw" \
      | jq -Rrn --unbuffered "$STREAM_JQ" 2>"$jqerr" > "$pipe" ) 2>/dev/null &
    sp=$!
    # Без disown: отвязанный процесс bash не узнаёт при сборе детей и печатает
    # «wait_for: No record of process». «Terminated» при прерывании гасит
    # групповое перенаправление у wait ниже.
    exec 3< "$pipe"
    # closed — блок мыслей уже закрыт (модель перешла к ответу или вызову);
    # efin_at — когда пришёл finish_reason (мс): дальше ждём итог не больше 1.5 с.
    local efin_at=""
    STREAM_PHASE=""
    [[ "${TA_REASONING:-off}" == "off" ]] && stream_phase api || stream_phase think
    while :; do
      if IFS= read -r -t 0.2 ev <&3; then
        case "$ev" in
          R:*)
            if (( opened == 0 || closed == 1 )); then
              stream_phase ""               # спиннер и живые мысли не должны драться за строку
              stream_think_open; opened=1; closed=0
            fi
            txt="${ev#R:}"
            stream_think_chunk "${txt//$'\x01'/ }"
            stream_loop_watch "${txt//$'\x01'/ }" && { aborted=2; kill_tree "$sp"; break; } ;;
          F:*)
            # Итог получен. Дальше ждать нечего: при keep-alive соединении curl
            # провисел бы до таймаута, а агент — вместе с ним.
            printf '%s' "${ev#F:}" > "$outjson"
            kill_tree "$sp"
            break ;;
          C:*)
            _stream_after_think
            [[ "$STREAM_PHASE" == call ]] || stream_phase write
            txt="${ev#C:}"
            stream_loop_watch "${txt//$'\x01'/ }" && { aborted=2; kill_tree "$sp"; break; } ;;
          T:*)
            _stream_after_think
            stream_phase call "${ev#T:}" ;;
          A:*)
            _stream_after_think
            [[ "$STREAM_PHASE" == call ]] || stream_phase call ;;
          E:*)
            _stream_after_think
            if [[ -z "$efin_at" ]]; then
              efin_at="$(_stream_now_ms)"
              stream_phase api "ответ получен"
            fi ;;
        esac
      else
        (( $? > 128 )) || break          # не таймаут чтения, а конец потока
      fi
      # Модель уже закончила, а провайдер держит соединение (ждёт usage и т.п.).
      # Ответ собираем из того, что пришло, и не заставляем пользователя ждать.
      if [[ -n "$efin_at" ]] && (( $(_stream_now_ms) - efin_at >= 1500 )); then
        kill_tree "$sp"; break
      fi
      if input_aborted; then kill_tree "$sp"; aborted=1; break; fi
    done
    stream_phase ""
    exec 3<&-
    { wait "$sp"; } 2>/dev/null
    rm -f "$pipe"
  else
    while IFS= read -r ev; do
      case "$ev" in
        R:*) (( opened == 0 )) && { stream_think_open; opened=1; }
             txt="${ev#R:}"; stream_think_chunk "${txt//$'\x01'/ }" ;;
        F:*) printf '%s' "${ev#F:}" > "$outjson" ;;
      esac
    done < <(curl -sS -N --max-time "$TA_HTTP_TIMEOUT" -D "$hdr" -X POST \
               "${TA_BASE_URL%/}/chat/completions" "${H[@]}" --data-binary @"$sbody" 2>"$err" \
             | tee "$raw" | jq -Rrn --unbuffered "$STREAM_JQ" 2>"$jqerr")
  fi

  _stream_after_think

  # Итоговой строки не пришло — пробуем собрать сообщение из сохранённого потока.
  if [[ ! -s "$outjson" ]] && [[ -s "$raw" ]]; then
    jq -Rrn "$STREAM_JQ" < "$raw" 2>/dev/null | sed -n 's/^F://p' | tail -1 > "$outjson"
  fi

  (( aborted == 1 )) && { printf '130'; return 0; }
  (( aborted == 2 )) && { printf '598'; return 0; }
  local code; code="$(awk '/^HTTP\//{c=$2} END{print c+0}' "$hdr" 2>/dev/null)"
  [[ "$code" == "0" || -z "$code" ]] && code=000
  # Ответ по HTTP нормальный, но собрать сообщение не удалось: пусть агент
  # повторит запрос обычным способом, а не падает с невнятной ошибкой.
  # Пустое сообщение — это тоже неудача: без текста, мыслей и вызовов
  # показывать нечего, лучше честно повторить запрос обычным способом.
  if [[ "$code" == "200" ]]; then
    if [[ ! -s "$outjson" ]]; then code=599
    elif [[ "$(jq -r '((.content // "") + (.reasoning // "")) as $t
                      | if ($t | length) == 0 and ((.tool_calls // []) | length) == 0
                        then "empty" else "ok" end' "$outjson" 2>/dev/null)" == "empty" ]]; then
      code=599
    fi
  fi
  printf '%s' "$code"
}

# Разбор потокового ответа сводится к чтению уже собранного файла.
provider_stream_parse() { jq -c 'del(.usage)' "$1" 2>/dev/null; }
provider_stream_usage() {
  jq -r '"\(.usage.completion_tokens // 0) \(.usage.total_tokens // 0)"' "$1" 2>/dev/null || echo "0 0"
}
