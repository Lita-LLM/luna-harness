#!/usr/bin/env bash
# lib/subagent.sh — подчинённые агенты.
#
# Основной агент поручает независимую подзадачу отдельному экземпляру: своя
# история, свой лимит шагов, наверх возвращается только итог. Ради этого всё и
# затевается — контекст главного не забивается выводом двадцати команд.
#
# УРОВНИ ДОСТУПА. Субагент работает без человека, подтвердить его действия некому,
# а при параллельном запуске четыре потока разом никто и не проверит. Поэтому
# права выдаются осознанно, а не «всем всё»:
#
#   read      чтение и поиск. Безопасно всегда, это значение по умолчанию.
#   diagnose  то же плюс bash, но каждая команда проходит классификатор опасности:
#             rm -rf, dd, curl | sh и прочее подобное отклоняются автоматически.
#   write     полный набор, включая правку файлов. Выдаётся только когда задача
#             одна (проверять параллельные изменения невозможно) либо когда
#             основной сеанс и так в авто-режиме. Все правки пишутся в чекпоинты,
#             так что /rewind откатит и их.
#
# В режиме плана доступ принудительно опускается до read: там менять нельзя никому.

SUBAGENT_TOOLS_READ='["read_file","list_dir","grep_files","web_search","web_fetch"]'
SUBAGENT_TOOLS_DIAG='["read_file","list_dir","grep_files","web_search","web_fetch","bash"]'
SUBAGENT_TOOLS_WRITE='["read_file","list_dir","grep_files","web_search","web_fetch","bash","write_file","edit_file"]'

subagent_toolset() {
  case "$1" in
    write)    printf '%s' "$SUBAGENT_TOOLS_WRITE" ;;
    diagnose) printf '%s' "$SUBAGENT_TOOLS_DIAG" ;;
    *)        printf '%s' "$SUBAGENT_TOOLS_READ" ;;
  esac
}

subagent_prompt() {
  local access="$1"
  cat <<EOF
Ты — подчинённый агент внутри termux-agent. Тебе поручена одна узкая задача.

$(prompt_env)

ТВОИ ПРАВА: $access
$(case "$access" in
  write)    echo "- Можешь читать, искать, выполнять команды и править файлы.
- Опасные команды всё равно отклоняются автоматически — не пытайся их обойти.
- Меняй только то, что относится к задаче. Каждая правка сохраняется в чекпоинт." ;;
  diagnose) echo "- Можешь читать, искать и выполнять команды для диагностики.
- Команды, меняющие систему, отклоняются автоматически: установка, удаление,
  перезапись. Если такое нужно — не делай, а напиши об этом в итоге." ;;
  *)        echo "- Только чтение и поиск. Выполнять команды и менять файлы ты не можешь." ;;
esac)

ПРАВИЛА
- Работай сам, вопросов задать некому: пользователя рядом нет.
- Уложись в отведённые шаги. Не уверен — так и скажи, догадки помечай как догадки.
- В конце дай сжатый итог: что выяснил, какие пути и команды нашёл, что делать дальше.
  Итог читает другой агент, а не человек: без вступлений, только суть, до 15 строк.
EOF
}

# Модель субагента: имя профиля из конфига либо просто идентификатор модели.
subagent_use_model() {
  local want="$1"
  [[ -z "$want" ]] && return 0
  if jq -e --arg n "$want" '.profiles[$n]' "$TA_CFG" >/dev/null 2>&1; then
    local p; p="$(jq -c --arg n "$want" '.profiles[$n]' "$TA_CFG")"
    TA_PROVIDER="$(jq -r '.provider // "openai"' <<<"$p")"
    TA_BASE_URL="$(jq -r '.base_url // empty' <<<"$p")"
    TA_MODEL="$(jq -r '.model // empty' <<<"$p")"
    TA_KEY_RAW="$(jq -r '.api_key // empty' <<<"$p")"
    TA_KEY_ENV="$(jq -r '.api_key_env // empty' <<<"$p")"
    TA_REASONING="$(jq -r '.reasoning // "off"' <<<"$p")"
    source "$TA_HOME/providers/$TA_PROVIDER.sh" 2>/dev/null
  else
    TA_MODEL="$want"   # та же точка входа, другая модель
  fi
  return 0
}

# Проверка действия субагента. Та же область и та же модель, что у основного
# агента, только без спиннера: субагенты работают параллельно под общим статусом.
# Модель недоступна или проверка выключена — остаются локальные правила.
subagent_blocked() {   # → 0 отклонить (причина в SUB_BLOCK_WHY)
  local n="$1" a="$2" method
  SUB_BLOCK_WHY=""
  tools_guard_scope "$n" "$a" || return 1
  method="$(cfg_setting auto_check model)"
  if [[ "$method" == model || "$method" == both ]]; then
    if [[ "$method" == both ]]; then
      SUB_BLOCK_WHY="$(tools_risk_why "$n" "$a")"; [[ -n "$SUB_BLOCK_WHY" ]] && return 0
    fi
    TA_GUARD_QUIET=1 guard_check "$n" "$a"
    case $? in
      0) SUB_BLOCK_WHY="${GUARD_REASON:-опасно}"; return 0 ;;
      1) return 1 ;;
    esac
  fi
  SUB_BLOCK_WHY="$(tools_risk_why "$n" "$a")"
  [[ -n "$SUB_BLOCK_WHY" ]]
}

# subagent_run <имя> <задача> <шагов> <файл результата> <доступ> <модель>
subagent_run() {
  local name="$1" task="$2" steps="${3:-8}" outfile="$4" access="${5:-read}" model="${6:-}"
  [[ "${TA_MODE:-normal}" == "plan" ]] && access="read"
  subagent_use_model "$model"

  local dir; dir="$(mktemp -d "${TMPDIR:-/tmp}/ta-sub.XXXXXX")"
  local hist="$dir/hist.json" tools="$dir/tools.json"
  local allow; allow="$(subagent_toolset "$access")"

  jq -n --arg s "$(subagent_prompt "$access")" --arg t "$task" \
    '[{role:"system",content:$s},{role:"user",content:$t}]' > "$hist"
  tools_manifest | jq --argjson allow "$allow" \
    'map(select(.name as $n | $allow | index($n))) | map({name, description, parameters})' > "$tools"

  local step=0 answer=""
  while (( step < steps )); do
    (( step++ ))
    provider_request "$hist" "$tools" > "$dir/req.json" 2>/dev/null || break
    local code
    code="$(provider_send "$dir/req.json" "$dir/resp.json" 2>/dev/null)"
    [[ "$code" == "200" ]] || { answer="[субагент $name: API вернул $code]"; break; }

    local msg; msg="$(provider_parse "$dir/resp.json")"
    [[ -n "$msg" ]] || { answer="[субагент $name: не разобрать ответ]"; break; }
    declare -F toolcalls_fix >/dev/null && msg="$(toolcalls_fix "$msg" "$tools" | jq -c 'del(.notes)')"
    local tmp="$dir/h.tmp"
    jq --argjson m "$msg" '. += [$m]' "$hist" > "$tmp" && mv "$tmp" "$hist"

    local text ncalls
    text="$(jq -r '.content // ""' <<<"$msg")"
    ncalls="$(jq '.tool_calls | length' <<<"$msg")"
    if (( ncalls == 0 )); then answer="$text"; break; fi

    local i
    for (( i=0; i<ncalls; i++ )); do
      local tc n a id res
      tc="$(jq -c ".tool_calls[$i]" <<<"$msg")"
      n="$(jq -r '.name' <<<"$tc")"; a="$(jq -c '.arguments' <<<"$tc")"; id="$(jq -r '.id' <<<"$tc")"
      if ! jq -e --arg n "$n" --argjson allow "$allow" '$allow | index($n)' >/dev/null <<<'{}'; then
        res="Инструмент «$n» тебе не выдан (уровень доступа: $access)."
      elif subagent_blocked "$n" "$a"; then
        # Подтвердить действие субагента некому: опасное просто отклоняем.
        res="Отклонено автоматически: действие опасное (${SUB_BLOCK_WHY:-проверка безопасности}), а подтвердить его некому.
Опиши в итоге, что требуется сделать, и это выполнит основной агент под присмотром пользователя."
      else
        res="$(tools_run "$n" "$a")"
      fi
      jq -n --arg id "$id" --arg n "$n" --arg c "$res" \
        '{role:"tool", tool_call_id:$id, name:$n, content:$c}' > "$dir/t.json"
      jq --slurpfile t "$dir/t.json" '. += $t' "$hist" > "$tmp" && mv "$tmp" "$hist"
    done
  done

  [[ -z "$answer" ]] && answer="[субагент $name: исчерпал $steps шагов без итога]"
  printf '%s' "$answer" > "$outfile"
  rm -rf "$dir"
}
