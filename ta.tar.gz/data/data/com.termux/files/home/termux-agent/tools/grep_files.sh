#!/usr/bin/env bash
tool_meta() {
cat <<'JSON'
{
  "name": "grep_files",
  "description": "Искать текст по файлам рекурсивно (regex) и/или файлы по имени. Быстрый способ найти, где лежит конфиг или откуда берётся ошибка.",
  "parameters": {
    "type": "object",
    "properties": {
      "pattern": {"type": "string", "description": "Регулярное выражение для поиска внутри файлов"},
      "name": {"type": "string", "description": "Шаблон имени файла, например *.py"},
      "path": {"type": "string", "description": "Где искать (по умолчанию текущий каталог)"},
      "max_results": {"type": "integer", "description": "Ограничение вывода, по умолчанию 80"}
    }
  }
}
JSON
}

tool_run() {
  local pat name p max
  pat="$(arg pattern)"; name="$(arg name)"
  p="$(expand_path "$(arg path "$PWD")")"
  max="$(arg max_results 80)"; [[ "$max" =~ ^[0-9]+$ ]] || max=80
  [[ -e "$p" ]] || die "нет пути: $p"

  if [[ -n "$name" && -z "$pat" ]]; then
    find "$p" -name "$name" 2>/dev/null | head -"$max"
    return 0
  fi
  [[ -n "$pat" ]] || die "нужен pattern или name"
  local inc=()
  [[ -n "$name" ]] && inc=(--include="$name")
  grep -rnI "${inc[@]}" -e "$pat" "$p" 2>/dev/null | head -"$max"
  return 0
}
