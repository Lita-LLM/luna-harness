#!/usr/bin/env bash
# Бесплатный веб-поиск без ключей и регистрации.
#
# source=web (по умолчанию) — движки по очереди, пока не будет результата:
#   1. lite.duckduckgo.com  (GET, потом POST — разметка у них разъезжается)
#   2. html.duckduckgo.com  (запасная разметка)
#   3. SearXNG              (если задан settings.searxng_url)
#   4. StackOverflow API    (поисковики недоступны, а вопрос обычно про ошибку)
#   5. Википедия            (последний рубеж)
# Brave и SearXNG с ключом — если настроены в settings.search_engine.
# Прицельные источники по API: github (issues и PR), stackoverflow, npm, wiki.
# read=N — сразу прочитать N первых ссылок и вернуть куски со словами запроса:
# экономит модели целые шаги, а на бесплатной модели шаг — это десятки секунд.
#
# Диагностика: TA_SEARCH_DEBUG=1 покажет коды ответов и размер страниц.
# Проверить отдельно от агента:  ta search "текст ошибки"

tool_meta() {
cat <<'JSON'
{
  "name": "web_search",
  "description": "Поиск в интернете: заголовок, ссылка, описание. Для ошибок вставляй точный текст ошибки. source: web (по умолчанию), github — issues и PR, stackoverflow, npm, wiki. read: 1-3 — сразу прочитать столько первых ссылок и показать куски со словами запроса (обычно выгоднее, чем отдельные web_fetch).",
  "parameters": {
    "type": "object",
    "properties": {
      "query": {"type": "string"},
      "source": {"type": "string", "enum": ["web", "github", "stackoverflow", "npm", "wiki"]},
      "recency": {"type": "string", "enum": ["day", "week", "month", "year"], "description": "Только свежее (для web и github)"},
      "read": {"type": "integer", "description": "Прочитать N первых результатов (0-3)"},
      "max_results": {"type": "integer", "description": "По умолчанию 6"}
    },
    "required": ["query"]
  }
}
JSON
}

_dbg() { [[ "${TA_SEARCH_DEBUG:-0}" == "1" ]] && printf '  [поиск] %s\n' "$*" >&2; return 0; }

# Ответ похож на страницу-заглушку («докажите, что вы не робот»)?
_is_challenge() {
  grep -qiE 'anomaly|are you a robot|unusual traffic|captcha|challenge-form' <<<"$1"
}

# stdin: HTML → stdout: "url<TAB>заголовок"
_ddg_links() {
  tr '\n' ' ' | sed 's/result__a/result-link/g' | awk -v RS='<a ' '
    /result-link/ {
      if (!match($0, /href=["'"'"'][^"'"'"']*["'"'"']/)) next
      u = substr($0, RSTART+6, RLENGTH-7)
      p = index($0, ">"); e = index($0, "</a>")
      t = (p > 0 && e > p) ? substr($0, p+1, e-p-1) : ""
      gsub(/<[^>]*>/, "", t); gsub(/^[ \t]+|[ \t]+$/, "", t); gsub(/[ \t]+/, " ", t)
      if (u != "" && t != "") print u "\t" t
    }'
}

_ddg_snippets() {
  tr '\n' ' ' | sed 's/result__snippet/result-snippet/g' | awk -v RS='result-snippet' '
    NR > 1 {
      p = index($0, ">"); if (p == 0) next
      s = substr($0, p+1)
      e = index(s, "</td>"); if (e == 0) e = index(s, "</a>")
      if (e > 0) s = substr(s, 1, e-1)
      gsub(/<[^>]*>/, "", s); gsub(/[ \t]+/, " ", s); gsub(/^ +| +$/, "", s)
      print s
    }'
}

# Возврат: 0 — есть результаты, 2 — страница нормальная, но результатов нет,
# 1 — разобрать не удалось (движок сломан или отдал не то).
_ddg_parse() {   # $1 = html → "url\tзаголовок\tописание"
  local html="$1" links snips
  links="$(printf '%s' "$html" | _ddg_links)"
  if [[ -z "$links" ]]; then
    # Настоящая страница выдачи узнаётся по форме поиска. Если она есть,
    # а ссылок нет — значит, поисковик честно ничего не нашёл.
    if grep -qiE 'name="q"|id="search_form|No results|Нет результатов' <<<"$html"; then
      return 2
    fi
    return 1
  fi
  snips="$(printf '%s' "$html" | _ddg_snippets)"
  paste -d'\t' <(printf '%s\n' "$links") <(printf '%s\n' "$snips") 2>/dev/null \
    || printf '%s\n' "$links"
}

_try_ddg() {     # $1 = запрос, $2 = lite_get | lite_post | html
  local q="$1" mode="$2" html code tmp
  tmp="$(mktemp)"
  case "$mode" in
    lite_get)
      code="$(curl -sSL --connect-timeout 6 --max-time 15 --compressed \
              -A "$UA" -H 'Accept-Language: ru,en;q=0.8' \
              -G --data-urlencode "q=$q" ${WS_DF:+--data-urlencode "df=$WS_DF"} "${TA_DDG_LITE_URL:-https://lite.duckduckgo.com/lite/}" \
              -o "$tmp" -w '%{http_code}' 2>/dev/null)" ;;
    lite_post)
      code="$(curl -sSL --connect-timeout 6 --max-time 15 --compressed \
              -A "$UA" -H 'Accept-Language: ru,en;q=0.8' \
              -H 'Content-Type: application/x-www-form-urlencoded' \
              --data-urlencode "q=$q" ${WS_DF:+--data-urlencode "df=$WS_DF"} "${TA_DDG_LITE_URL:-https://lite.duckduckgo.com/lite/}" \
              -o "$tmp" -w '%{http_code}' 2>/dev/null)" ;;
    html)
      code="$(curl -sSL --connect-timeout 6 --max-time 15 --compressed \
              -A "$UA" -H 'Accept-Language: ru,en;q=0.8' \
              -G --data-urlencode "q=$q" ${WS_DF:+--data-urlencode "df=$WS_DF"} "${TA_DDG_HTML_URL:-https://html.duckduckgo.com/html/}" \
              -o "$tmp" -w '%{http_code}' 2>/dev/null)" ;;
  esac
  html="$(cat "$tmp" 2>/dev/null)"; rm -f "$tmp"
  _dbg "$mode: код $code, получено ${#html} байт"
  [[ "$code" == "200" ]] || return 1
  if _is_challenge "$html"; then _dbg "$mode: страница-заглушка, ищем дальше"; return 1; fi
  _ddg_parse "$html"
  local rc=$?
  (( rc == 2 )) && _dbg "$mode: поисковик ответил, но ничего не нашёл"
  return $rc
}

_try_searxng() {
  local q="$1" base
  base="$(cfg_setting searxng_url "")"
  [[ -n "$base" ]] || return 1
  base="${base%/}"
  local out
  out="$(curl -sSL --connect-timeout 6 --max-time 20 -A "$UA" \
        -G --data-urlencode "q=$q" --data 'format=json&safesearch=0' \
        "$base/search" 2>/dev/null | jq -r '.results[]? | "\(.url)\t\(.title)\t\(.content // "")"' 2>/dev/null)"
  _dbg "searxng ($base): строк $(printf '%s' "$out" | grep -c '' )"
  [[ -n "$out" ]] && printf '%s' "$out"
}

_try_brave() {
  local q="$1" key
  key="$(cfg_setting search_api_key "")"
  [[ -n "$key" ]] || return 1
  curl -sSL --connect-timeout 6 --max-time 20 -H "X-Subscription-Token: $key" \
       -H 'Accept: application/json' -G --data-urlencode "q=$q" \
       'https://api.search.brave.com/res/v1/web/search' 2>/dev/null \
  | jq -r '.web.results[]? | "\(.url)\t\(.title)\t\(.description // "")"' 2>/dev/null
}

# ── прицельные источники по API: стабильный JSON вместо разбора разметки ──
_try_github() {
  local q="$1" n="$2" qq="$1" out
  [[ -n "${WS_SINCE:-}" ]] && qq="$qq updated:>=$WS_SINCE"
  local -a h=(-H 'Accept: application/vnd.github+json')
  [[ -n "${GITHUB_TOKEN:-${GH_TOKEN:-}}" ]] && h+=(-H "Authorization: Bearer ${GITHUB_TOKEN:-$GH_TOKEN}")
  out="$(curl -sSL --compressed --connect-timeout 6 --max-time 20 -A termux-agent "${h[@]}" \
        -G --data-urlencode "q=$qq" --data "per_page=$n" \
        'https://api.github.com/search/issues' 2>/dev/null)"
  _dbg "github: $(jq -r '.total_count // .message // "нет ответа"' <<<"$out" 2>/dev/null)"
  jq -r '.items[]? | "\(.html_url)\t\(.title) [\(.state)\(if .pull_request then ", PR" else "" end)]\t\(.repository_url | sub(".*/repos/"; "")) · \(.updated_at[0:10]) · комментариев \(.comments) · \(((.body // "") | gsub("[\r\n]+"; " "))[0:220])"' <<<"$out" 2>/dev/null
}

_try_stackoverflow() {
  local q="$1" n="$2"
  curl -sSL --compressed --connect-timeout 6 --max-time 20 -A "$UA" \
       -G --data-urlencode "q=$q" --data "site=stackoverflow&sort=relevance&order=desc&pagesize=$n" \
       'https://api.stackexchange.com/2.3/search/advanced' 2>/dev/null \
  | jq -r '.items[]? | "\(.link)\t\(.title)\t голосов \(.score) · ответов \(.answer_count)\(if .accepted_answer_id then " · есть принятый" else "" end) · \(.tags | join(", "))"' 2>/dev/null
}

_try_npm() {
  local q="$1" n="$2"
  curl -sSL --compressed --connect-timeout 6 --max-time 20 -A "$UA" \
       -G --data-urlencode "text=$q" --data "size=$n" 'https://registry.npmjs.org/-/v1/search' 2>/dev/null \
  | jq -r '.objects[]?.package | "https://www.npmjs.com/package/\(.name)\t\(.name) \(.version)\t\(.description // "") · \((.date // "")[0:10])"' 2>/dev/null
}

# Последний рубеж: Википедия отвечает без ключей и почти всегда доступна.
_try_wikipedia() {
  local q="$1" lang out
  for lang in ru en; do
    out="$(curl -sSL --connect-timeout 6 --max-time 15 -A "$UA" \
          -G --data-urlencode "srsearch=$q" \
          --data 'action=query&list=search&format=json&srlimit=5' \
          "https://$lang.wikipedia.org/w/api.php" 2>/dev/null \
        | jq -r --arg l "$lang" '.query.search[]? |
            "https://\($l).wikipedia.org/wiki/\(.title|gsub(" ";"_"))\t\(.title)\t\(.snippet|gsub("<[^>]*>";""))"' 2>/dev/null)"
    _dbg "wikipedia/$lang: строк $(printf '%s' "$out" | grep -c '')"
    [[ -n "$out" ]] && { printf '%s' "$out"; return 0; }
  done
  return 1
}

tool_run() {
  local q n raw engine src rec rd
  q="$(arg query)"; [[ -n "$q" ]] || die "пустой запрос"
  n="$(arg max_results 6)"; [[ "$n" =~ ^[0-9]+$ ]] || n=6; (( n > 15 )) && n=15; (( n < 1 )) && n=6
  src="$(arg source web)"
  rec="$(arg recency)"
  rd="$(arg read 0)"; [[ "$rd" =~ ^[0-9]+$ ]] || rd=0; (( rd > 3 )) && rd=3
  have curl || die "нет curl: pkg install curl"

  WS_DF=""; WS_SINCE=""
  case "$rec" in
    day)   WS_DF=d; WS_SINCE="$(date -d '-1 day'   +%F 2>/dev/null)" ;;
    week)  WS_DF=w; WS_SINCE="$(date -d '-7 days'  +%F 2>/dev/null)" ;;
    month) WS_DF=m; WS_SINCE="$(date -d '-1 month' +%F 2>/dev/null)" ;;
    year)  WS_DF=y; WS_SINCE="$(date -d '-1 year'  +%F 2>/dev/null)" ;;
  esac

  local empty=0 source=""
  case "$src" in
    github)        raw="$(_try_github "$q" "$n")";        source="github (issues и PR)" ;;
    stackoverflow) raw="$(_try_stackoverflow "$q" "$n")"; source="stackoverflow" ;;
    npm)           raw="$(_try_npm "$q" "$n")";           source="npm" ;;
    wiki)          raw="$(_try_wikipedia "$q")";          source="википедия" ;;
  esac
  if [[ "$src" != web && -n "$src" ]]; then
    if [[ -z "$raw" ]]; then
      printf 'Источник %s ничего не вернул по запросу: %s\n' "$src" "$q"
      [[ "$src" == github ]] && printf 'У GitHub без токена лимит 10 поисков в минуту; export GITHUB_TOKEN=… его снимает.\n'
      printf 'Попробуй source=web или короче запрос.\n'
      return 0
    fi
  else
    engine="${TA_SEARCH_ENGINE:-duckduckgo}"
    case "$engine" in
      brave)   raw="$(_try_brave "$q")" ;;
      searxng) raw="$(_try_searxng "$q")" ;;
    esac

    if [[ -z "${raw:-}" ]]; then
      local m
      for m in lite_get lite_post html; do
        raw="$(_try_ddg "$q" "$m")"
        case $? in
          0) source="duckduckgo"; break ;;
          2) empty=1; source="duckduckgo"; break ;;   # честно ничего не нашлось
          *) raw="" ;;
        esac
      done
      if [[ -z "$raw" ]] && (( empty == 0 )); then
        raw="$(_try_searxng "$q")" && source="searxng"
      fi
      # Поисковики недоступны — сначала StackOverflow (агент почти всегда ищет
      # ошибку), потом Википедия. Когда поисковик честно ответил «ничего не
      # найдено», запасные не зовём: иначе точный запрос получает случайную выдачу.
      if [[ -z "$raw" ]] && (( empty == 0 )); then
        raw="$(_try_stackoverflow "$q" "$n")" && [[ -n "$raw" ]] && source="stackoverflow (поисковики недоступны)"
      fi
      if [[ -z "$raw" ]] && (( empty == 0 )); then
        raw="$(_try_wikipedia "$q")" && source="википедия (поисковики недоступны)"
      fi
    else
      source="$engine"
    fi

    if (( empty == 1 )) && [[ -z "$raw" ]]; then
      printf 'По запросу ничего не найдено: %s\n\n' "$q"
      case "$q" in
        *site:*/*)
          printf 'Похоже, дело в операторе site: он работает только с доменом, без пути.
Вместо  site:github.com/termux/termux-app  пиши  site:github.com termux-app
или добавь ключевые слова обычным текстом.\n' ;;
        *)
          printf 'Переформулируй: убери кавычки и лишние операторы, оставь ключевые слова
или точный текст ошибки. Для ошибок есть source=github и source=stackoverflow.\n' ;;
      esac
      return 0
    fi

    if [[ -z "$raw" ]]; then
      printf 'Поиск ничего не вернул. Ни один движок не ответил пригодной выдачей.
Возможные причины: нет сети, провайдер блокирует DuckDuckGo, поисковик отдаёт
страницу-заглушку. Что можно сделать:
  source=github / source=stackoverflow — поиск через их API, в обход поисковиков
  ta search "%s"            — та же проверка с подробной диагностикой
  ta set searxng_url URL    — свой инстанс SearXNG с поддержкой JSON' "$q"
      return 0
    fi
  fi

  [[ -n "$source" ]] && printf 'источник: %s\n\n' "$source"
  local i=0 url title snip key
  local -A seen=()
  local -a urls=()
  while IFS=$'\t' read -r url title snip; do
    [[ -z "$url" ]] && continue
    case "$url" in
      *uddg=*) url="${url##*uddg=}"; url="${url%%&*}"; url="$(urldecode "$url")" ;;
    esac
    case "$url" in //*) url="https:$url" ;; esac
    case "$url" in *duckduckgo.com/y.js*|*duckduckgo.com/l/*|*bing.com/aclick*) continue ;; esac
    # одна и та же страница с разным хвостом (#якорь, ?utm) — один результат
    key="${url%%#*}"; key="${key%%\?utm_*}"; key="${key%/}"
    [[ -n "${seen[$key]:-}" ]] && continue
    seen[$key]=1
    (( i++ )); (( i > n )) && break
    urls+=("$url")
    printf '%d. %s\n   %s\n' "$i" "$(printf '%s' "$title" | html_unescape)" "$url"
    [[ -n "$snip" ]] && printf '   %s\n' "$(printf '%s' "${snip:0:300}" | html_unescape)"
  done <<< "$raw"
  (( i == 0 )) && { printf 'Ничего не найдено по запросу: %s' "$q"; return 0; }

  (( rd > 0 )) || return 0
  # Чтение первых ссылок — параллельно, каждая со своим таймаутом.
  source "$TA_HOME/lib/web.sh"
  local tmpd; tmpd="$(mktemp -d)"
  local budget=$(( ( ${TA_OUT_LIMIT:-8000} - 2500 ) / rd )); (( budget < 700 )) && budget=700
  local k
  for (( k=0; k<rd && k<${#urls[@]}; k++ )); do
    ( t="$(WEB_TIMEOUT=20 WEB_DEADLINE=35 web_read "${urls[$k]}" 2>/dev/null | tail -n +2)"
      if f="$(printf '%s\n' "$t" | web_fragments "$q" "$budget")" && [[ -n "$f" ]]; then
        printf '%s\n' "$f"
      elif [[ -n "${t//[[:space:]]/}" ]]; then
        printf '(слов запроса нет, начало страницы)\n%s\n' "${t:0:$(( budget / 2 ))}"
      else
        printf '(не удалось прочитать)\n'
      fi ) > "$tmpd/$k" 2>/dev/null &
  done
  wait
  for (( k=0; k<rd && k<${#urls[@]}; k++ )); do
    printf '\n══ %d. %s\n' "$(( k + 1 ))" "${urls[$k]}"
    cat "$tmpd/$k" 2>/dev/null
  done
  rm -rf "$tmpd"
  printf '\n(подробнее — web_fetch с find по нужной ссылке)\n'
  return 0
}
