#!/usr/bin/env bash
# План работ: агент ведёт чек-лист, пользователь видит прогресс.

tool_meta() {
cat <<'JSON'
{
  "name": "todo",
  "description": "Вести список шагов задачи. Вызывай в начале сложной задачи (3+ шага), чтобы показать план, и после каждого выполненного шага — чтобы отметить прогресс. Передавай ВЕСЬ список целиком каждый раз. Для простых задач в один-два шага не нужен.",
  "parameters": {
    "type": "object",
    "properties": {
      "items": {
        "type": "array",
        "description": "Полный список шагов",
        "items": {
          "type": "object",
          "properties": {
            "text": {"type": "string", "description": "Что сделать"},
            "status": {"type": "string", "description": "todo | doing | done | failed"}
          },
          "required": ["text", "status"]
        }
      }
    },
    "required": ["items"]
  },
  "x_interactive": true,
  "x_guard": false
}
JSON
}

tool_run() {
  local items; items="$(argj items)"
  [[ -n "$items" && "$items" != "null" ]] || die "пустой список"

  source "$TA_HOME/lib/ui.sh"; ui_init
  if { : > /dev/tty; } 2>/dev/null; then
  {
    printf '\n%s%s план%s\n' "$C_DIM" "─────" "$C_RESET"
    jq -r '.[] | "\(.status)\t\(.text)"' <<<"$items" | while IFS=$'\t' read -r st tx; do
      case "$st" in
        done)   printf '  %s✓%s %s%s%s\n' "$C_GRN" "$C_RESET" "$C_DIM" "$tx" "$C_RESET" ;;
        doing)  printf '  %s▸%s %s%s%s\n' "$C_CYA" "$C_RESET" "$C_B" "$tx" "$C_RESET" ;;
        failed) printf '  %s✗%s %s\n' "$C_RED" "$C_RESET" "$tx" ;;
        *)      printf '  %s○%s %s%s%s\n' "$C_GRY" "$C_RESET" "$C_GRY" "$tx" "$C_RESET" ;;
      esac
    done
    printf '\n'
  } > /dev/tty
  fi

  local done_n total
  done_n="$(jq '[.[] | select(.status=="done")] | length' <<<"$items")"
  total="$(jq 'length' <<<"$items")"
  printf 'План обновлён: выполнено %s из %s.' "$done_n" "$total"
}
