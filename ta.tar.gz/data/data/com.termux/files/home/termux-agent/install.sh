#!/usr/bin/env bash
# Установка termux-agent. Запуск: bash install.sh
set -uo pipefail

SRC="$(cd -P "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST="${TA_DEST:-$HOME/.termux-agent}"
BINDIR="${PREFIX:-/usr/local}/bin"
mkdir -p "$BINDIR" 2>/dev/null
[[ -w "$BINDIR" ]] || BINDIR="$HOME/bin"

say()  { printf '\033[38;5;80m•\033[0m %s\n' "$*"; }
ok()   { printf '\033[38;5;114m✓\033[0m %s\n' "$*"; }
warn() { printf '\033[38;5;179m!\033[0m %s\n' "$*"; }

printf '\n\033[1mУстановка termux-agent\033[0m\n\n'

# 1. зависимости
missing=()
for c in bash jq curl; do command -v "$c" >/dev/null || missing+=("$c"); done
if (( ${#missing[@]} )); then
  say "ставлю зависимости: ${missing[*]}"
  if command -v pkg >/dev/null;      then pkg install -y "${missing[@]}"
  elif command -v apt-get >/dev/null; then apt-get install -y "${missing[@]}"
  else warn "поставь вручную: ${missing[*]}"; fi
fi
command -v termux-notification >/dev/null || say "подсказка: pkg install termux-api — уведомления и /copy в буфер"

# 2. копирование
say "копирую в $DEST"
mkdir -p "$DEST"
cp -r "$SRC/ta" "$SRC/lib" "$SRC/providers" "$SRC/tools" "$SRC/docs" "$DEST/" 2>/dev/null
cp "$SRC/README.md" "$DEST/" 2>/dev/null
chmod +x "$DEST/ta"

# 3. ссылка в PATH
mkdir -p "$BINDIR"
ln -sf "$DEST/ta" "$BINDIR/ta"
ok "команда ta → $BINDIR/ta"
case ":$PATH:" in
  *":$BINDIR:"*) ;;
  *) warn "добавь в ~/.bashrc:  export PATH=\"\$PATH:$BINDIR\"" ;;
esac

# 4. каталоги данных
mkdir -p "${XDG_CONFIG_HOME:-$HOME/.config}/termux-agent/tools"
mkdir -p "${XDG_DATA_HOME:-$HOME/.local/share}/termux-agent/sessions"

printf '\n'
ok "готово"
printf '\nДальше:\n  \033[1mta setup\033[0m    — выбрать провайдера и вставить ключ\n  \033[1mta doctor\033[0m   — проверить, что всё работает\n  \033[1mta\033[0m          — запустить агента\n\n'
