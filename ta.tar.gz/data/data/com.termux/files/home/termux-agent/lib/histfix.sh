#!/usr/bin/env bash
# lib/histfix.sh — починка вызовов инструментов и истории перед отправкой в API.
#
# Бесплатные и экзотические модели (и прокладки между ними и OpenRouter) иногда
# присылают вызовы в странном виде: без имени, с пустым id, с одинаковыми id,
# с аргументами, которые не JSON. Раньше такой вызов попадал в историю как есть,
# и следующий запрос падал с «API 400» — причём навсегда, потому что кривое
# сообщение уже лежало в истории и уезжало в каждый новый запрос.
#
# Здесь две линии обороны:
#   1. toolcalls_fix — чинит свежий ответ модели до того, как он попадёт в историю;
#   2. HISTFIX_JQ    — при каждой отправке приводит всю историю к виду, который
#                      примет любой API. Спасает и старые, уже испорченные сессии.

[[ -n "${HISTFIX_JQ:-}" ]] && return 0

# jq-определение fixhist: массив сообщений → массив сообщений.
#  • вызовы без имени выбрасываются, имена приводятся к [A-Za-z0-9_-]{1,64};
#  • id делаются непустыми и уникальными на всю историю;
#  • результат инструмента привязывается к своему вызову (по id, затем по имени),
#    осиротевшие результаты выбрасываются;
#  • вызовам, у которых нет результата, дописывается заглушка — иначе API
#    откажется принимать следующее сообщение;
#  • пустые ответы ассистента (ни текста, ни вызовов) выбрасываются.
HISTFIX_JQ='
def _hf_name: tostring | sub("^(functions?|tools?)[.:]"; "") | gsub("[^A-Za-z0-9_-]"; "_") | .[0:64];
def _hf_str: if . == null then "" elif type == "string" then . else tojson end;
def _hf_close:
  if (.pend | length) > 0 then
    .out += [.pend[] | {role: "tool", tool_call_id: .new, name: .name,
                        content: "Результата нет: выполнение было прервано."}]
    | .pend = []
  else . end;
def fixhist:
  (reduce .[] as $m ({out: [], pend: [], used: {}, n: 0};
      (if $m.role != "tool" then _hf_close else . end)
      | if $m.role == "assistant" then
          (reduce [($m.tool_calls // [])[] | select(((.name // "") | _hf_str | _hf_name) != "")][] as $c
              (. + {cur: []};
                .n += 1
                | (($c.id // "") | _hf_str) as $id
                | (if $id == "" or (.used[$id] // false) then "call_h\(.n)" else $id end) as $nid
                | .used[$nid] = true
                | .cur += [{orig: $id, new: $nid, name: ($c.name | _hf_str | _hf_name),
                            arguments: (($c.arguments // {}) | if type == "object" then . else {} end)}])) as $st
          | $st.cur as $cur
          | ($m.content // "" | _hf_str) as $txt
          | if ($cur | length) == 0 and ($txt | test("^\\s*$")) then $st | del(.cur)
            else
              ($st | del(.cur))
              | .out += [ ($m | del(.tool_calls))
                          + (if ($cur | length) > 0
                             then {tool_calls: ($cur | map({id: .new, name: .name, arguments: .arguments}))}
                             else {} end) ]
              | .pend = $cur
            end
        elif $m.role == "tool" then
          (($m.tool_call_id // "") | _hf_str) as $tid
          | (($m.name // "") | _hf_str | _hf_name) as $tn
          | ((.pend | map(.orig) | index($tid))
             // (if $tn != "" then (.pend | map(.name) | index($tn)) else null end)) as $j
          | if $j == null then .
            else
              .pend[$j] as $p
              | .out += [ $m + {tool_call_id: $p.new, name: $p.name, content: ($m.content | _hf_str)} ]
              | .pend = (.pend[0:$j] + .pend[$j+1:])
            end
        else
          .out += [$m]
        end)
   | _hf_close | .out);
'

# toolcalls_fix <сообщение-json> [файл схемы инструментов]
# Печатает исправленное сообщение. В поле .notes — что пришлось поправить
# (для показа пользователю; из истории это поле потом убирается).
toolcalls_fix() {
  local msg="$1" schema="${2:-${TA_TMP:-/tmp}/tools_schema.json}" tools='[]'
  [[ -s "$schema" ]] && tools="$(cat "$schema" 2>/dev/null)"
  jq -c --argjson tools "${tools:-[]}" --arg pfx "$(date +%s)$RANDOM" '
    def cleanname: tostring | sub("^(functions?|tools?)[.:]"; "") | gsub("[^A-Za-z0-9_-]"; "_") | .[0:64];
    # По набору аргументов угадать инструмент: обязательные есть, лишних нет.
    def infer($a):
      ($a | keys) as $k
      | [ $tools[]
          | select((((.parameters.required // []) - $k) | length) == 0
                   and (($k - ((.parameters.properties // {}) | keys)) | length) == 0)
          | .name ]
      | if length == 1 then .[0] else null end;
    .notes = (.notes // [])
    | reduce ((.tool_calls // []) | to_entries[]) as $e (. + {tc2: [], seen: {}};
        $e.value as $c
        | (($c.arguments // {}) | if type == "object" then . else {} end) as $a
        | (($c.name // "") | cleanname) as $n0
        | (if $n0 != "" then $n0 elif ($a | length) > 0 then (infer($a) // "") else "" end) as $n
        | if $n == "" then
            (if ($a | length) > 0 or ($c.bad_args // "") != ""
             then .notes += ["вызов без имени инструмента пропущен" +
                             (if ($a | length) > 0 then " (аргументы: " + ($a | keys | join(", ")) + ")" else "" end)]
             else . end)
          else
            (if $n0 == "" then .notes += ["вызов пришёл без имени — по аргументам это " + $n] else . end)
            | ((($c.id // "") | tostring) as $id
               | if $id == "" or (.seen[$id] // false) then "call_\($pfx)_\($e.key)" else $id end) as $nid
            | .seen[$nid] = true
            | .tc2 += [ {id: $nid, name: $n, arguments: $a}
                        + (if ($c.bad_args // "") != "" then {bad_args: $c.bad_args} else {} end) ]
          end)
    | .tool_calls = .tc2
    | del(.tc2, .seen)' <<<"$msg" 2>/dev/null || printf '%s' "$msg"
}
