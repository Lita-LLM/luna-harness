#!/usr/bin/env bash
tool_meta() {
cat <<'JSON'
{
  "name": "edit_file",
  "description": "Точечная правка файла: замена уникального фрагмента old на new. Фрагмент old должен встречаться ровно один раз, иначе ошибка. Предпочитай этот инструмент вместо перезаписи больших файлов.",
  "parameters": {
    "type": "object",
    "properties": {
      "path": {"type": "string"},
      "old": {"type": "string", "description": "Точный существующий фрагмент"},
      "new": {"type": "string", "description": "Чем заменить (пустая строка — удалить)"},
      "intent": {"type": "string", "description": "ОБЯЗАТЕЛЬНО. Что меняем в файле и зачем"}
    },
    "required": ["path", "old", "new", "intent"]
  },
  "x_confirm": true,
  "x_writes": true
}
JSON
}

tool_run() {
  local p old new n
  p="$(expand_path "$(arg path)")"; [[ -f "$p" ]] || die "нет файла: $p"
  old="$(jq -r '.old // ""' <<<"$TA_TOOL_ARGS"; printf X)"; old="${old%X}"
  new="$(jq -r '.new // ""' <<<"$TA_TOOL_ARGS"; printf X)"; new="${new%X}"
  [[ -n "$old" ]] || die "old пустой"

  n="$(OLD="$old" awk 'BEGIN{RS="\0"} {s=$0; o=ENVIRON["OLD"]; c=0; i=index(s,o); while(i>0){c++; s=substr(s,i+length(o)); i=index(s,o)} print c}' "$p")"
  (( n == 0 )) && die "фрагмент не найден в $p — перечитай файл (read_file)"
  (( n > 1 ))  && die "фрагмент встречается $n раз(а) — добавь контекста для уникальности"

  ckpt_save "$p"; cp "$p" "$p.bak"
  OLD="$old" NEW="$new" awk 'BEGIN{RS="\0"} {
    s=$0; o=ENVIRON["OLD"]; nw=ENVIRON["NEW"]
    i=index(s,o)
    printf "%s%s%s", substr(s,1,i-1), nw, substr(s,i+length(o))
  }' "$p.bak" > "$p" || die "не удалось записать"
  printf 'изменён %s (резервная копия: %s.bak)' "$p" "$p"
}
