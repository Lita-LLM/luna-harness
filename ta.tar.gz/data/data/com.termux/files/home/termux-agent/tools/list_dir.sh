#!/usr/bin/env bash
tool_meta() {
cat <<'JSON'
{
  "name": "list_dir",
  "description": "Показать содержимое каталога (дерево на нужную глубину, с размерами).",
  "parameters": {
    "type": "object",
    "properties": {
      "path": {"type": "string", "description": "Каталог (по умолчанию текущий)"},
      "depth": {"type": "integer", "description": "Глубина обхода, по умолчанию 1"},
      "all": {"type": "boolean", "description": "Показывать скрытые файлы"}
    }
  }
}
JSON
}

tool_run() {
  local p d
  p="$(expand_path "$(arg path "$PWD")")"
  [[ -d "$p" ]] || die "нет каталога: $p"
  d="$(arg depth 1)"; [[ "$d" =~ ^[0-9]+$ ]] || d=1
  printf '%s\n' "$p"
  local fargs=(-mindepth 1 -maxdepth "$d")
  [[ "$(arg all false)" == "true" ]] || fargs+=( -not -path '*/.*' )
  find "$p" "${fargs[@]}" -printf '%y %10s  %P\n' 2>/dev/null | sort -k3 | head -300
  return 0
}
