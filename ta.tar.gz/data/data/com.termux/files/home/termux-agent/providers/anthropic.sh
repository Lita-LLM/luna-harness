#!/usr/bin/env bash
# Провайдер Anthropic Messages API (с расширенным мышлением).

source "${TA_HOME:?}/lib/histfix.sh"

_anth_budget() {
  case "${TA_REASONING:-off}" in
    low) echo 2048 ;; medium) echo 8192 ;; high) echo 16384 ;; *) echo 0 ;;
  esac
}

provider_request() {
  local budget; budget="$(_anth_budget)"
  local maxtok="$TA_MAX_TOKENS"
  (( budget > 0 )) && (( maxtok <= budget )) && maxtok=$(( budget + 4096 ))
  jq -n --slurpfile h "$1" --slurpfile t "$2" \
        --arg model "$TA_MODEL" \
        --argjson temp "$TA_TEMPERATURE" \
        --argjson maxtok "$maxtok" \
        --argjson budget "$budget" \
        --argjson extra "$TA_EXTRA_BODY" "$HISTFIX_JQ"'
    def blocks:
      if .role == "assistant" then
        ((.reasoning_raw // [])
         + (if (.content // "") == "" then [] else [{type: "text", text: .content}] end)
         + ((.tool_calls // []) | map({type: "tool_use", id: .id, name: .name, input: .arguments})))
      elif .role == "tool" then
        [{type: "tool_result", tool_use_id: .tool_call_id, content: (.content | tostring)}]
      else
        [{type: "text", text: .content}]
      end;
    def norole: if .role == "assistant" then "assistant" else "user" end;
    ($h[0] | fixhist | map(select(.role != "system")) | map({role: norole, content: blocks})
      | reduce .[] as $m ([];
          if (length > 0) and (.[-1].role == $m.role)
          then (.[0:-1] + [{role: $m.role, content: (.[-1].content + $m.content)}])
          else . + [$m] end)) as $msgs |
    {
      model: $model,
      max_tokens: $maxtok,
      temperature: (if $budget > 0 then 1 else $temp end),
      system: ($h[0] | map(select(.role == "system") | .content) | join("\n\n")),
      messages: $msgs,
      tools: ($t[0] | map({name: .name, description: .description, input_schema: .parameters}))
    }
    | (if ($t[0] | length) == 0 then del(.tools) else . end)
    | (if $budget > 0 then . + {thinking: {type: "enabled", budget_tokens: $budget}} else . end)
    | . * $extra'
}

provider_send() {
  local key; key="$(cfg_api_key)"
  local -a H=(-H 'Content-Type: application/json' -H 'anthropic-version: 2023-06-01')
  [[ -n "$key" ]] && H+=(-H "x-api-key: $key")
  local h; for h in "${TA_EXTRA_HEADERS[@]}"; do [[ -n "$h" ]] && H+=(-H "$h"); done
  curl -sS --max-time "$TA_HTTP_TIMEOUT" -X POST "${TA_BASE_URL%/}/messages" \
       "${H[@]}" --data-binary @"$1" -o "$2" -w '%{http_code}'
}

provider_parse() {
  jq -c '
    (.content // []) as $c |
    {
      role: "assistant",
      content: ([$c[] | select(.type == "text") | .text] | join("\n")),
      reasoning: ([$c[] | select(.type == "thinking") | .thinking] | join("\n")),
      reasoning_raw: [$c[] | select(.type == "thinking" or .type == "redacted_thinking")],
      tool_calls: [$c[] | select(.type == "tool_use") | {id: .id, name: .name, arguments: (.input // {})}]
    }' "$1"
}

provider_usage() {
  jq -r '"\(.usage.output_tokens // 0) \((.usage.input_tokens // 0) + (.usage.output_tokens // 0))"' "$1" 2>/dev/null || echo "0 0"
}

provider_error() { jq -r '(.error.message // .message // "неизвестная ошибка") | tostring' "$1" 2>/dev/null; }

# Потоковый режим для этого API пока не реализован: ответ приходит целиком.
provider_stream_supported() { return 1; }
