#!/usr/bin/env bash
# lib/toolparse.sh — спасение вызовов инструментов, написанных текстом.
#
# Не все модели умеют структурные tool_calls. Некоторые пишут вызов прямо в
# ответ или даже в рассуждения:
#
#   <invoke name="bash"><parameter name="command">ls -la</parameter></invoke>
#   <tool_call>{"name":"bash","arguments":{"command":"ls -la"}}</tool_call>
#   ```json {"name":"bash","arguments":{…}} ```
#
# Для агента это выглядит как «модель поговорила и ничего не сделала». Здесь мы
# вылавливаем такие вызовы и превращаем в нормальные.

# Разбор XML-образного вида. Печатает построчно: CALL<TAB>имя, PARAM<TAB>ключ<TAB>значение.
_toolparse_xml() {
  awk '
    BEGIN { RS = "\0" }
    {
      s = $0
      while (match(s, /<invoke[ \t]+name[ \t]*=[ \t]*"[^"]+"/)) {
        # позиции надо запомнить: следующий match() их перезапишет
        istart = RSTART; ilen = RLENGTH
        head = substr(s, istart, ilen)
        match(head, /"[^"]+"/); name = substr(head, RSTART+1, RLENGTH-2)
        rest = substr(s, istart + ilen)
        endpos = index(rest, "</invoke>")
        body = (endpos > 0) ? substr(rest, 1, endpos-1) : rest
        print "CALL\t" name
        while (match(body, /<parameter[ \t]+name[ \t]*=[ \t]*"[^"]+"[ \t]*>/)) {
          pstart = RSTART; plen = RLENGTH
          ph = substr(body, pstart, plen)
          match(ph, /"[^"]+"/); key = substr(ph, RSTART+1, RLENGTH-2)
          after = substr(body, pstart + plen)
          e = index(after, "</parameter>")
          val = (e > 0) ? substr(after, 1, e-1) : after
          gsub(/^[ \t\r\n]+|[ \t\r\n]+$/, "", val)
          gsub(/\n/, "\001", val)
          print "PARAM\t" key "\t" val
          body = (e > 0) ? substr(after, e + 12) : ""
        }
        s = (endpos > 0) ? substr(rest, endpos + 9) : ""
      }
    }'
}

# Из текста → массив вызовов во внутреннем формате (или пусто).
toolparse_extract() {
  local text="$1" out="[]" line kind a b name args
  # 1. XML-образный вид
  local parsed; parsed="$(printf '%s' "$text" | _toolparse_xml 2>/dev/null)"
  if [[ -n "$parsed" ]]; then
    name=""; args="{}"
    while IFS=$'\t' read -r kind a b; do
      case "$kind" in
        CALL)
          [[ -n "$name" ]] && out="$(jq -c --arg n "$name" --argjson a "$args" \
            '. + [{id: ("call_" + $n), name: $n, arguments: $a}]' <<<"$out")"
          name="$a"; args="{}" ;;
        PARAM)
          b="${b//$'\001'/$'\n'}"
          args="$(jq -c --arg k "$a" --arg v "$b" '. + {($k): $v}' <<<"$args")" ;;
      esac
    done <<< "$parsed"
    [[ -n "$name" ]] && out="$(jq -c --arg n "$name" --argjson a "$args" \
      '. + [{id: ("call_" + $n), name: $n, arguments: $a}]' <<<"$out")"
  fi

  # 2. JSON-образный вид: <tool_call>{…}</tool_call>, ```json {…} ``` или голый объект
  if [[ "$out" == "[]" ]]; then
    local cleaned
    cleaned="$(printf '%s' "$text" \
      | sed -e 's/<tool_call>/\n/g' -e 's/<\/tool_call>/\n/g' \
            -e 's/```json/\n/g' -e 's/```/\n/g')"
    out="$(printf '%s' "$cleaned" | jq -c -R -s '
      [ splits("\n") | select(test("\"name\"[ \t]*:")) | fromjson? // empty
        | select(type == "object" and has("name"))
        | {id: ("call_" + (.name|tostring)),
           name: (.name|tostring),
           arguments: ((.arguments // .parameters // .input // {})
                       | if type == "string" then (fromjson? // {}) else . end)} ]' 2>/dev/null || echo '[]')"
  fi

  [[ -z "$out" ]] && out="[]"
  printf '%s' "$out"
}

# Вычистить разметку вызова из текста, чтобы она не мозолила глаза в ответе.
toolparse_strip() {
  printf '%s' "$1" | sed -e 's|<[a-z_]*function_call>||g' -e 's|</[a-z_]*function_call>||g' \
    -e 's|<invoke[^>]*>||g' -e 's|</invoke>||g' \
    -e 's|<parameter[^>]*>||g' -e 's|</parameter>||g' \
    -e 's|<tool_call>||g' -e 's|</tool_call>||g'
}
