#!/usr/bin/env bash
# lib/web.sh — общее для web_fetch и web_search.
#
# Всё на curl + jq + awk, без браузеров и питона:
#   web_read <url>          → чистый текст страницы (с кэшем на 15 минут)
#   web_fragments <q> <max> → из текста на stdin только куски вокруг совпадений
#   web_html2text           → HTML на stdin → читаемый текст (заголовки, списки, код)
#
# Для сайтов, где у HTML есть нормальный API, HTML не парсим вовсе:
# GitHub (файлы, README, каталоги, issues/PR, релизы), StackOverflow и прочий
# StackExchange, npm, PyPI. Это и чище, и в разы короче для контекста.

WEB_UA="${UA:-Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36}"
WEB_CACHE="${TA_DATA_DIR:-${TMPDIR:-/tmp}}/webcache"

# ── HTML → текст ────────────────────────────────────────────────────────────
# Один проход awk с RS="<": каждая запись — «тег>текст после него». Работает в
# mawk, gawk и busybox awk. LC_ALL=C — чтобы байты UTF-8 не портились.
#   -v base=URL   для абсолютных ссылок
#   -v links=1    пометить ссылки [N] и перечислить адреса в конце
#
# !!Ни одной склейки вида s = s x в цикле!! В mawk и busybox awk каждая такая
# склейка копирует строку целиком, и страница на пару мегабайт превращалась
# в миллиарды копирований: web_fetch «висел» минутами. gawk спасал только
# отчасти — на большом <pre> с кучей &quot; (исходники, JSON, ответы
# StackOverflow) разбор сущностей тоже был квадратичным. Поэтому:
#   • текст копится кусками в массив A[], а не одной строкой;
#   • сущности разбираются через split по «&», без gsub и substr в цикле;
#   • строки собираются из кусков попарным слиянием (n·log n) и печатаются
#     сразу, без накопления итога.
web_html2text() {
  LC_ALL=C awk -v base="${1:-}" -v links="${2:-0}" '
  function hexval(h,   i, c, v) { v = 0; h = tolower(h)
    for (i = 1; i <= length(h); i++) { c = index("0123456789abcdef", substr(h, i, 1)); if (!c) break; v = v * 16 + c - 1 }
    return v }
  function utf8(n) {
    if (n < 128) return sprintf("%c", n)
    if (n < 2048) return sprintf("%c%c", 192 + int(n / 64), 128 + n % 64)
    if (n < 65536) return sprintf("%c%c%c", 224 + int(n / 4096), 128 + int(n / 64) % 64, 128 + n % 64)
    return sprintf("%c%c%c%c", 240 + int(n / 262144), 128 + int(n / 4096) % 64, 128 + int(n / 64) % 64, 128 + n % 64) }
  # Сущности разбираем через split по «&»: каждый кусок, кроме первого,
  # начинается с имени сущности. Ни gsub, ни substr в цикле по большой строке —
  # busybox awk на них тоже квадратичен.
  function dec(q,   e, v) {   # q — всё, что шло после «&»
    if (match(q, /^[a-z]+;/)) {
      e = substr(q, 1, RLENGTH - 1)
      if (e in ENT) return ENT[e] substr(q, RLENGTH + 1)
    } else if (match(q, /^#[xX][0-9a-fA-F]+;/) || match(q, /^#[0-9]+;/)) {
      e = substr(q, 2, RLENGTH - 2)
      v = (e ~ /^[xX]/) ? hexval(substr(e, 2)) : e + 0
      return ((v > 0 && v < 1114112) ? utf8(v) : "") substr(q, RLENGTH + 1)
    }
    return "&" q }
  # текст с сущностями — сразу в выходной поток, кусками
  function pents(s,   n, i, P) {
    if (index(s, "&") == 0) { put(s); return }
    n = split(s, P, "&"); put(P[1])
    for (i = 2; i <= n; i++) put(dec(P[i]))
  }
  # то же для коротких строк (title, alt): там результат нужен строкой
  function ents(s,   n, i, P, out) {
    if (index(s, "&") == 0) return s
    n = split(s, P, "&"); out = P[1]
    for (i = 2; i <= n; i++) out = out dec(P[i])
    return out }
  # Огромный текстовый узел без тегов: gsub и split по регулярке в busybox awk
  # квадратичны. split по " " (пробелы, табы, переводы строк) линеен везде —
  # режем на слова и отдаём пачками по ~2 КБ, внутри пачки склейки дешёвые.
  function squeeze(t,   n, i, W, buf, w, any) {
    n = split(t, W, " ")
    buf = (t ~ /^[ \t\r\n]/) ? " " : ""; any = 0
    for (i = 1; i <= n; i++) {
      w = W[i]
      if (index(w, "\r")) { gsub(/\r+/, " ", w); gsub(/^ +| +$/, "", w); gsub(/  +/, " ", w) }
      if (w == "") continue
      buf = buf (any ? " " : "") w; any = 1
      if (length(buf) > 2000) { pents(buf); buf = "" }
    }
    if (t ~ /[ \t\r\n]$/) buf = buf " "
    pents(buf) }
  function put(s,   L) {
    if (s == "") return
    A[++na] = s; L = length(s); la += L
    if (inmain > 0) { M[na] = 1; lm += L }
    last2 = (L >= 2) ? substr(s, L - 1) : substr(last2, 2) s }
  function nl(k) {
    if (k == 2) { if (last2 == "\n\n") return; put(substr(last2, 2, 1) == "\n" ? "\n" : "\n\n") }
    else if (substr(last2, 2, 1) != "\n") put("\n") }
  function absurl(u,   o, b) {
    if (u ~ /^[a-zA-Z][a-zA-Z0-9+.-]*:/) return u
    if (u ~ /^#/ || u == "") return ""
    if (u ~ /^\/\//) { match(base, /^[a-zA-Z]+:/); return substr(base, 1, RLENGTH) u }
    match(base, /^[a-zA-Z]+:\/\/[^\/]+/); o = substr(base, 1, RLENGTH)
    if (u ~ /^\//) return o u
    b = base; sub(/[?#].*$/, "", b); if (b !~ /\/$/) sub(/[^\/]*$/, "", b); if (b == "") b = o "/"
    return b u }
  function attr(t, name,   v) {
    if (!match(t, name "[ \t\r\n]*=[ \t\r\n]*(\"[^\"]*\"|\047[^\047]*\047|[^ \t\r\n>]+)")) return ""
    v = substr(t, RSTART, RLENGTH); sub(/^[^=]*=[ \t\r\n]*/, "", v); gsub(/^["\047]|["\047]$/, "", v); return v }

  # ── сборка строк из кусков ──
  function jn(a, b,   m) {
    if (a == b) return B[a]
    if (b == a + 1) return B[a] B[b]
    m = int((a + b) / 2); return jn(a, m) jn(m + 1, b) }
  function flushline(   l) { l = (nb == 0) ? "" : jn(1, nb); nb = 0; line(l) }
  function line(l) {
    if (l ~ /^```/) fence = !fence
    else if (!fence) { sub(/^[ \t]+/, "", l); sub(/[ \t]+$/, "", l)
      # короткие повторы — кнопки и заглушки интерфейса («Copy link», «More options»)
      if (l ~ /^-[ \t]*$/) return
      if (l != "" && length(l) <= 70 && l !~ /^\|/) { if (l in once) return; once[l] = 1 } }
    if (l == "" && !fence) { if (blank) return; blank = 1 } else blank = 0
    emit(l) }
  # пустые строки откладываем: в конце текста они не нужны
  function emit(l) {
    if (l == "") { pend++; return }
    if (!started) { started = 1; if (title != "" && l != "# " title) printf "# %s\n\n", title }
    while (pend > 0) { printf "\n"; pend-- }
    printf "%s\n", l }

  BEGIN {
    ENT["nbsp"] = " "; ENT["lt"] = "<"; ENT["gt"] = ">"; ENT["quot"] = "\""; ENT["apos"] = "\047"
    ENT["amp"] = "&"; ENT["mdash"] = "—"; ENT["ndash"] = "–"; ENT["hellip"] = "…"
    ENT["laquo"] = "«"; ENT["raquo"] = "»"; ENT["copy"] = "©"
    RS = "<"; last2 = "\n\n"; raw = ""; skip = 0; pre = 0; inmain = 0; nlinks = 0; title = ""; intitle = 0; na = 0 }
  {
    rec = $0
    if (NR == 1) { pents(rec); next }
    if (incomment) { p = index(rec, "-->"); if (!p) next; incomment = 0; rec = substr(rec, p + 3); if (!skip && raw == "") pents(rec); next }
    if (substr(rec, 1, 3) == "!--") {
      p = index(rec, "-->"); if (!p) { incomment = 1; next }
      rec = substr(rec, p + 3); if (!skip && raw == "") pents(rec); next }
    p = index(rec, ">")
    # «<» без тега («a < b» в тексте) — это текст, а не начало тега
    if (p == 0 || (raw == "" && rec !~ /^[a-zA-Z\/!?]/)) {
      if (intitle) title = title "<" rec
      else if (raw == "" && !skip) { put("<"); pents(rec) }
      next }
    tag = substr(rec, 1, p - 1); txt = substr(rec, p + 1)
    isclose = (substr(tag, 1, 1) == "/")
    name = tolower(isclose ? substr(tag, 2) : tag); sub(/[ \t\r\n\/].*$/, "", name)

    # содержимое script/style — сырой текст, внутри «<» ничего не значит
    if (raw != "") { if (isclose && name == raw) raw = ""; next }
    if (!isclose && name ~ /^(script|style|noscript|template|svg|iframe|textarea|select)$/) { if (tag !~ /\/$/) raw = name; next }

    if (name ~ /^(nav|footer|aside|form|dialog)$/) { skip += isclose ? -1 : 1; if (skip < 0) skip = 0; next }
    if (name == "title") { intitle = !isclose; if (!isclose) title = ""; if (intitle) title = title txt; next }
    if (intitle) { title = title txt; next }
    if (name == "main" || name == "article") { inmain += isclose ? -1 : 1; if (inmain < 0) inmain = 0 }
    if (skip) next

    if (name ~ /^h[1-6]$/) { if (isclose) nl(2); else { nl(2); put(substr("######", 1, substr(name, 2) + 0) " ") } }
    else if (name == "li") { if (!isclose) { nl(1); put("- ") } }
    else if (name == "br") nl(1)
    else if (name == "pre") { if (!isclose) { nl(2); put("```"); nl(1) } else { nl(1); put("```"); nl(2) }; pre = !isclose }
    else if (name == "code" && !pre) put("`")
    else if (name ~ /^(td|th)$/) { if (!isclose) put(" | ") }
    else if (name == "hr") { nl(1); put("---"); nl(1) }
    else if (name == "img" && !isclose) { a = attr(tag, "alt"); if (a != "") put("[" ents(a) "]") }
    else if (name == "a" && links) {
      if (!isclose) { href = absurl(attr(tag, "href")) }
      else if (href != "" && href !~ /^javascript:/) {
        if (!(href in seen)) { seen[href] = ++nlinks; order[nlinks] = href }
        put("[" seen[href] "]"); href = "" } }
    else if (name ~ /^(p|div|tr|table|ul|ol|dl|dt|dd|section|article|main|header|blockquote|figure|figcaption|details|summary|center)$/) nl(1)

    if (txt == "") next
    if (pre) pents(txt)
    else if (length(txt) < 4096) { gsub(/[ \t\r\n]+/, " ", txt); pents(txt) }
    else squeeze(txt)
  }
  END {
    usemain = (lm >= 400 && lm * 5 >= la)
    gsub(/[ \t\r\n]+/, " ", title); title = ents(title); sub(/^ /, "", title); sub(/ $/, "", title)
    nb = 0; blank = 1; fence = 0; started = 0; pend = 0
    for (i = 1; i <= na; i++) {
      if (usemain && !(i in M)) continue
      s = A[i]; delete A[i]
      if (index(s, "\n") == 0) { B[++nb] = s; continue }
      n = split(s, P, "\n")
      # split("x\n") даёт ["x", ""]: всё, кроме последнего, — законченные строки
      for (k = 1; k < n; k++) { B[++nb] = P[k]; flushline() }
      if (P[n] != "") B[++nb] = P[n]
    }
    if (nb > 0) flushline()
    if (!started && title != "") printf "# %s\n\n", title
    if (links && nlinks) { printf "\nСсылки:\n"; for (i = 1; i <= nlinks; i++) printf "[%d] %s\n", i, order[i] }
  }'
}

# ── куски текста вокруг совпадений ──────────────────────────────────────────
# web_fragments "запрос" <лимит символов>; текст на stdin.
# Ранжирование по числу разных слов запроса в окне ±2 строки; выводятся лучшие
# окна в порядке документа. Регистр не важен (и для кириллицы: grep -i).
web_fragments() {
  local q="$1" max="${2:-3000}" tmp; tmp="$(mktemp)"
  cat > "$tmp"
  local -a pat=(); local w
  for w in $q; do
    w="${w//[\"\'\`(),;<>{\}]/}"; w="${w//\[/}"; w="${w//\]/}"
    (( ${#w} >= 3 )) && pat+=(-e "$w")
  done
  (( ${#pat[@]} )) || { head -c "$max" "$tmp"; rm -f "$tmp"; return 0; }
  grep -n -o -i -F "${pat[@]}" "$tmp" 2>/dev/null \
  | LC_ALL=C awk -F: -v max="$max" -v file="$tmp" -v terms="$q" '
      { k = $1 SUBSEP tolower($2); if (!(k in d)) { d[k] = 1; sc[$1]++ } }
      END {
        nt = split(terms, T, " ")
        top = 0; for (l in sc) if (sc[l] > top) top = sc[l]
        while ((getline line < file) > 0) text[++total] = line
        # Лучшие окна — сначала с большим числом разных слов, при равенстве —
        # раньше по тексту. Очки — маленькие целые (не больше числа слов), так что
        # вместо сортировки проходим по очкам сверху вниз: O(слов · строк).
        # Сортировка вставками была квадратичной и на большой странице с частым
        # словом (десятки тысяч совпадений) вешала web_fetch на минуты.
        used = 0
        for (s = top; s >= 1 && used < max; s--)
          for (y = 1; y <= total && used < max; y++) {
            if (!(y in sc) || sc[y] != s) continue
            a = y - 2; b = y + 2; if (a < 1) a = 1; if (b > total) b = total
            dup = 0; for (x = a; x <= b; x++) if (x in take) dup++
            if (dup == b - a + 1) continue
            for (x = a; x <= b; x++) if (!(x in take)) { take[x] = 1; used += (length(text[x]) > 500 ? 500 : length(text[x])) + 1 }
          }
        if (used == 0) exit 1
        prev = -1
        for (x = 1; x <= total; x++) if (x in take) {
          if (prev >= 0 && x != prev + 1) print "…"
          l = text[x]
          # простыни в одну строку (таблицы, минифицированный код) режем,
          # не разрывая многобайтовый символ UTF-8
          if (length(l) > 500) {
            st = 1; ll = tolower(l)
            for (ti = 1; ti <= nt; ti++) { q = index(ll, tolower(T[ti])); if (q > 0 && (st == 1 || q - 200 < st)) st = q - 200 }
            if (st < 1) st = 1
            pre = (st > 1) ? "… " : ""; l = substr(l, st, 500)
            sub(/^[\200-\277]+/, "", l); sub(/[\300-\367][\200-\277]*$/, "", l); l = pre l " …" }
          print l; prev = x }
      }' 2>/dev/null | head -c "$(( max * 2 ))"
  local rc=${PIPESTATUS[1]}
  rm -f "$tmp"
  return $rc
}

# ── сеть ────────────────────────────────────────────────────────────────────
# web_get <url> <файл тела> [доп. аргументы curl…] → печатает «код<TAB>content-type»
web_get() {
  local url="$1" out="$2"; shift 2
  curl -sSL --compressed --connect-timeout 8 --max-time "${WEB_TIMEOUT:-30}" --max-filesize 8000000 \
       -A "$WEB_UA" -H 'Accept-Language: ru,en;q=0.8' "$@" \
       -o "$out" -w '%{http_code}\t%{content_type}' "$url" 2>/dev/null
}

_web_gh() {   # GitHub API: без токена 60 запросов в час, с GITHUB_TOKEN — 5000
  local -a h=(-H 'Accept: application/vnd.github+json')
  [[ -n "${GITHUB_TOKEN:-${GH_TOKEN:-}}" ]] && h+=(-H "Authorization: Bearer ${GITHUB_TOKEN:-$GH_TOKEN}")
  curl -sSL --compressed --connect-timeout 8 --max-time 25 -A "termux-agent" "${h[@]}" "$@" 2>/dev/null
}

# Особые сайты. Печатает текст и возвращает 0, либо 1 — «не наш случай».
_web_special() {
  local url="$1" u="${1%%#*}" m
  # ── GitHub ──
  if [[ "$u" =~ ^https?://(www\.)?github\.com/([^/]+)/([^/?]+)(/(.*))?$ ]]; then
    local o="${BASH_REMATCH[2]}" r="${BASH_REMATCH[3]%.git}" rest="${BASH_REMATCH[5]%%\?*}"
    local api="https://api.github.com/repos/$o/$r"
    local j printed=""
    case "$rest" in
      blob/*|raw/*)
        curl -sSLf --connect-timeout 8 --max-time 25 -A "$WEB_UA" "https://raw.githubusercontent.com/$o/$r/${rest#*/}" 2>/dev/null && return 0
        return 1 ;;
      issues/[0-9]*|pull/[0-9]*)
        local num="${rest#*/}"; num="${num%%/*}"
        j="$(_web_gh "$api/issues/$num")"
        # лимит API исчерпан или нет доступа — пусть читается обычная страница
        jq -e '.number' <<<"$j" >/dev/null 2>&1 || return 1
        jq -r '"# \(.title)\n\(if .pull_request then "PR" else "issue" end) #\(.number) · \(.state) · \(.user.login) · \(.created_at[0:10]) · комментариев: \(.comments)\(if (.labels | length) > 0 then "\nметки: " + ([.labels[].name] | join(", ")) else "" end)\n\n\(.body // "")"' <<<"$j"
        _web_gh "$api/issues/$num/comments?per_page=50" | jq -r '
          if type == "array" then .[] | "\n---\n\(.user.login) · \(.created_at[0:10])\(if (.reactions["+1"] // 0) > 0 then " · 👍\(.reactions["+1"])" else "" end)\n\(.body // "")" else empty end' 2>/dev/null
        return 0 ;;
      issues|issues/|pulls|pulls/)
        j="$(_web_gh "$api/issues?state=all&per_page=30")"
        jq -e 'type == "array"' <<<"$j" >/dev/null 2>&1 || return 1
        jq -r '.[] | "#\(.number) [\(.state)] \(.title) · \(.updated_at[0:10])"' <<<"$j"
        return 0 ;;
      releases*)
        j="$(_web_gh "$api/releases?per_page=5")"
        jq -e 'type == "array"' <<<"$j" >/dev/null 2>&1 || return 1
        jq -r '.[] | "## \(.tag_name) · \((.published_at // "")[0:10])\(if .prerelease then " · pre" else "" end)\n\((.body // "")[0:1500])\nфайлы: \([.assets[].name] | join(", "))\n"' <<<"$j"
        return 0 ;;
      ""|tree/*)
        local path="" ref=""
        if [[ "$rest" == tree/* ]]; then rest="${rest#tree/}"; ref="${rest%%/*}"; [[ "$rest" == */* ]] && path="${rest#*/}"; fi
        j="$(_web_gh "$api")"
        jq -e '.full_name' <<<"$j" >/dev/null 2>&1 && { printed=1
          jq -r '"# \(.full_name)\n\(.description // "")\n★\(.stargazers_count) · обновлён \(.pushed_at[0:10]) · ветка \(.default_branch)\(if .archived then " · АРХИВ" else "" end)\n"' <<<"$j"; }
        j="$(_web_gh "$api/contents/$path${ref:+?ref=$ref}")"
        jq -e 'type == "array"' <<<"$j" >/dev/null 2>&1 && { printed=1
          jq -r '"Файлы:\n" + ([.[] | "  " + .name + (if .type == "dir" then "/" else "" end)] | join("\n")) + "\n"' <<<"$j"; }
        # README берём с raw.githubusercontent.com: у него нет лимита API
        local f base="https://raw.githubusercontent.com/$o/$r/${ref:-HEAD}/${path:+$path/}"
        local rc
        for f in README.md readme.md README.rst README.txt README; do
          j="$(curl -sSLf --connect-timeout 8 --max-time 20 -A "$WEB_UA" "$base$f" 2>/dev/null)"; rc=$?
          if (( rc == 0 )) && [[ -n "$j" ]]; then
            printf '\n== %s ==\n%s\n' "$f" "$j"; printed=1; break
          fi
          # 22 — «нет такого файла», пробуем следующее имя; всё прочее (таймаут,
          # нет сети) повторять пять раз по двадцать секунд бессмысленно
          (( rc == 22 )) || break
        done
        [[ -n "$printed" ]] && return 0
        return 1 ;;
    esac
    return 1
  fi
  if [[ "$u" =~ ^https?://gist\.github\.com/[^/]+/([0-9a-f]+) ]]; then
    _web_gh "https://api.github.com/gists/${BASH_REMATCH[1]}" | jq -r '.files[] | "== \(.filename) ==\n\(.content)\n"' 2>/dev/null && return 0
    return 1
  fi
  # ── StackExchange ──
  if [[ "$u" =~ ^https?://(www\.)?(stackoverflow\.com|superuser\.com|serverfault\.com|askubuntu\.com|([a-z]+)\.stackexchange\.com)/(questions|q)/([0-9]+) ]]; then
    local site="${BASH_REMATCH[2]%.com}" id="${BASH_REMATCH[5]}" se="https://api.stackexchange.com/2.3"
    [[ -n "${BASH_REMATCH[3]}" ]] && site="${BASH_REMATCH[3]}"
    local q a
    q="$(curl -sSL --connect-timeout 8 --compressed --max-time 20 -A "$WEB_UA" "$se/questions/$id?site=$site&filter=withbody" 2>/dev/null)"
    [[ "$(jq -r '.items | length' <<<"$q" 2>/dev/null)" =~ ^[1-9] ]] || return 1
    a="$(curl -sSL --connect-timeout 8 --compressed --max-time 20 -A "$WEB_UA" "$se/questions/$id/answers?site=$site&filter=withbody&sort=votes&order=desc&pagesize=4" 2>/dev/null)"
    { jq -r '.items[0] | "<h1>\(.title)</h1><p>вопрос · голосов \(.score) · ответов \(.answer_count) · метки: \(.tags | join(", "))</p>\(.body)"' <<<"$q"
      jq -r '.items[]? | "<hr><h2>Ответ · голосов \(.score)\(if .is_accepted then " · ПРИНЯТ" else "" end)</h2>\(.body)"' <<<"$a"
    } 2>/dev/null | web_html2text "$url" | sed '1{/^# $/d}'
    return 0
  fi
  # ── npm ──
  if [[ "$u" =~ ^https?://(www\.)?npmjs\.com/package/(.+)$ ]]; then
    m="${BASH_REMATCH[2]%%\?*}"; m="${m%/}"; m="${m%%/v/*}"
    curl -sSL --connect-timeout 8 --compressed --max-time 25 -A "$WEB_UA" "https://registry.npmjs.org/${m//\//%2f}" 2>/dev/null | jq -r '
      if .error then "npm: " + .error else
      (.["dist-tags"].latest) as $l | (.versions[$l] // {}) as $v |
      "# \(.name) \($l)\n\(.description // "")\nметки версий: \(.["dist-tags"] | to_entries | map("\(.key)=\(.value)") | join(", "))\nопубликована: \((.time[$l] // "?")[0:10])\nengines: \($v.engines // {} | tojson)\(if ($v.os // []) != [] or ($v.cpu // []) != [] then "\nos: \($v.os // [] | join(",")) cpu: \($v.cpu // [] | join(","))" else "" end)\nbin: \($v.bin // {} | tojson)\npostinstall: \($v.scripts.postinstall // "нет")\nзависимости: \($v.dependencies // {} | keys | join(", "))\nнеобязательные: \($v.optionalDependencies // {} | keys | join(", "))\nрепозиторий: \($v.repository.url // .repository.url // "")\n\n\((.readme // "")[0:6000])" end' 2>/dev/null && return 0
    return 1
  fi
  # ── PyPI ──
  if [[ "$u" =~ ^https?://pypi\.org/project/([^/]+)(/([^/]+))? ]]; then
    local pkg="${BASH_REMATCH[1]}" ver="${BASH_REMATCH[3]}"
    curl -sSL --connect-timeout 8 --compressed --max-time 25 -A "$WEB_UA" "https://pypi.org/pypi/$pkg${ver:+/$ver}/json" 2>/dev/null | jq -r '
      .info as $i |
      "# \($i.name) \($i.version)\n\($i.summary // "")\nrequires_python: \($i.requires_python // "?")\nзависимости: \(($i.requires_dist // []) | join("; "))\nфайлы этой версии: \([.urls[]? | .filename] | join(", "))\nссылки: \(($i.project_urls // {}) | to_entries | map("\(.key): \(.value)") | join(" · "))\n\n\(($i.description // "")[0:6000])"' 2>/dev/null && return 0
    return 1
  fi
  return 1
}

# ── чтение страницы целиком ────────────────────────────────────────────────
_web_cache_key() { printf '%s' "$1" | md5sum 2>/dev/null | cut -c1-32; }

# web_read <url> → текст на stdout; первая строка «@@ HTTP код · тип · источник»
web_read() {
  local url="$1" key cf
  case "$url" in http://*|https://*) ;; *) url="https://$url" ;; esac
  mkdir -p "$WEB_CACHE" 2>/dev/null
  key="$(_web_cache_key "$url")"; cf="$WEB_CACHE/$key.txt"
  if [[ -n "$key" && -s "$cf" ]] && [[ -n "$(find "$cf" -mmin -15 2>/dev/null)" ]]; then
    cat "$cf"; return 0
  fi
  # старое подметаем изредка
  (( RANDOM % 20 == 0 )) && find "$WEB_CACHE" -type f -mmin +1440 -delete 2>/dev/null

  # Общий срок на всё чтение. У каждого curl свой --max-time, но у особых сайтов
  # их бывает по пять-шесть подряд (API, README, запасной HTML, reader), и в сумме
  # набегали минуты. Дольше срока не ждём: возвращаем честный таймаут.
  local out; out="$(mktemp)"
  local limit="${WEB_DEADLINE:-$(cfg_setting fetch_deadline 60 2>/dev/null || echo 60)}"
  [[ "$limit" =~ ^[0-9]+$ ]] && (( limit >= 5 )) || limit=60
  ( _web_fetch_uncached "$url" > "$out" ) 2>/dev/null &
  local pid=$! ticks=0 timed_out=0
  while kill -0 "$pid" 2>/dev/null; do
    if (( ticks >= limit * 5 )); then _web_kill_tree "$pid"; timed_out=1; break; fi
    sleep 0.2; (( ticks++ ))
  done
  { wait "$pid"; } 2>/dev/null
  if (( timed_out == 1 )); then
    printf '@@ HTTP 000 · таймаут\nстраница не прочиталась за %sс: сайт тянет ответ или не отвечает.\nПопробуй позже, другой источник или web_search.\n' "$limit" > "$out"
  fi
  [[ -n "$key" ]] && [[ "$(head -1 "$out")" == "@@ HTTP 2"* ]] && cp "$out" "$cf" 2>/dev/null
  cat "$out"; rm -f "$out"
}

_web_kill_tree() {
  local c
  for c in $(pgrep -P "$1" 2>/dev/null); do _web_kill_tree "$c"; done
  kill -TERM "$1" 2>/dev/null
}

_web_fetch_uncached() {
  local url="$1" body meta code ctype text cs
  if text="$(_web_special "$url")" && [[ -n "${text//[[:space:]]/}" ]]; then
    printf '@@ HTTP 200 · api\n%s\n' "$text"; return 0
  fi
  body="$(mktemp)"
  meta="$(web_get "$url" "$body")"; code="${meta%%$'\t'*}"; ctype="${meta#*$'\t'}"
  ctype="${ctype,,}"
  if [[ ! -s "$body" ]]; then
    rm -f "$body"
    printf '@@ HTTP %s · пусто\nпустой ответ (нет сети, таймаут или доступ закрыт)\n' "${code:-000}"; return 0
  fi

  # кодировка: Content-Type или <meta charset> в начале страницы
  cs=""; [[ "$ctype" =~ charset=([a-z0-9_-]+) ]] && cs="${BASH_REMATCH[1]}"
  if [[ -z "$cs" && "$ctype" == *html* ]]; then
    [[ "$(head -c 3000 "$body" | tr 'A-Z' 'a-z')" =~ charset=[\"\']?([a-z0-9_-]+) ]] && cs="${BASH_REMATCH[1]}"
  fi
  if [[ -n "$cs" && "$cs" != utf-8 && "$cs" != utf8 && "$cs" != us-ascii ]] && command -v iconv >/dev/null; then
    iconv -c -f "$cs" -t UTF-8 "$body" > "$body.u" 2>/dev/null && [[ -s "$body.u" ]] && mv "$body.u" "$body"
    rm -f "$body.u"
  fi

  local kind="text"
  case "$ctype" in
    *json*) kind=json ;;
    *html*|*xml*) kind=html ;;
    *pdf*) kind=pdf ;;
    image/*|audio/*|video/*|*zip*|*octet-stream*|*gzip*|*tar*) kind=bin ;;
    "") head -c 600 "$body" | grep -qi '<html\|<!doctype html' && kind=html ;;
  esac
  [[ "$kind" == text ]] && head -c 600 "$body" | grep -qi '<html\|<!doctype html' && kind=html

  case "$kind" in
    json) text="$(jq . "$body" 2>/dev/null || cat "$body")" ;;
    pdf)
      if command -v pdftotext >/dev/null; then text="$(pdftotext -layout "$body" - 2>/dev/null)"
      else text="PDF, $(wc -c < "$body") байт. Чтобы читать PDF: pkg install poppler"; fi ;;
    bin) text="Бинарный файл: $ctype, $(wc -c < "$body") байт — текстом не показать." ;;
    html) text="$(web_html2text "$url" "${WEB_LINKS:-0}" < "$body")" ;;
    *) text="$(cat "$body")" ;;
  esac

  # Страница-приложение на JavaScript или защита от ботов: текста почти нет.
  # Тогда просим текстовую версию у r.jina.ai (ta set fetch_reader off — не надо).
  local src="$kind" words; words="$(printf '%s' "$text" | wc -w)"
  if [[ "$kind" == html ]] && { (( words < 60 )) || [[ "$code" == 403 || "$code" == 429 || "$code" == 503 ]]; } \
     && [[ "$(cfg_setting fetch_reader auto 2>/dev/null || echo auto)" != off ]]; then
    local rd; rd="$(curl -sSL --connect-timeout 8 --compressed --max-time 25 -A "$WEB_UA" -H 'X-Return-Format: markdown' \
                    "https://r.jina.ai/$url" 2>/dev/null)"
    if (( $(printf '%s' "$rd" | wc -w) > words + 40 )); then text="$rd"; src="reader"; code=200; fi
  fi
  rm -f "$body"
  printf '@@ HTTP %s · %s\n%s\n' "${code:-000}" "$src" "$text"
}
