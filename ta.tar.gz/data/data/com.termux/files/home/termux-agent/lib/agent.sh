#!/usr/bin/env bash
# lib/agent.sh — цикл агента: запрос → инструменты → ответ.

TA_TOK_IN=0; TA_TOK_OUT=0; TA_TOK_THINK=0; TA_API_MS=0; TA_TURNS=0
TA_QUEUE=(); TA_PENDING_CMDS=()


# Пустая сессия — это файл, где нет ни одного сообщения пользователя: такие
# остаются после каждого запуска «посмотреть и выйти» и засоряют список.
session_is_empty() {
  local f="$1"
  [[ -f "$f" ]] || return 1
  local n; n="$(jq '[.[] | select(.role == "user")] | length' "$f" 2>/dev/null || echo 1)"
  [[ "$n" == "0" ]]
}

session_drop_if_empty() {
  local f="$1"
  [[ -n "$f" ]] || return 0
  session_is_empty "$f" || return 0
  rm -f "$f" "$TA_CKPT_DIR/$(basename "$f" .json).log" 2>/dev/null
  return 0
}

# Подмести все пустые, кроме текущей.
sessions_sweep() {
  local f
  for f in "$TA_SESS_DIR"/*.json; do
    [[ -f "$f" ]] || continue
    [[ "$f" == "${TA_SESSION:-}" ]] && continue
    session_drop_if_empty "$f"
  done
  return 0
}

hist_new() {
  session_drop_if_empty "${TA_SESSION:-}"
  TA_SESSION="$TA_SESS_DIR/$(date +%Y%m%d-%H%M%S)-$$.json"
  jq -n --arg s "$(prompt_system)" '[{role:"system", content:$s}]' > "$TA_SESSION"
  TA_CKPT_LOG="$TA_CKPT_DIR/$(basename "$TA_SESSION" .json).log"
  : > "$TA_CKPT_LOG"
  TA_TOK_IN=0; TA_TOK_OUT=0; TA_TOK_THINK=0; TA_API_MS=0; TA_TURNS=0
}

hist_add() {
  local tmp="$TA_TMP/h.json"
  jq --argjson m "$1" '. += [$m]' "$TA_SESSION" > "$tmp" && mv "$tmp" "$TA_SESSION"
}

hist_user()  { hist_add "$(jq -n --arg c "$1" '{role:"user", content:$c}')"; }
hist_chars() { jq -r '[.[] | ((.content // "") | tostring | length)] | add // 0' "$TA_SESSION" 2>/dev/null; }
hist_ctx_pct() {
  local chars win
  chars="$(hist_chars)"; win="$(cfg_setting context_window 128000)"
  awk -v c="${chars:-0}" -v w="${win:-128000}" 'BEGIN{ if (w>0) printf "%.0f", (c/4)*100/w; else print 0 }'
}


# ── фоновые задачи ──────────────────────────────────────────────────────────
# Реестр запущенного в фоне: и то, что агент сам отправил в фон, и то, от чего
# пользователь отцепился по Ctrl+C. Завершение такой задачи — событие, о котором
# агент узнаёт на следующем же шаге, не дожидаясь, пока его спросят.
jobs_registry() { printf '%s' "$TA_DATA_DIR/run/jobs.tsv"; }

jobs_register() {   # jobs_register <pid> <ярлык> <лог>
  local reg; reg="$(jobs_registry)"
  mkdir -p "$(dirname "$reg")" 2>/dev/null
  printf '%s\t%s\t%s\n' "$1" "$2" "$3" >> "$reg"
}

# Печатает отчёт о завершившихся задачах и вычищает их из реестра.
jobs_collect() {
  local reg; reg="$(jobs_registry)"
  [[ -s "$reg" ]] || return 0
  local pid label log keep="" out=""
  while IFS=$'\t' read -r pid label log; do
    [[ -z "$pid" ]] && continue
    if kill -0 "$pid" 2>/dev/null; then
      keep+="$(printf '%s\t%s\t%s' "$pid" "$label" "$log")"$'\n'
    else
      local tail_txt=""
      [[ -f "$log" ]] && tail_txt="$(tail -c 600 "$log" 2>/dev/null)"
      out+="Фоновая задача «$label» (PID $pid) завершилась в $(date '+%H:%M').
Лог целиком: $log
Хвост вывода:
$tail_txt
"
    fi
  done < "$reg"
  printf '%s' "$keep" > "$reg"
  [[ -n "$out" ]] && printf '%s' "$out"
  return 0
}

jobs_alive() {
  local reg; reg="$(jobs_registry)"
  [[ -s "$reg" ]] || { printf '0'; return 0; }
  local pid rest c=0
  while IFS=$'\t' read -r pid rest; do
    [[ -n "$pid" ]] && kill -0 "$pid" 2>/dev/null && (( c++ ))
  done < "$reg"
  printf '%s' "$c"
}

# ── сообщения, набранные пока агент работает ────────────────────────────────
input_drain() {
  { : < /dev/tty; } 2>/dev/null || return 0
  local l
  while IFS= read -r -t 0.01 l </dev/tty 2>/dev/null; do
    [[ -n "${l// }" ]] && TA_QUEUE+=("$l")
  done
  return 0
}

# Пометка о том, когда и в какой ситуации пришло сообщение: агенту важно понимать,
# ждал он указаний, работал или его прервали на полуслове.
hist_user_tagged() {
  local text="$1" situation="$2"
  hist_user "$(printf '[%s · %s]\n%s' "$(date '+%H:%M')" "$situation" "$text")"
}

queue_flush() {
  input_collect
  (( ${#TA_QUEUE[@]} == 0 )) && return 0
  # Команды (начинаются с /) модели не отправляем: они предназначены программе.
  local keep=() msg situation
  for msg in "${TA_QUEUE[@]}"; do
    if [[ "$msg" == /* ]]; then TA_PENDING_CMDS+=("$msg"); else keep+=("$msg"); fi
  done
  TA_QUEUE=("${keep[@]}")
  (( ${#TA_QUEUE[@]} == 0 )) && return 0
  situation="дописано пока агент работал, прочти и учти немедленно"
  input_aborted && situation="пользователь прервал работу этим сообщением"
  for msg in "${TA_QUEUE[@]}"; do
    ui_user "$msg"
    hist_user_tagged "$msg" "$situation"
  done
  TA_QUEUE=()
}

# ── подтверждение ───────────────────────────────────────────────────────────
confirm_tool() {
  local name="$1" args="$2" why="${3:-}" rc
  TA_ARGS_EDITED=""
  input_watch_stop
  # Решение «спрашивать или нет» уже принято в tools_gate: там учтён и режим,
  # и проверка безопасности. Здесь второй раз не решаем. why — чем действие
  # насторожило проверку, если спрашиваем из-за неё.
  if ! { : < /dev/tty; } 2>/dev/null; then
    ui_dim "  нет терминала для подтверждения — отклонено (-y, если доверяешь)"
    return 1
  fi

  local intent; intent="$(jq -r '.intent // ""' <<<"$args" 2>/dev/null)"
  printf '  %s%s┌ подтвердить%s\n' "$C_YEL" "$C_B" "$C_RESET"
  if [[ -n "$why" ]]; then
    printf '%s\n' "проверка: $why" | ui_wrap $(( UI_COLS - 6 )) | while IFS= read -r l; do
      printf '  %s│%s %s%s%s\n' "$C_YEL" "$C_RESET" "$C_RED" "$l" "$C_RESET"
    done
  fi
  if [[ -n "$intent" && "$intent" != "null" ]]; then
    printf '%s\n' "$intent" | ui_wrap $(( UI_COLS - 6 )) | while IFS= read -r l; do
      printf '  %s│%s %s%s%s\n' "$C_YEL" "$C_RESET" "$C_B" "$l" "$C_RESET"
    done
    printf '  %s│%s\n' "$C_YEL" "$C_RESET"
  fi
  jq -r 'to_entries[] | select(.key != "intent") | "\(.key): \(.value|tostring)"' <<<"$args" 2>/dev/null \
    | ui_wrap $(( UI_COLS - 6 )) | while IFS= read -r l; do
        printf '  %s│%s %s%s%s\n' "$C_YEL" "$C_RESET" "$C_GRY" "$l" "$C_RESET"
      done
  # «a — дальше без вопросов» предлагаем только в обычном режиме и только
  # один раз за сессию: переключает в авто. Сюда же в авто-режиме попадает то,
  # что классификатор счёл опасным — вот тут «a» второй раз эскалирует в
  # полный авто (см. tools_gate: full). В режиме ревизора и в полном авто она
  # ничего не переключает. Нажал однажды на каждом уровне — дальше не
  # предлагаем этот уровень, даже если режим потом вернули назад.
  local offer_always=0 offer_full=0
  case "${TA_MODE:-normal}" in
    normal) [[ "${TA_ALWAYS_SESSION:-}" != "${TA_SESSION:-}" ]] && offer_always=1 ;;
    auto)   [[ "${TA_FULL_SESSION:-}" != "${TA_SESSION:-}" ]] && offer_full=1 ;;
  esac
  local keys="Enter — да · n — нет · e — править"
  (( offer_always == 1 )) && keys+=" · a — дальше без вопросов"
  (( offer_full == 1 )) && keys+=" · a — вообще без вопросов (необратимое всё равно спросит)"
  keys+=" · q — стоп"
  local first=1 l
  while IFS= read -r l; do
    if (( first )); then printf '  %s%s└ %s%s\n' "$C_YEL" "$C_B" "$l" "$C_RESET"; first=0
    else printf '  %s%s  %s%s\n' "$C_YEL" "$C_B" "$l" "$C_RESET"; fi
  done < <(printf '%s\n' "$keys" | ui_wrap $(( UI_COLS - 6 )))

  local a
  while :; do
    printf '  %s❯%s ' "$C_YEL" "$C_RESET"
    read -r a </dev/tty 2>/dev/null || a="n"
    case "${a,,}" in
      a|в) (( offer_always == 1 || offer_full == 1 )) && break
           ui_dim "  «a» здесь не действует: Enter — да, n — нет" ;;
      *) break ;;
    esac
  done
  case "${a,,}" in
    ""|y|д|да) input_watch_start; return 0 ;;
    a|в)
      if (( offer_full == 1 )); then
        TA_MODE="full"; TA_FULL_SESSION="${TA_SESSION:-}"
        ui_dim "  режим: полный авто — вообще без подтверждений; то, что проверка сочтёт"
        ui_dim "  опасным, дальше не спрашивает, а помечает модели в результате;"
        ui_dim "  необратимое (rm -rf, ~/.ssh и ключи, curl|sh…) всё равно спросит"
      else
        TA_MODE="auto"; TA_ALWAYS_SESSION="${TA_SESSION:-}"
        ui_dim "  режим: авто — дальше без подтверждений, опасное всё равно проверяется"
      fi
      input_watch_start; return 0 ;;
    e|у)
      local field val
      field="$(jq -r 'if has("command") then "command" elif has("path") then "path" else (keys[0] // "") end' <<<"$args")"
      [[ -z "$field" ]] && return 0
      val="$(jq -r --arg f "$field" '.[$f] | tostring' <<<"$args")"
      val="$(ui_input "$field:" "$val")"
      TA_ARGS_EDITED="$(jq -c --arg f "$field" --arg v "$val" '.[$f] = $v' <<<"$args")"
      ui_dim "  изменено"; input_watch_start; return 0 ;;
    q) TA_ABORT=1; input_watch_start; return 1 ;;
    *) input_watch_start; return 1 ;;
  esac
}

# ── запрос к модели ─────────────────────────────────────────────────────────
_call_model() {
  local body="$1" out="$2" code attempt=1 pid
  while (( attempt <= 3 )); do
    provider_send "$body" "$out" > "$TA_TMP/code.txt" 2>"$TA_TMP/curl.err" &
    pid=$!
    while kill -0 "$pid" 2>/dev/null; do
      if input_aborted; then kill_tree "$pid"; wait "$pid" 2>/dev/null; printf '130'; return 0; fi
      sleep 0.12
    done
    wait "$pid" 2>/dev/null
    code="$(cat "$TA_TMP/code.txt" 2>/dev/null)"
    [[ -z "$code" ]] && code=000
    case "$code" in
      429|500|502|503|504|000)
        (( attempt == 3 )) && break
        ui_status offline "повтор $attempt/3 через $(( attempt * 3 ))с"
        sleep $(( attempt * 3 ))
        (( attempt++ )) ;;
      *) break ;;
    esac
  done
  printf '%s' "$code"
}

_now_ms() { date +%s%3N 2>/dev/null || printf '%s000' "$(date +%s)"; }

# ── основной цикл ───────────────────────────────────────────────────────────
agent_turn() {
  local rc
  input_abort_clear
  TA_IN_TURN=1
  input_watch_start
  _agent_turn_inner "$@"; rc=$?
  input_watch_stop
  input_abort_clear
  TA_IN_TURN=0
  return $rc
}

_agent_turn_inner() {
  local input="$1"
  TA_ABORT=0; TA_400_RETRY=0; TA_EMPTY_RETRIES=0
  [[ -n "$input" ]] && hist_user "$input"
  declare -F guard_notes_prune >/dev/null && guard_notes_prune
  rm -f "$TA_TMP/tools.json"
  tools_schema > "$TA_TMP/tools_schema.json"

  local step=0
  while (( step < TA_MAX_STEPS )); do
    (( step++ ))
    input_drain; queue_flush

    local finished; finished="$(jobs_collect)"
    if [[ -n "$finished" ]]; then
      ui_info "фоновая задача завершилась"
      hist_user_tagged "$finished" "фоновая задача завершилась сама, пока ты работал"
    fi

    if ! provider_request "$TA_SESSION" "$TA_TMP/tools_schema.json" > "$TA_TMP/req.json" 2>"$TA_TMP/req.err"; then
      ui_err "не удалось собрать запрос: $(head -2 "$TA_TMP/req.err")"; return 1
    fi

    local streaming=0
    stream_enabled && streaming=1
    stream_loop_reset
    [[ "${TA_REASONING:-off}" == "off" ]] && ui_status api || ui_status think
    local t0 t1 secs; t0="$(_now_ms)"
    local code
    if (( streaming == 1 )); then
      # Поток печатает мысли сам, поэтому анимацию убираем заранее.
      ui_status_stop
      provider_stream "$TA_TMP/req.json" "$TA_TMP/stream.json" > "$TA_TMP/code.txt"
      code="$(cat "$TA_TMP/code.txt")"
    else
      code="$(_call_model "$TA_TMP/req.json" "$TA_TMP/resp.json")"
    fi
    # Модель залипла и повторяет одну фразу — генерация уже остановлена,
    # осталось дать ей толчок. Про само зацикливание не говорим: объяснять
    # это бесполезно, а лишний текст только сбивает.
    if [[ "${code:-}" == "598" ]]; then
      ui_status_stop
      (( ${TA_LOOP_RETRIES:-0} >= 3 )) && {
        ui_err "модель не может продолжить — останавливаюсь"
        TA_LOOP_RETRIES=0; return 1; }
      TA_LOOP_RETRIES=$(( ${TA_LOOP_RETRIES:-0} + 1 ))
      ui_warn "ответ оборван, прошу продолжить"
      hist_user_tagged "Ответ не дошёл из-за технической ошибки связи. Продолжай задачу с того места, где остановился: назови следующий конкретный шаг и сразу сделай его. Отвечай коротко." \
                       "сбой передачи ответа"
      continue
    fi

    if [[ "${code:-}" == "599" ]]; then
      ui_warn "поток оборвался, повторяю обычным запросом"
      streaming=0
      code="$(_call_model "$TA_TMP/req.json" "$TA_TMP/resp.json")"
    elif (( streaming == 1 )) && [[ "${code:-}" != "200" && "${code:-}" != "130" ]]; then
      # Тело ошибки при потоковом запросе лежит в сыром потоке, а не в resp.json:
      # без этого пользователь видел пустое «API 400:».
      cp "$TA_TMP/stream.raw" "$TA_TMP/resp.json" 2>/dev/null || : > "$TA_TMP/resp.json"
      case "$code" in
        429|500|502|503|504|000)
          # Временная беда (у бесплатных моделей 429 — обычное дело):
          # обычный запрос умеет повторять с паузами.
          ui_status offline "повтор после ошибки $code"
          streaming=0
          code="$(_call_model "$TA_TMP/req.json" "$TA_TMP/resp.json")" ;;
      esac
    fi
    t1="$(_now_ms)"
    ui_status_stop
    secs="$(awk -v a="$t0" -v b="$t1" 'BEGIN{printf "%.1f", (b-a)/1000}')"

    if [[ "$code" == "130" ]] || input_aborted; then
      input_abort_clear
      ui_warn "запрос прерван"
      hist_user_tagged "Прерывание. Не продолжай начатое, дождись следующего указания." \
                       "пользователь прервал работу"
      # если пока прерывали, что-то было набрано — сразу продолжаем с этим
      input_collect
      if (( ${#TA_QUEUE[@]} > 0 )); then
        queue_flush
        continue
      fi
      return 130
    fi
    TA_API_MS=$(( TA_API_MS + t1 - t0 )); (( TA_TURNS++ ))

    if [[ "$code" != "200" ]]; then
      local emsg; emsg="$(provider_error "$TA_TMP/resp.json" 2>/dev/null)"
      [[ -z "$emsg" || "$emsg" == "null" ]] && emsg="$(head -c 300 "$TA_TMP/resp.json" 2>/dev/null)"
      [[ -z "$emsg" ]] && emsg="$(head -2 "$TA_TMP/curl.err" 2>/dev/null)"
      # Модель не умеет рассуждать, а мышление включено — выключаем его до конца
      # сессии и повторяем шаг сами, вместо того чтобы остановиться.
      if [[ "$code" == "400" && "${TA_REASONING:-off}" != "off" && "${TA_400_RETRY:-0}" == "0" ]] \
         && [[ "${emsg,,}" =~ (reason|think|effort) ]]; then
        TA_400_RETRY=1
        ui_warn "модель не принимает мышление ($(str_trunc "$emsg" 120)) — выключаю и повторяю"
        ui_dim "  вернуть: /think"
        TA_REASONING=off
        (( step-- ))
        continue
      fi
      if [[ "$code" == "000" ]]; then ui_state_line offline "$emsg"
      else ui_err "API $code: $(str_trunc "$emsg" 300)"; fi
      case "$code" in
        401|403) ui_dim "  ключ не принят — ta setup" ;;
        404)     ui_dim "  модель или base_url неверны — /model" ;;
        413)     ui_dim "  запрос слишком большой — /compact" ;;
        429)     ui_dim "  лимит запросов исчерпан — подожди минуту или смени модель: /model" ;;
        400)
          if [[ "${emsg,,}" =~ (context|token|too\ long|maximum|length) ]]; then
            ui_dim "  не помещается в контекст модели — /compact"
          elif [[ "${TA_REASONING:-off}" != "off" ]]; then
            ui_dim "  если повторяется: /think off, затем /compact"
          else
            ui_dim "  если повторяется: /compact или /new"
          fi ;;
      esac
      return 1
    fi

    local msg
    if (( streaming == 1 )); then msg="$(provider_stream_parse "$TA_TMP/stream.json")"
    else msg="$(provider_parse "$TA_TMP/resp.json")"; fi

    # Нестриминговый ответ приходит целиком, поэтому зацикливание видно только здесь.
    if [[ -n "$msg" ]] && (( streaming == 0 )); then
      local _check; _check="$(jq -r '((.content // "") + " " + (.reasoning // ""))' <<<"$msg" 2>/dev/null)"
      if text_is_looped "$_check"; then
        (( ${TA_LOOP_RETRIES:-0} >= 3 )) && { ui_err "модель не может продолжить — останавливаюсь"; TA_LOOP_RETRIES=0; return 1; }
        TA_LOOP_RETRIES=$(( ${TA_LOOP_RETRIES:-0} + 1 ))
        ui_warn "ответ оборван, прошу продолжить"
        hist_user_tagged "Ответ не дошёл из-за технической ошибки связи. Продолжай задачу с того места, где остановился: назови следующий конкретный шаг и сразу сделай его. Отвечай коротко." \
                         "сбой передачи ответа"
        continue
      fi
    fi
    if [[ -z "$msg" ]]; then
      ui_err "не разобрать ответ провайдера"
      local dbg="$TA_TMP/resp.json"
      (( streaming == 1 )) && dbg="$TA_TMP/stream.raw"
      [[ -s "$dbg" ]] && { ui_dim "  последнее, что пришло:"; tail -c 300 "$dbg" | ui_wrap "$UI_COLS" | while IFS= read -r l; do ui_dim "  $l"; done; }
      [[ -s "$TA_TMP/stream.jqerr" ]] && ui_dim "  разбор: $(head -c 200 "$TA_TMP/stream.jqerr")"
      return 1
    fi
    # Кривые вызовы (без имени, с пустыми или повторяющимися id) чиним до того,
    # как сообщение попадёт в историю: иначе следующий запрос получит 400.
    msg="$(toolcalls_fix "$msg" "$TA_TMP/tools_schema.json")"
    local _note
    while IFS= read -r _note; do
      [[ -n "$_note" ]] && ui_dim "  $_note"
    done < <(jq -r '(.notes // [])[]' <<<"$msg" 2>/dev/null)
    msg="$(jq -c 'del(.notes)' <<<"$msg")"
    hist_add "$msg"
    TA_400_RETRY=0

    TA_LOOP_RETRIES=0
    local usage out_tok total_tok
    if (( streaming == 1 )); then usage="$(provider_stream_usage "$TA_TMP/stream.json" 2>/dev/null || echo '0 0')"
    else usage="$(provider_usage "$TA_TMP/resp.json" 2>/dev/null || echo '0 0')"; fi
    out_tok="${usage%% *}"; total_tok="${usage##* }"
    TA_TOK_OUT=$(( TA_TOK_OUT + out_tok ))
    TA_TOK_IN=$(( TA_TOK_IN + (total_tok > out_tok ? total_tok - out_tok : 0) ))

    local reasoning text ncalls
    reasoning="$(jq -r '.reasoning // ""' <<<"$msg")"
    text="$(jq -r '.content // ""' <<<"$msg")"
    ncalls="$(jq '.tool_calls | length' <<<"$msg")"

    # Модель могла написать вызов текстом вместо структурного поля — тогда со
    # стороны это выглядит как «поговорил и ничего не сделал». Вылавливаем.
    if (( ncalls == 0 )) && [[ "$text$reasoning" == *"<invoke"* || "$text$reasoning" == *"tool_call"* || "$text$reasoning" == *'"arguments"'* ]]; then
      local recovered; recovered="$(toolparse_extract "$text$reasoning")"
      if [[ -n "$recovered" && "$recovered" != "[]" ]]; then
        ui_dim "  вызов пришёл текстом — разобрал сам"
        # Остатки разметки в ответе не нужны: это был вызов, а не реплика.
        text=""
        msg="$(jq -c --argjson tc "$recovered" --arg t "$text" '.tool_calls = $tc | .content = $t' <<<"$msg")"
        msg="$(toolcalls_fix "$msg" "$TA_TMP/tools_schema.json" | jq -c 'del(.notes)')"
        ncalls="$(jq '.tool_calls | length' <<<"$msg")"
        # в истории должна лежать уже исправленная версия
        local _tmp="$TA_TMP/h.json"
        jq --argjson m "$msg" '.[length-1] = $m' "$TA_SESSION" > "$_tmp" && mv "$_tmp" "$TA_SESSION"
      fi
    fi

    if [[ -n "$reasoning" && "$reasoning" != "null" ]]; then
      TA_LAST_THINKING="$reasoning"
      if (( streaming == 1 )); then
        : # мысли уже напечатаны потоком, время дописано в ту же строку
      else
        printf '\n'; ui_thinking "$reasoning" "$secs" ""
      fi
    fi
    if [[ -n "$text" && "$text" != "null" ]]; then
      printf '\n'; printf '%s\n' "$text" | ui_md
      TA_LAST_ANSWER="$text"
    fi

    if (( ncalls == 0 )); then
      # Модель подумала, но не ответила и ничего не вызвала (часто бывает, когда
      # её вызов инструмента пришёл битым и был отброшен). Молча останавливаться
      # нельзя — со стороны это выглядит как зависание. Подталкиваем.
      if [[ -z "${text//[[:space:]]/}" || "$text" == "null" ]]; then
        if (( ${TA_EMPTY_RETRIES:-0} < 2 )); then
          TA_EMPTY_RETRIES=$(( ${TA_EMPTY_RETRIES:-0} + 1 ))
          ui_metrics "$secs" "$out_tok" "$total_tok"
          ui_warn "пустой ответ без действий — прошу продолжить"
          hist_user_tagged "Твой прошлый ответ пришёл пустым: ни текста, ни вызова инструмента (если ты вызывал инструмент — вызов не дошёл, в нём не было имени). Продолжай задачу: сделай следующий шаг обычным вызовом инструмента с именем и аргументами-JSON, либо дай ответ текстом." \
                           "пустой ответ модели"
          continue
        fi
        TA_EMPTY_RETRIES=0
        ui_metrics "$secs" "$out_tok" "$total_tok"
        ui_warn "модель несколько раз ответила пустотой — остановился. Напиши «продолжай» или смени модель: /model"
        return 1
      fi
      TA_EMPTY_RETRIES=0
      ui_metrics "$secs" "$out_tok" "$total_tok"
      return 0
    fi
    TA_EMPTY_RETRIES=0

    local i
    for (( i=0; i<ncalls; i++ )); do
      local tc name args id result
      # Отмена — это отмена всего: оставшиеся вызовы даже не показываем.
      if (( TA_ABORT == 1 )); then
        tc="$(jq -c ".tool_calls[$i]" <<<"$msg")"
        hist_add "$(jq -n --arg id "$(jq -r '.id' <<<"$tc")" --arg n "$(jq -r '.name' <<<"$tc")" \
          --arg c "Отменено пользователем вместе со всеми оставшимися вызовами этого шага." \
          '{role:"tool", tool_call_id:$id, name:$n, content:$c}')"
        continue
      fi
      tc="$(jq -c ".tool_calls[$i]" <<<"$msg")"
      name="$(jq -r '.name' <<<"$tc")"
      args="$(jq -c '.arguments' <<<"$tc")"
      id="$(jq -r '.id' <<<"$tc")"

      local bad_args; bad_args="$(jq -r '.bad_args // ""' <<<"$tc")"
      if [[ -n "$bad_args" ]]; then
        ui_tool_head "$name" "(аргументы не разобрать)"
        ui_dim "  аргументы пришли не JSON-объектом — возвращаю модели"
        hist_add "$(jq -n --arg id "$id" --arg n "$name" --arg raw "$(str_trunc "$bad_args" 400)" \
          '{role:"tool", tool_call_id:$id, name:$n,
            content:("НЕ ВЫПОЛНЕНО: аргументы вызова не являются корректным JSON-объектом, поэтому ничего не запускалось.\nПришло: " + $raw + "\nПовтори вызов: один инструмент — один JSON-объект в arguments.")}')"
        continue
      fi

      ui_tool_head "$name" "$(tools_summary "$name" "$args")"
      local intent_line; intent_line="$(jq -r '.intent // ""' <<<"$args" 2>/dev/null)"
      if [[ -n "$intent_line" && "$intent_line" != "null" ]]; then
        printf '%s\n' "  $intent_line" | ui_wrap "$UI_COLS" | while IFS= read -r l; do
          printf '%s%s%s\n' "$C_GRY" "$l" "$C_RESET"
        done
      fi

      local allowed=1 result="" hist_content=""
      tools_gate "$name" "$args"
      case "$TA_GATE" in
        ask)
          confirm_tool "$name" "$args" "$TA_GATE_REASON" && allowed=1 || allowed=0 ;;
        note)
          allowed=1
          ui_warn "проверка: сработала, но пропущено (полный авто) — ${TA_GATE_REASON:-опасно}" ;;
        deny)
          allowed=0
          ui_err "проверка: отклонено${TA_GATE_REASON:+ — $TA_GATE_REASON}"
          result="НЕ ВЫПОЛНЕНО. Проверка безопасности отклонила действие: ${TA_GATE_REASON:-небезопасно}.
Ничего не произошло. Не повторяй это действие и не обходи запрет другим способом.
Если оно действительно нужно — объясни пользователю зачем и спроси через ask_user." ;;
      esac
      (( allowed == 0 )) && [[ -z "$result" ]] && \
        result="НЕ ВЫПОЛНЕНО. Пользователь запретил этот вызов и ничего не произошло.
Не повторяй эту же команду и не обходи запрет другим способом. Объясни коротко, зачем
она была нужна, и спроси, как поступить."

      if (( allowed == 1 )); then
        [[ -n "${TA_ARGS_EDITED:-}" ]] && args="$TA_ARGS_EDITED"
        # Инструменты, которые сами рисуют в терминале (вопрос, меню, план),
        # идут без спиннера: он перерисовывает строку каждые 100 мс и затирал
        # или сдвигал их вывод.
        local interactive=0
        [[ "$(tools_manifest | jq -r --arg n "$name" '.[] | select(.name==$n) | .x_interactive // false')" == "true" ]] && interactive=1
        (( interactive == 1 )) && input_watch_stop
        (( interactive == 0 )) && ui_status "$(fun_tool_phase "$name")" "$name"
        # Вывод пишем в постоянный файл: если пользователь отцепится от долгой
        # команды, процесс продолжит писать туда же, и лог не пропадёт.
        local runlog="$TA_DATA_DIR/run/$(date +%Y%m%d-%H%M%S)-$name.log"
        mkdir -p "$TA_DATA_DIR/run" 2>/dev/null
        ( TA_CKPT_LOG="${TA_CKPT_LOG:-}" TA_CKPT_DIR="$TA_CKPT_DIR" tools_run "$name" "$args" ) > "$runlog" 2>&1 &
        local tpid=$! detached=0
        while kill -0 "$tpid" 2>/dev/null; do
          if input_aborted; then
            # Не убиваем: это может быть сборка на двадцать минут.
            # Просто перестаём ждать и отдаём управление пользователю.
            detached=1
            break
          fi
          sleep 0.12
        done
        (( detached == 0 )) && wait "$tpid" 2>/dev/null
        ui_status_stop
        (( interactive == 1 )) && input_watch_start
        result="$(cat "$runlog" 2>/dev/null)"
        if (( detached == 1 )); then
          jobs_register "$tpid" "$name: $(tools_summary "$name" "$args" | cut -c1-40)" "$runlog"
          ui_warn "команда продолжает работать в фоне (PID $tpid)"
          ui_dim "  лог: $runlog · убить: kill $tpid"
          result="${result}
[Пользователь прервал ожидание в $(date '+%H:%M'). Процесс НЕ убит и продолжает
работать в фоне, PID $tpid, вывод пишется в $runlog. Выше — только то, что успело
попасть в лог. Продолжать ждать нельзя: дождись указаний пользователя, а состояние
при необходимости проверяй чтением этого файла.]"
        fi
        TA_LAST_TOOL_OUT="$result"
        [[ -z "$result" ]] && result="(пусто)"
        ui_tool_body "$result" 10
        if input_aborted; then
          input_abort_clear
          ui_warn "выполнение прервано"
        fi
        # В историю (модели) уходит пометка, что проверка сработала и была
        # пропущена только режимом «полный авто»; в терминале (человеку) это
        # уже показано отдельной строкой выше — result туда попадает как есть.
        if [[ "$TA_GATE" == note ]] && declare -F guard_note_wrap >/dev/null; then
          hist_content="$(guard_note_wrap "${TA_TURNS:-0}" "${TA_GATE_REASON:-опасно}" "$result")"
        fi
      elif [[ "$TA_GATE" != deny ]]; then
        ui_dim "  отклонено"
      fi
      unset TA_ARGS_EDITED

      hist_add "$(jq -n --arg id "$id" --arg n "$name" --arg c "${hist_content:-$result}" \
                    '{role:"tool", tool_call_id:$id, name:$n, content:$c}')"
      input_drain
    done

    ui_metrics "$secs" "$out_tok" "$total_tok"
    (( TA_ABORT == 1 )) && { ui_warn "прервано"; return 1; }
  done

  ui_warn "лимит шагов ($TA_MAX_STEPS) — напиши «продолжай» или подними: ta set max_steps N"
  return 1
}

# ── сжатие контекста ────────────────────────────────────────────────────────
agent_compact() {
  local level="${1:-normal}"
  local n; n="$(jq 'length' "$TA_SESSION")"
  (( n < 6 )) && { ui_dim "сжимать нечего"; return 0; }
  local tmp="$TA_TMP/compact" ask
  case "$level" in
    short|кратко|1)
      ask="Ужми диалог выше до 3-5 предложений: задача, чем кончилось, что осталось. Без подробностей." ;;
    full|подробно|3)
      ask="Составь подробную сводку диалога выше, чтобы по ней можно было продолжить работу с нуля: задача, окружение и версии, что уже проверено и с каким результатом, какие команды сработали и какие нет, точные пути и имена файлов, текущее состояние, что осталось сделать. Ничего важного не выбрасывай." ;;
    *)
      ask="Сожми диалог выше в сводку: задача, что выяснено, что сделано, что осталось. Ключевые пути и команды сохрани. Только сводка." ;;
  esac
  jq --arg a "$ask" '. + [{role:"user", content:$a}]' "$TA_SESSION" > "$tmp.hist"
  echo '[]' > "$tmp.tools"
  ui_status compact
  provider_request "$tmp.hist" "$tmp.tools" > "$tmp.req" 2>/dev/null
  local code; code="$(_call_model "$tmp.req" "$tmp.resp")"
  ui_status_stop
  [[ "$code" == "200" ]] || { ui_err "не вышло сжать (API $code)"; return 1; }
  local summary; summary="$(provider_parse "$tmp.resp" | jq -r '.content')"
  [[ -n "$summary" ]] || { ui_err "пустая сводка"; return 1; }
  jq -n --arg s "$(prompt_system)" --arg c "$summary" \
    '[{role:"system",content:$s},{role:"user",content:("Сводка предыдущего диалога:\n" + $c)}]' > "$TA_SESSION"
  ui_ok "контекст сжат ($level): было $n сообщений"
  printf '%s\n' "$summary" | ui_md
}

# ── откат правок (чекпоинты) ────────────────────────────────────────────────
cmd_rewind() {
  local log="${TA_CKPT_LOG:-}"
  [[ -n "$log" && -s "$log" ]] || { ui_dim "правок в этой сессии не было"; return 0; }

  local items="" p b i=0
  while IFS=$'\t' read -r p b; do
    [[ -z "$p" ]] && continue
    (( i++ ))
    items="$(printf '%s\t%s\t%s' "$i" "$p" "$( [[ -n "$b" ]] && echo 'вернуть прежнее содержимое' || echo 'файла не было — будет удалён' )")"$'\n'"$items"
  done < "$log"
  [[ -n "$items" ]] || { ui_dim "нечего откатывать"; return 0; }
  items="$(printf '%s\t%s\t%s' "ALL" "◀ откатить все правки сессии" "$i шт.")"$'\n'"$items"

  local pick; pick="$(printf '%s' "$items" | ui_pick --title "Откат правок" --hint "Enter вернуть · Esc отмена")" || return 1

  _restore_one() {
    local path="$1" backup="$2"
    if [[ -n "$backup" && -f "$backup" ]]; then cp "$backup" "$path" && ui_ok "восстановлен: $path"
    elif [[ -z "$backup" ]]; then rm -f "$path" && ui_ok "удалён (его не было): $path"
    else ui_warn "нет копии для $path"; fi
  }

  if [[ "$pick" == "ALL" ]]; then
    tac "$log" | while IFS=$'\t' read -r p b; do [[ -n "$p" ]] && _restore_one "$p" "$b"; done
    : > "$log"
    return 0
  fi

  local want="$pick" k=0
  while IFS=$'\t' read -r p b; do
    (( k++ ))
    [[ "$k" == "$want" ]] && { _restore_one "$p" "$b"; break; }
  done < "$log"
}
