#!/usr/bin/env bash
# lib/models.sh — список моделей прямо из API провайдера, с кэшем и поиском.

models_cache_file() {
  local key; key="$(printf '%s|%s' "$1" "$2" | md5sum 2>/dev/null | cut -c1-12)"
  [[ -z "$key" ]] && key="$(printf '%s' "$2" | tr -c 'a-zA-Z0-9' '_' | tail -c 20)"
  printf '%s/models-%s.json' "$TA_DATA_DIR" "$key"
}

# models_fetch <provider> <base_url> <key> [force] → TSV: id \t метка \t пояснение
models_fetch() {
  local provider="$1" base="${2%/}" key="${3:-}" force="${4:-}"
  local cache; cache="$(models_cache_file "$provider" "$base")"
  mkdir -p "$TA_DATA_DIR"

  if [[ -z "$force" && -s "$cache" ]]; then
    local age=$(( $(date +%s) - $(stat -c %Y "$cache" 2>/dev/null || echo 0) ))
    (( age < 86400 )) && { cat "$cache"; return 0; }
  fi

  local tmp; tmp="$(mktemp)" ; local code
  case "$provider" in
    anthropic)
      code="$(curl -sS --connect-timeout 4 --max-time 12 2>/dev/null -H "x-api-key: $key" -H 'anthropic-version: 2023-06-01' \
             "$base/models?limit=100" -o "$tmp" -w '%{http_code}')" ;;
    gemini)
      code="$(curl -sS --connect-timeout 4 --max-time 12 2>/dev/null -H "x-goog-api-key: $key" \
             "$base/models?pageSize=200" -o "$tmp" -w '%{http_code}')" ;;
    *)
      local -a H=()
      [[ -n "$key" ]] && H=(-H "Authorization: Bearer $key")
      code="$(curl -sS --connect-timeout 4 --max-time 12 2>/dev/null "${H[@]}" "$base/models" -o "$tmp" -w '%{http_code}')" ;;
  esac

  if [[ "$code" != "200" ]]; then rm -f "$tmp"; return 1; fi

  local out
  case "$provider" in
    anthropic)
      out="$(jq -r '.data[]? | [.id, (.display_name // .id), ""] | @tsv' "$tmp" 2>/dev/null)" ;;
    gemini)
      out="$(jq -r '
        .models[]? | select((.supportedGenerationMethods // []) | index("generateContent"))
        | [(.name | sub("^models/"; "")), (.displayName // .name),
           (if .inputTokenLimit then ((.inputTokenLimit/1000|floor|tostring) + "k") else "" end)]
        | @tsv' "$tmp" 2>/dev/null)" ;;
    *)
      if grep -q 'context_length' "$tmp" 2>/dev/null; then
        # OpenRouter и совместимые: показываем контекст и цену за миллион токенов
        out="$(jq -r '
          .data[]? |
          [ .id,
            (.name // .id),
            ( [ (if .context_length then ((.context_length/1000|floor|tostring) + "k") else empty end),
                (if (.pricing.prompt // "0") | tonumber > 0
                 then "$" + (((.pricing.prompt|tonumber) * 1000000 * 100 | round / 100) | tostring) + "/M"
                 else "free" end) ] | join(" · ") )
          ] | @tsv' "$tmp" 2>/dev/null)"
      else
        out="$(jq -r '(.data // .models // [])[]? | (if type=="string" then . else (.id // .name) end)
                      | [., ., ""] | @tsv' "$tmp" 2>/dev/null)"
      fi ;;
  esac
  rm -f "$tmp"

  [[ -z "$out" ]] && return 1
  printf '%s\n' "$out" | sort -u > "$cache"
  cat "$cache"
}

models_recent_add() {
  cfg_write '.recent_models = ([$m] + ((.recent_models // []) - [$m]))[0:8]' --arg m "$1" >/dev/null 2>&1
}

# Выбор модели: недавние сверху, затем весь список из API.
models_pick() {
  local provider="$1" base="$2" key="$3" force="${4:-}"
  local list recent items=""

  ui_status models
  list="$(models_fetch "$provider" "$base" "$key" "$force")"
  ui_status_stop

  if [[ -z "$list" ]]; then
    ui_warn "не удалось получить список моделей от провайдера"
    ui_dim "  бывает у локальных серверов и прокси — введи имя модели вручную"
    ui_input "Модель:" ""
    return $?
  fi

  recent="$(cfg_read '(.recent_models // [])[]' 2>/dev/null)"
  local r
  while IFS= read -r r; do
    [[ -z "$r" ]] && continue
    if printf '%s\n' "$list" | cut -f1 | grep -qxF "$r"; then
      items+="$(printf '%s\t%s\t%s' "$r" "$r" "недавняя")"$'\n'
    fi
  done <<< "$recent"

  items+="$list"
  local total; total="$(printf '%s\n' "$list" | wc -l)"
  printf '%s\n' "$items" | ui_pick \
    --title "Модель ($total доступно)" \
    --hint "↑↓ · печатай для поиска · Enter выбрать · Esc отмена" --custom
}

# ── общий выбор: модели всех настроенных профилей в одном списке ─────────────
# Значение результата: "<профиль>\x1f<модель>" либо "__fetch__\x1f<профиль>".
# Сеть не дёргается: берём только то, что уже в кэше. Списки, которых нет,
# показываем отдельной строкой «запросить у API» — тогда и решает пользователь.
models_pick_global() {
  local items="" cur_profile="${1:-}" p prov base cache line id lab meta
  local recent; recent="$(cfg_read '(.recent_models // [])[]' 2>/dev/null)"

  # 1. недавние — наверх
  local r
  while IFS= read -r r; do
    [[ -z "$r" ]] && continue
    items+="$(printf '%s\x1f%s\t%s\t%s' "$cur_profile" "$r" "$r" "недавняя")"$'\n'
  done <<< "$recent"

  # 2. по профилю: то, что уже скачано
  while IFS= read -r p; do
    [[ -z "$p" ]] && continue
    prov="$(jq -r --arg n "$p" '.profiles[$n].provider // "openai"' "$TA_CFG")"
    base="$(jq -r --arg n "$p" '.profiles[$n].base_url // ""' "$TA_CFG")"
    cache="$(models_cache_file "$prov" "${base%/}")"
    if [[ -s "$cache" ]]; then
      while IFS=$'\t' read -r id lab meta; do
        [[ -z "$id" ]] && continue
        items+="$(printf '%s\x1f%s\t%s\t%s' "$p" "$id" "${lab:-$id}" "$p${meta:+ · $meta}")"$'\n'
      done < "$cache"
    else
      items+="$(printf '__fetch__\x1f%s\t%s\t%s' "$p" "↻ $p: запросить список моделей" \
                "$(jq -r --arg n "$p" '.profiles[$n].model // ""' "$TA_CFG")")"$'\n'
    fi
  done < <(cfg_profiles)

  # 3. ручной ввод — всегда доступен
  items+="$(printf '__manual__\x1f%s\t%s\t%s' "$cur_profile" "✎ ввести имя модели вручную" "если её нет в списке")"$'\n'

  printf '%s' "$items" | ui_pick --title "Модель" \
    --hint "↑↓ · печатай для поиска · Enter выбрать · Esc отмена"
}
